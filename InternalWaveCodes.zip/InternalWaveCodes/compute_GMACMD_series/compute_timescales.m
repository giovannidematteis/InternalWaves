%% load all files
files = dir('*.mat');
tic
%% constant parameters
E_GM    = 0.003; %J/kg
f0      = 7.3*10^-5; %1cpd 
f00     = sin(32.5*pi/180)*2*f0; %value at which parameterization is computed
f_norm  = f00/f0; % f00 in cpd
N00     = f00*66.7978; %value at which parameterization is computed
omM2    = 2*pi/(12*60*60)*(24*60)/(24*60+50); %M2 tidal frequency
g       = 9.8;
rho     = 1000;
m_star  = 4*pi/1300*g/rho/N00^2;

NI_slopes = [];
continuum_slopes = [];
mslopes = [];
mEs = [];
mstars = [];
epsilons1 = [];
epsilons2 = [];
Pbudget_NIHWss = [];
Pbudget_HFLWss = [];
Pbudget_HFHWss = [];
Pout_NILWss = [];
Pout_NIHWss = [];
Pout_HFLWss = [];
Pout_HFHWss = [];
E_NILWss = [];
E_NIHWss = [];
E_HFLWss = [];
E_HFHWss = [];
Tev_NIHWss = [];
Tev_HFLWss = [];
Tev_HFHWss = [];
Tres_NILWss = [];
Tres_NIHWss = [];
Tres_HFLWss = [];
Tres_HFHWss = [];
Tres_totss  = [];

count = 0;

%% initialize structure parameters
Scount      = [];
Slatitude   = [];
Slongitude  = [];
Sidepth     = [];
Ssfdepth    = [];
Sf          = [];
Sn          = [];
Stimespec   = [];
Syday       = [];
Se0         = [];
Se0new      = [];


load('Pollmann_data');
depth_low = [300,500,1000];
depth_up  = [500,1000,2000];

% Define Ms, Rs, nu, mu, Rs, Os
        % define domain grid
        m_min = 2*pi/2600*g/rho/N00^2;
        m_max = 2*pi/10*g/rho/N00^2;%/5 or /10?
        cutoff = 0.03; % based on observations in stretched coordinates
        ms   = load('ms');
        os   = load('os');
        os_ex  = linspace(((1+cutoff)*f00),(N00),nom);
        [Os,Ms] = meshgrid(os,ms);
        Os       = Os';
        Ms       = Ms';
        Rs       = sqrt(1./((Os/f00).^2 - 1));

%% loop over all files

CC = 0;
for i=1:2984
    tic
    load(files(i).name)
    
    %% mooring-dependent parameters (all loaded from Arnaud's structure)
    k=2;
    if mod(length(mooring.block{1}.freq),2)==0 %adjust to even/odd array length
        k=1;
    end
    nfr     = floor((length(mooring.block{1}.freq))/2+k); %size of freq array
    ff      = sin(abs(mooring.latitude)*pi/180)*2*7.3*10^-5;%local inertial freq
    f       = ff/f0;% in cpd
    om      = mooring.block{1}.freq(nfr:end)/f;%frequency normalized by local f
    spec    = mooring.block{1}.spec(:,nfr:end) + fliplr(mooring.block{1}.spec(:,1:(nfr-k)));
    spec    = spec(:,(om-1)>0); %spectrum restricted to superinertial frequencies
    om      = om((om-1)>0); %frequency restricted to superinertial frequencies
    e_0     = mooring.block{1}.e0; %energy level relative to standard GM value E_GM
    j_max   = length(e_0);
    KE_e    = E_GM*e_0; %total kinetic energy
    N_e     = sqrt(mooring.N2)*ones(1,j_max); %buoyancy freq matched from climatology
    N_ov_f  = N_e(1)/ff; %local aspect ratio N/f
    f_e     = abs(f)*ones(1,j_max); %abs(f) in cpd
    lat     = mooring.latitude; %local latitude
    
    if(N_ov_f>2)
    
    NI_slope = zeros(1,j_max);
    continuum_slope = zeros(1,j_max);
    mslope = zeros(1,j_max)+nan;
    mE     = zeros(1,j_max)+nan;
    mstar  = zeros(1,j_max)+nan;
    
    %% latitude-dependent boundaries (Giovanni's precedure to exclude near-inertial PSI peak and non-resolved near-inertial peaks: see figure)
    if abs(lat)>28.9
        lNI   = log10((1-0.08)*omM2./ff-1); %M2 freq - 8%: NI upper bound
        lcont = log10((1+0.20)*omM2./ff-1); %M2 freq + 20%: continuum lower bound
    end
    if abs(lat)<=28.9
        lNI   = log10((1-0.12)*.5*omM2./ff-1); %1/2 M2 freq - 12%: NI upper bound
        lcont = log10((1+0.20)*omM2./ff-1); %M2 freq +20%: continuum lower bound
    end
    
    %% compute slope throughout time series
    timespecs   = mooring.block{1}.timespec;%mooring.begintime + j*mooring.increment/60/24;
    if length(timespecs)==1
        timespecs = timespecs + (1:j_max);
    end
    
    latitude   = mooring.latitude;
    longitude  = mooring.longitude;
    idepth     = mooring.idepth; %mooring depth
    sfdepth    = mooring.sfdepth; %sea floor depth
    
            %% Assign m slope from Pollmann's dataset
        
        
           Lat = latitude;
           Lon = longitude;
           Dep = idepth;
           [xx,bin_lat] = min(abs(P.lat(:,1)-Lat));
           llon=P.lon(1,:);
           lon360 = [llon(llon<0)+360,llon(llon>=0)];
           [xx,bin_lon] = min(abs(lon360-Lon));
           dd = nan;
           for ddepth=1:3
              if(idepth>depth_low(ddepth) && idepth<depth_up(ddepth))
                  dd = ddepth;
              end
           end
           if dd==1
                  mslope    = ones(1,j_max)*P.s1(bin_lat,bin_lon);
                  mE        = ones(1,j_max)*P.e1(bin_lat,bin_lon);
                  mstar     = ones(1,j_max)*P.m1(bin_lat,bin_lon);
           end
           if dd==2
                  mslope    = ones(1,j_max)*P.s2(bin_lat,bin_lon);
                  mE        = ones(1,j_max)*P.e2(bin_lat,bin_lon);
                  mstar     = ones(1,j_max)*P.m2(bin_lat,bin_lon);
           end
           if dd==3
                  mslope    = ones(1,j_max)*P.s3(bin_lat,bin_lon);
                  mE        = ones(1,j_max)*P.e3(bin_lat,bin_lon);
                  mstar     = ones(1,j_max)*P.m3(bin_lat,bin_lon);
           end
           
          % mslope = mslope + 0.2; % Kurt's test based on Natre geostrophic eddies
    
    e0news = zeros(1,j_max)+nan;
    
    for j=1:j_max %loop over time by increments of 1 day
       
        count      = count + 1;

        timespec   = timespecs(j); %date
        d          = datetime(timespec,'ConvertFrom','datenum');
        yday       = day(d,'dayofyear');
        
        cond_om1 = logical((log10(om-1)>-1.6).*(log10(om-1)<lNI)); %logical selection of NI peak bt/ fixed lower bound (1.03f) and upper bound
        cond_om2 = logical((log10(om-1)>lcont).*(log10(om)<log10(N_ov_f))); %logical selection of continuum bt/ lower bound and buoyancy freq
        %pause
        l_om1 = log10(om(cond_om1)-1); %log10 of stretched NI frequency variable
        l_om2 = log10(om(cond_om2)); %log10 of continuum frequency variable
        X = [ones(length(l_om1),1) l_om1']; %standard linear best fit for NI spectrum
        b = X\log10(spec(j,cond_om1)');
        b1=b; %NI slope and vertical shift
        NI_slope(j) = -b(2); %save minus NI slope
        X = [ones(length(l_om2),1) l_om2']; %standard linear best fit for continuum spectrum
        b = X\log10(spec(j,cond_om2)'); %continuum slope and vertical shift
        continuum_slope(j) = -b(2); %save minus continuum slope
        
       
        
        
        %% Compute kinetic energy
        
        l_om2     = log10(om(cond_om2)-1);
        l_om      = [l_om1,l_om2];
        sp        = [spec(j,cond_om1),spec(j,cond_om2)];
        
        om_int    = linspace(1.03,N_ov_f,1000);
        l_om_int  = log10(om_int-1);
        sp_int    = 10.^(interp1(l_om,log10(sp),l_om_int));
        om_Int    = om_int(logical(1-isnan(sp_int)));
        sp_Int    = sp_int(logical(1-isnan(sp_int)));
        KinEn     = (trapz(om_Int,sp_Int) + 0.03*sp_Int(1))*f_e(1); % check with Arnaud f or no f!!!
        e0new     = KinEn/E_GM; % /(N_e(1))*(N00) for now, wait for confirmation from Arnaud about WKB normalization
       % e0new/E_GM/e_0(j); This quantity is NOT WKB-scaled
        
        om_pos = om(om>1);
        spec_pos = spec(j,om>1);
        
%         figure(1);clf;
%         loglog(om_pos-1,spec_pos,om_Int-1,sp_Int)
%         xlabel('$\omega$','interpreter','latex')
%         ylabel('$e(\omega)$','interpreter','latex')
        
%pause

        
         %uncomment for visualization of the slopes
%          if j==1
%             figure(3)
%             clf;
%             plot(log10(om_pos-1),log10(spec_pos),'*','linewidth',1.2,'markersize',3)
%             hold on
%             plot(log10(om(cond_om1)-1),log10(om(cond_om1)-1)*b1(2)+b1(1),'k','linewidth',2)
%             plot(log10(om_pos(1:20)-1),log10(om_pos(1:20)-1)*(-0.5)+b1(1),'m--','linewidth',2)
%             xlabel('$log10(\omega-f)/f$','Interpreter','latex')
%             plot(log10(om_pos(cond_om2)-1),log10(om_pos(cond_om2))*b(2)+b(1),'r','linewidth',2)
%             xlabel('$log10(\omega-f)/f$','Interpreter','latex')
%             
%             figure(4)
%             clf;
%             plot(log10(om_pos),log10(spec_pos),'*','linewidth',1.2,'markersize',3)
%             hold on
%             plot(log10(om_pos(cond_om1)),log10(om_pos(cond_om1)-1)*b1(2)+b1(1),'k','linewidth',2)
%             plot(log10(om_pos(1:20)),log10(om_pos(1:20)-1)*(-0.5)+b1(1),'m--','linewidth',2)
%             xlabel('$log10(\omega)/f$','Interpreter','latex')
%             plot(log10(om_pos(cond_om2)),log10(om_pos(cond_om2))*b(2)+b(1),'r','linewidth',2)
%             xlabel('$log10(\omega)/f$','Interpreter','latex')

%save all parameters for structure            
        Scount      = [Scount,count];
        Slatitude   = [Slatitude,latitude];
        Slongitude  = [Slongitude,longitude];
        Sidepth     = [Sidepth,idepth];
        Ssfdepth    = [Ssfdepth,sfdepth];
        Sf          = [Sf,ff];
        Sn          = [Sn,N_e(1)];
        Stimespec   = [Stimespec,timespec];
        Syday       = [Syday,yday];
        Se0         = [Se0,e_0(j)];
        Se0new      = [Se0new,e0new];
        
        e0news(j)     = e0new;
        
          %   pause
%          end
    end
    
    %% Second part of the script: calculate epsilon
    
    %spectral parameters in our parameterization (see Eq.3 notes)
    s_e     = NI_slope;
    y_e     = continuum_slope;
    nu_e    = 2-y_e;
    mu_e    = 2*s_e+nu_e-1;
    z_e     = mslope;
    mE_e    = mE;
    mstar_e = mstar;
    
    [lat longitude f mean(s_e) mean(y_e) z_e(1)]

    DissipatedPowers_e1 = zeros(1,j_max)+nan;
    DissipatedPowers_e2 = zeros(1,j_max)+nan;
    Pbudget_NIHWs = zeros(1,j_max)+nan;
    Pbudget_HFLWs = zeros(1,j_max)+nan;
    Pbudget_HFHWs = zeros(1,j_max)+nan;
    Pout_NILWs = zeros(1,j_max)+nan;
    Pout_NIHWs = zeros(1,j_max)+nan;
    Pout_HFLWs = zeros(1,j_max)+nan;
    Pout_HFHWs = zeros(1,j_max)+nan;
    E_NILWs = zeros(1,j_max)+nan;
    E_NIHWs = zeros(1,j_max)+nan;
    E_HFLWs = zeros(1,j_max)+nan;
    E_HFHWs = zeros(1,j_max)+nan;
    Tev_NIHWs = zeros(1,j_max)+nan;
    Tev_HFLWs = zeros(1,j_max)+nan;
    Tev_HFHWs = zeros(1,j_max)+nan;
    Tres_NILWs = zeros(1,j_max)+nan;
    Tres_NIHWs = zeros(1,j_max)+nan;
    Tres_HFLWs = zeros(1,j_max)+nan;
    Tres_HFHWs = zeros(1,j_max)+nan;
    Tres_tots  = zeros(1,j_max)+nan;
    
    if (logical((1-isnan(mslope(1)))*(mslope(1)>1)*(mslope(1)<3)))
    for ii=1:j_max
        y  = y_e(ii);
        s  = s_e(ii);
        z  = z_e(ii);
        e0new = e0news(ii);
        
%         % averaged version
%         y = mean(y_e,'omitnan');
%         s = mean(s_e,'omitnan');
%         z = mean(z_e,'omitnan');
%         e0new = mean(Se0new,'omitnan');
        
        nu = 2 - y;
        mu = 2*s + nu - 1;
        KinEn     = e0new*E_GM; %NOT WKB-scaled
        
        Fi = interpolant3D(y,s,z,Fs,params); %calculate fluxes from interpolation on 3D parameterization grid
        %Fi = interpolant(y,s,Fs,params); %calculate fluxes from interpolation on 2D parameterization grid

        %Fis(ii) = Fi*(KE_e(ii)^2);
        % Calculate turbulence production summing the fluxes that go beyond the
        % threshold of transition to turbulence
        DissipatedPower_e1 = Fi(2,3)*(Fi(2,3)>0)+Fi(5,6)+Fi(8,9)+Fi(2,6)+Fi(8,6)*(Fi(8,6)>0)+Fi(5,9)+Fi(1,3);
        DissipatedPower_e2 = +Fi(1,3) + Fi(2,3)*(Fi(2,3)>0)+Fi(2,6)+Fi(5,6)+Fi(5,9)+Fi(4,7)+Fi(5,8)+Fi(4,8)+Fi(5,7);
        
        % Calculate partial powers
        P2budget = (Fi(1,2) + Fi(3,2) + Fi(4,2) + Fi(5,2) + Fi(6,2) + Fi(7,2) + Fi(8,2) + Fi(9,2))*(KinEn^2)*(f_e(ii)/f_norm);
        P4budget = (Fi(1,4) + Fi(2,4) + Fi(3,4) + Fi(5,4) + Fi(6,4) + Fi(7,4) + Fi(8,4) + Fi(9,4))*(KinEn^2)*(f_e(ii)/f_norm);
        P5budget = (Fi(1,5) + Fi(2,5) + Fi(3,5) + Fi(4,5) + Fi(6,5) + Fi(7,5) + Fi(8,5) + Fi(9,5))*(KinEn^2)*(f_e(ii)/f_norm);
        
        % Compute 2D energy density
        n     = (Ms./Rs).^(-4+nu).*(1+Rs.^2).^((mu-3)/2).*(abs(Ms).^(y-z))./(1+(m_star./abs(Ms)).^z);
        en    = n.*(Ms.^2).*(Os.^2); %all prefactors have been dropped: going to be normalized to KE anyway
        En_h  = trapz(ms,en,2); % integrate in vertical wavenumber
        E_tot = trapz(os,En_h) + (os(1)-f00)*En_h(1); % total energy not normalized
        norm_factor = KinEn/E_tot;
        E_tot = KinEn;
        en    = en*norm_factor; % normalized 2D energy density
        
             
        
        % Compute the 4 partial energies
        % Define matrices with boundaries
        mss = [m_min,20*m_min,m_max,20*m_max];
        oss = [1.03*f00,5*f00,20*f00,N00];
        n_mss = [1,17,200]; % boundary indeces
        n_oss = [1,61,290]; % boundary indeces
        % NI-LW
        En_h = trapz(ms(n_mss(1):n_mss(2)),en(:,n_mss(1):n_mss(2)),2);
        E_tot_NILW = trapz(os(n_oss(1):n_oss(2)),En_h(n_oss(1):n_oss(2))) + (os(1)-f00)*En_h(1);
        % NI-HW
        En_h = trapz(ms(n_mss(2):n_mss(3)),en(:,n_mss(2):n_mss(3)),2);
        E_tot_NIHW = trapz(os(n_oss(1):n_oss(2)),En_h(n_oss(1):n_oss(2))) + (os(1)-f00)*En_h(1);
        % HF-LW
        En_h = trapz(ms(n_mss(1):n_mss(2)),en(:,n_mss(1):n_mss(2)),2);
        E_tot_HFLW = trapz(os(n_oss(2):n_oss(3)),En_h(n_oss(2):n_oss(3)));
        % HF-HW
        En_h = trapz(ms(n_mss(2):n_mss(3)),en(:,n_mss(2):n_mss(3)),2);
        E_tot_HFHW = trapz(os(n_oss(2):n_oss(3)),En_h(n_oss(2):n_oss(3)));
        
        
        % Compute the powers going out of the 4 boxes
        Po_NILW = (Fi(2,1)*(Fi(2,1)<0) + Fi(3,1)*(Fi(3,1)<0) + Fi(4,1)*(Fi(4,1)<0) + Fi(5,1)*(Fi(5,1)<0) + Fi(7,1)*(Fi(7,1)<0))*(KinEn^2)*(f_e(ii)/f_norm);
        Po_NIHW = (Fi(1,2)*(Fi(1,2)<0) + Fi(3,2)*(Fi(3,2)<0) + Fi(4,2)*(Fi(4,2)<0) + Fi(5,2)*(Fi(5,2)<0) + Fi(6,2)*(Fi(6,2)<0) + Fi(7,2)*(Fi(7,2)<0) + Fi(8,2)*(Fi(8,2)<0) + Fi(9,2)*(Fi(9,2)<0))*(KinEn^2)*(f_e(ii)/f_norm);
        Po_HFLW = (Fi(1,4)*(Fi(1,4)<0) + Fi(2,4)*(Fi(2,4)<0) + Fi(3,4)*(Fi(3,4)<0) + Fi(5,4)*(Fi(5,4)<0) + Fi(6,4)*(Fi(6,4)<0) + Fi(7,4)*(Fi(7,4)<0) + Fi(8,4)*(Fi(8,4)<0) + Fi(9,4)*(Fi(9,4)<0))*(KinEn^2)*(f_e(ii)/f_norm);
        Po_HFHW = (Fi(1,5)*(Fi(1,5)<0) + Fi(2,5)*(Fi(2,5)<0) + Fi(3,5)*(Fi(3,5)<0) + Fi(4,5)*(Fi(4,5)<0) + Fi(6,5)*(Fi(6,5)<0) + Fi(7,5)*(Fi(7,5)<0) + Fi(8,5)*(Fi(8,5)<0) + Fi(9,5)*(Fi(9,5)<0))*(KinEn^2)*(f_e(ii)/f_norm);

        % Compute the evolution timescales (in hours)
        Tev_NIHW = E_tot_NIHW/P2budget/(-3600);
        Tev_HFLW = E_tot_HFLW/P4budget/(-3600);
        Tev_HFHW = E_tot_HFHW/P5budget/(-3600);
        
        % Compute the 4 residence timescales and the total res ts (in hours)
        Tres_NILW = E_tot_NILW/Po_NILW/(-3600);
        Tres_NIHW = E_tot_NIHW/Po_NIHW/(-3600);
        Tres_HFLW = E_tot_HFLW/Po_HFLW/(-3600);
        Tres_HFHW = E_tot_HFHW/Po_HFHW/(-3600);
        
        
        %pause
        KE = E_GM*e0new; %KE_e(ii)
        DissipatedPower_e1 = DissipatedPower_e1*(KE^2)*(f_e(ii)/f_norm) .* ((N_e(ii)/N00).^(0*(2+2*(y_e(ii)-2))));%((N_e(ii)/N00).^(2+2*(y_e(ii)-2)));%*((N_e(ii)/N0)^(2*nu_e(ii)-2));
        DissipatedPower_e2 = DissipatedPower_e2*(KE^2)*(f_e(ii)/f_norm) .* ((N_e(ii)/N00).^(0*(2+2*(y_e(ii)-2))));%((N_e(ii)/N00).^(2+2*(y_e(ii)-2)));%*((N_e(ii)/N0)^(2*nu_e(ii)-2));
        
        Tres_tot  = E_tot/DissipatedPower_e2;
        %ii
        %checkPowers = [DissipatedPower1,DissipatedPower2,DissipatedPower3]
        % the above analysis shows that the only flux component that fleeps and strongly
        % goes upscale for large y is mat(2,3), which is inhibited by physical
        % reasons (absence of energy source in box 3, in the dissipation region
        % of shear instability. Thus, DissipatedPower3 appears to be the most appropriate definition)
        DissipatedPowers_e1(ii) = DissipatedPower_e1; %save turbulent production
        DissipatedPowers_e2(ii) = DissipatedPower_e2; %save turbulent production
        Pbudget_NIHWs(ii) = P2budget;
        Pbudget_HFLWs(ii) = P4budget;
        Pbudget_HFHWs(ii) = P5budget;
        Pout_NILWs(ii) = Po_NILW;
        Pout_NIHWs(ii) = Po_NIHW;
        Pout_HFLWs(ii) = Po_HFLW;
        Pout_HFHWs(ii) = Po_HFHW;
        E_NILWs(ii) = E_tot_NILW;
        E_NIHWs(ii) = E_tot_NIHW;
        E_HFLWs(ii) = E_tot_HFLW;
        E_HFHWs(ii) = E_tot_HFHW;
        Tev_NIHWs(ii) = Tev_NIHW;
        Tev_HFLWs(ii) = Tev_HFLW;
        Tev_HFHWs(ii) = Tev_HFHW;
        Tres_NILWs(ii) = Tres_NILW;
        Tres_NIHWs(ii) = Tres_NIHW;
        Tres_HFLWs(ii) = Tres_HFLW;
        Tres_HFHWs(ii) = Tres_HFHW;
        Tres_tots(ii)  = Tres_tot;
        %pause
        
    end
    end
    toc
    CC = CC+j_max
    
    continuum_slopes = [continuum_slopes,continuum_slope];
    NI_slopes = [NI_slopes,NI_slope];
    mslopes = [mslopes,mslope];
    mEs = [mEs,mE];
    mstars = [mstars,mstar];
    epsilons1 = [epsilons1,DissipatedPowers_e1];
    epsilons2 = [epsilons2,DissipatedPowers_e2];
    Pbudget_NIHWss = [Pbudget_NIHWss,Pbudget_NIHWs];
    Pbudget_HFLWss = [Pbudget_HFLWss,Pbudget_HFLWs];
    Pbudget_HFHWss = [Pbudget_HFHWss,Pbudget_HFHWs];
    Pout_NILWss = [Pout_NILWss,Pout_NILWs];
    Pout_NIHWss = [Pout_NIHWss,Pout_NIHWs];
    Pout_HFLWss = [Pout_HFLWss,Pout_HFLWs];
    Pout_HFHWss = [Pout_HFHWss,Pout_HFHWs];
    E_NILWss    = [E_NILWss,E_NILWs];
    E_NIHWss    = [E_NIHWss,E_NIHWs];
    E_HFLWss    = [E_HFLWss,E_HFLWs];
    E_HFHWss    = [E_HFHWss,E_HFHWs];
    Tev_NIHWss  = [Tev_NIHWss,Tev_NIHWs];
    Tev_HFLWss  = [Tev_HFLWss,Tev_HFLWs];
    Tev_HFHWss  = [Tev_HFHWss,Tev_HFHWs];
    Tres_NILWss = [Tres_NILWss,Tres_NILWs];
    Tres_NIHWss = [Tres_NIHWss,Tres_NIHWs];
    Tres_HFLWss = [Tres_HFLWss,Tres_HFLWs];
    Tres_HFHWss = [Tres_HFHWss,Tres_HFHWs];
    Tres_totss  = [Tres_totss,Tres_tots];
    
    %pause
    end
end

%save all data in structure Stat.all

Stat.all.I               = Scount;
Stat.all.lat             = Slatitude;
Stat.all.lon             = Slongitude;
Stat.all.idepth          = Sidepth;
Stat.all.sfdepth         = Ssfdepth;
Stat.all.f               = Sf;
Stat.all.N               = Sn;
Stat.all.timespec        = Stimespec;
Stat.all.yday            = Syday;
Stat.all.NIslope         = NI_slopes;
Stat.all.continuum_slope = continuum_slopes;
Stat.all.mslope          = mslopes;
Stat.all.mE              = mEs;
Stat.all.mstar           = mstars;
Stat.all.e0              = Se0;
Stat.all.e0new           = Se0new;
Stat.all.epsilon1        = epsilons1; %estimate with only vertical transport
Stat.all.epsilon2        = epsilons2; % estimate with both vertical and horizontal transport
Stat.all.Pbudget_NIHW = Pbudget_NIHWss;
Stat.all.Pbudget_HFLW = Pbudget_HFLWss;
Stat.all.Pbudget_HFHW = Pbudget_HFHWss;
Stat.all.Pout_NILW = Pout_NILWss;
Stat.all.Pout_NIHW = Pout_NIHWss;
Stat.all.Pout_HFLW = Pout_HFLWss;
Stat.all.Pout_HFHW = Pout_HFHWss;
Stat.all.E_NILW    = E_NILWss;
Stat.all.E_NIHW    = E_NIHWss;
Stat.all.E_HFLW    = E_HFLWss;
Stat.all.E_HFHW    = E_HFHWss;
Stat.all.Tev_NIHW  = Tev_NIHWss;
Stat.all.Tev_HFLW  = Tev_HFLWss;
Stat.all.Tev_HFHW  = Tev_HFHWss;
Stat.all.Tres_NILW = Tres_NILWss;
Stat.all.Tres_NIHW = Tres_NIHWss;
Stat.all.Tres_HFLW = Tres_HFLWss;
Stat.all.Tres_HFHW = Tres_HFHWss;
Stat.all.Tres_tot  = Tres_totss;

save('Statistics_timescales_Gio_N0_mstar_correction.mat','Stat');

toc