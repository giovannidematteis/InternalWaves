function Fi = interpolant(y,s,Fs,params)
%INTERPOLANT given (y, s), the high freq and near inertial scalings of a
% certain spectrum, the function interpolates each component of
% the flux matrix (normalized by KE^2) at point (y, s) based on knowing the
% components on a 25-point grid

% ys = [1.4,1.69,2.];
% ss = [0.5,1.,1.45,1.85];
% [Ys,Ss] = meshgrid(ys,ss);

% ['v5a','v5b','v5c','v5d','v7a','v4a','v4b','v2a','v4c','v7b','v1a','v1c',
%  'v0','v1b','v7c','v3','v3a','v2b','v3b','v7d','v6a','v6b','v6c','v6d','v7e']

yss = [1.1,1.1,1.1,1.1,1.1,1.4,1.4,1.4,1.4,1.4,1.69,1.69,1.69,1.69,1.69,2,2,2,2,2,2.3,2.3,2.3,2.3,2.3]';
sss = [.5,1.,1.45,1.85,2.2,.5,1.,1.45,1.85,2.2,.5,1.,1.45,1.85,2.2,.5,1.,1.45,1.85,2.2,.5,1.,1.45,1.85,2.2]';

Fi = zeros(9,9);

for i=1:9
    for j=1:9
        count = ((1:25)-1)*9 + i;
        Fss = Fs(count,j);
        F = scatteredInterpolant(yss,sss,Fss,'natural','nearest');
        Fi(i,j) = F(y,s);
        %griddata(yss,sss,Fss,y,s,'linear');
    end
end

end