function IntegrandT = IntegrandTf0(k,k2,k3,n1,params)
    m = params.m;
    f = params.f;
    
    
    [m2,m3] = m1a(k,k2,k3,params);
    n2 = GM(k2,m2,params);
    n3 = GM(k3,m3,params);
    R1a = k*k2*k3*abs(V123(k,k2,k3,m,m2,m3))^2*f123(k,k2,k3,n1,n2,n3,params)/(g_abs(k2,k3,m2,m3,f));
    [m2,m3] = m1b(k,k2,k3,params);
    n2 = GM(k2,m2,params);
    n3 = GM(k3,m3,params);
    R1b = k*k2*k3*abs(V123(k,k2,k3,m,m2,m3))^2*f123(k,k2,k3,n1,n2,n3,params)/(g_abs(k2,k3,m2,m3,f));
    [m2,m3] = m2a(k,k2,k3,params);
    n2 = GM(k2,m2,params);
    n3 = GM(k3,m3,params);
    R2a = k*k2*k3*abs(V213(k,k2,k3,m,m2,m3))^2*f123(k2,k,k3,n2,n1,n3,params)/(g_abs(k2,k3,m2,m3,f));
    [m2,m3] = m2b(k,k2,k3,params);
    n2 = GM(k2,m2,params);
    n3 = GM(k3,m3,params);
    R2b = k*k2*k3*abs(V213(k,k2,k3,m,m2,m3))^2*f123(k2,k,k3,n2,n1,n3,params)/(g_abs(k2,k3,m2,m3,f));
    [m2,m3] = m3a(k,k2,k3,params);
    n2 = GM(k2,m2,params);
    n3 = GM(k3,m3,params);
    R3a = k*k2*k3*abs(V312(k,k2,k3,m,m2,m3))^2*f123(k3,k,k2,n3,n1,n2,params)/(g_abs(k2,k3,m2,m3,f));
    [m2,m3] = m3b(k,k2,k3,params);
    n2 = GM(k2,m2,params);
    n3 = GM(k3,m3,params);
    R3b = k*k2*k3*abs(V312(k,k2,k3,m,m2,m3))^2*f123(k3,k,k2,n3,n1,n2,params)/(g_abs(k2,k3,m2,m3,f));
    IntegrandT = - R2b - R3b + R1a - R2a - R3a + R1b;
end