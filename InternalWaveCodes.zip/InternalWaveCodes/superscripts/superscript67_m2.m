% The code runs the scripts compute_fluxes and compute_fluxes_low_freq
% for the 25 points of the (y,s) grid at a given value of the aspect ratio
% N/f;

%% Modified on 8/29/2023 to discern bt/ local vs nonlocal contributions

AR = 66.7978; %40;

ys       = [2]; %   High frequency slope  [1.69];%[1.1,1.1,1.1 ,1.1 ,1.1,1.4,1.4,1.4 ,1.4 ,1.4,1.69,1.69,1.69,1.69,1.69,2   ,2   ,2   ,2   ,2   ,2.3 ,2.3 ,2.3 ,2.3 ,2.3 ]; %load('super-y'); %[1.69];
ss       = [1.45];% Near Inertial slope   [0.5];%[0.5,1  ,1.45,1.85,2.2,0.5,1  ,1.45,1.85,2.2,0.5 ,1   ,1.45,1.85,2.2 ,0.5 ,1   ,1.45,1.85,2.2 ,0.5 ,1   ,1.45,1.85,2.2 ]; %load('super-s'); %[1.445];
nus      = 4 - (ys + 2) ;
mus      = 2*ss + nus - 1;
names_hf_loc = {'NDOTS-r4-NIloc-1a-hf','NDOTS-r4-NIloc-1b-hf','NDOTS-r4-NIloc-2a-hf','NDOTS-r4-NIloc-2b-hf','NDOTS-r4-NIloc-3a-hf','NDOTS-r4-NIloc-3b-hf'};%{'NDOTS-n10-r4-v5a-ar67-m2','NDOTS-n10-r4-v5b-ar67-m2','NDOTS-n10-r4-v5c-ar67-m2','NDOTS-n10-r4-v5d-ar67-m2','NDOTS-n10-r4-v7a-ar67-m2','NDOTS-n10-r4-v4a-ar67-m2','NDOTS-n10-r4-v4b-ar67-m2','NDOTS-n10-r4-v2a-ar67-m2','NDOTS-n10-r4-v4c-ar67-m2','NDOTS-n10-r4-v7b-ar67-m2','NDOTS-n10-r4-v1a-ar67-m2','NDOTS-n10-r4-v1c-ar67-m2','NDOTS-n10-r4-v0-ar67-m2','NDOTS-n10-r4-v1b-ar67-m2','NDOTS-n10-r4-v7c-ar67-m2','NDOTS-n10-r4-v3-ar67-m2','NDOTS-n10-r4-v3a-ar67-m2','NDOTS-n10-r4-v2b-ar67-m2','NDOTS-n10-r4-v3b-ar67-m2','NDOTS-n10-r4-v7d-ar67-m2','NDOTS-n10-r4-v6a-ar67-m2','NDOTS-n10-r4-v6b-ar67-m2','NDOTS-n10-r4-v6c-ar67-m2','NDOTS-n10-r4-v6d-ar67-m2','NDOTS-n10-r4-v7e-ar67-m2'}; %load('super-names-hf'); %{'NDOTS-n10-r4-v0-ar21'};
names_lf_loc = {'NDOTS-r4-NIloc-1a-lf','NDOTS-r4-NIloc-1b-lf','NDOTS-r4-NIloc-2a-lf','NDOTS-r4-NIloc-2b-lf','NDOTS-r4-NIloc-3a-lf','NDOTS-r4-NIloc-3b-lf'};%{'NDOTS-n10-r4-v5a-ar67-m2-lf','NDOTS-n10-r4-v5b-ar67-m2-lf','NDOTS-n10-r4-v5c-ar67-m2-lf','NDOTS-n10-r4-v5d-ar67-m2-lf','NDOTS-n10-r4-v7a-ar67-m2-lf','NDOTS-n10-r4-v4a-ar67-m2-lf','NDOTS-n10-r4-v4b-ar67-m2-lf','NDOTS-n10-r4-v2a-ar67-m2-lf','NDOTS-n10-r4-v4c-ar67-m2-lf','NDOTS-n10-r4-v7b-ar67-m2-lf','NDOTS-n10-r4-v1a-ar67-m2-lf','NDOTS-n10-r4-v1c-ar67-m2-lf','NDOTS-n10-r4-v0-ar67-m2-lf','NDOTS-n10-r4-v1b-ar67-m2-lf','NDOTS-n10-r4-v7c-ar67-m2-lf','NDOTS-n10-r4-v3-ar67-m2-lf','NDOTS-n10-r4-v3a-ar67-m2-lf','NDOTS-n10-r4-v2b-ar67-m2-lf','NDOTS-n10-r4-v3b-ar67-m2-lf','NDOTS-n10-r4-v7d-ar67-m2-lf','NDOTS-n10-r4-v6a-ar67-m2-lf','NDOTS-n10-r4-v6b-ar67-m2-lf','NDOTS-n10-r4-v6c-ar67-m2-lf','NDOTS-n10-r4-v6d-ar67-m2-lf','NDOTS-n10-r4-v7e-ar67-m2-lf'}; %load('super-names-hf'); %{'NDOTS-n19-r4-v0-ar21-lf'};
names_hf_nloc = {'NDOTS-r4-NInloc-1a-hf','NDOTS-r4-NInloc-1b-hf','NDOTS-r4-NInloc-2a-hf','NDOTS-r4-NInloc-2b-hf','NDOTS-r4-NInloc-3a-hf','NDOTS-r4-NInloc-3b-hf'};%{'NDOTS-n10-r4-v5a-ar67-m2','NDOTS-n10-r4-v5b-ar67-m2','NDOTS-n10-r4-v5c-ar67-m2','NDOTS-n10-r4-v5d-ar67-m2','NDOTS-n10-r4-v7a-ar67-m2','NDOTS-n10-r4-v4a-ar67-m2','NDOTS-n10-r4-v4b-ar67-m2','NDOTS-n10-r4-v2a-ar67-m2','NDOTS-n10-r4-v4c-ar67-m2','NDOTS-n10-r4-v7b-ar67-m2','NDOTS-n10-r4-v1a-ar67-m2','NDOTS-n10-r4-v1c-ar67-m2','NDOTS-n10-r4-v0-ar67-m2','NDOTS-n10-r4-v1b-ar67-m2','NDOTS-n10-r4-v7c-ar67-m2','NDOTS-n10-r4-v3-ar67-m2','NDOTS-n10-r4-v3a-ar67-m2','NDOTS-n10-r4-v2b-ar67-m2','NDOTS-n10-r4-v3b-ar67-m2','NDOTS-n10-r4-v7d-ar67-m2','NDOTS-n10-r4-v6a-ar67-m2','NDOTS-n10-r4-v6b-ar67-m2','NDOTS-n10-r4-v6c-ar67-m2','NDOTS-n10-r4-v6d-ar67-m2','NDOTS-n10-r4-v7e-ar67-m2'}; %load('super-names-hf'); %{'NDOTS-n10-r4-v0-ar21'};
names_lf_nloc = {'NDOTS-r4-NInloc-1a-lf','NDOTS-r4-NInloc-1b-lf','NDOTS-r4-NInloc-2a-lf','NDOTS-r4-NInloc-2b-lf','NDOTS-r4-NInloc-3a-lf','NDOTS-r4-NInloc-3b-lf'};%{'NDOTS-n10-r4-v5a-ar67-m2-lf','NDOTS-n10-r4-v5b-ar67-m2-lf','NDOTS-n10-r4-v5c-ar67-m2-lf','NDOTS-n10-r4-v5d-ar67-m2-lf','NDOTS-n10-r4-v7a-ar67-m2-lf','NDOTS-n10-r4-v4a-ar67-m2-lf','NDOTS-n10-r4-v4b-ar67-m2-lf','NDOTS-n10-r4-v2a-ar67-m2-lf','NDOTS-n10-r4-v4c-ar67-m2-lf','NDOTS-n10-r4-v7b-ar67-m2-lf','NDOTS-n10-r4-v1a-ar67-m2-lf','NDOTS-n10-r4-v1c-ar67-m2-lf','NDOTS-n10-r4-v0-ar67-m2-lf','NDOTS-n10-r4-v1b-ar67-m2-lf','NDOTS-n10-r4-v7c-ar67-m2-lf','NDOTS-n10-r4-v3-ar67-m2-lf','NDOTS-n10-r4-v3a-ar67-m2-lf','NDOTS-n10-r4-v2b-ar67-m2-lf','NDOTS-n10-r4-v3b-ar67-m2-lf','NDOTS-n10-r4-v7d-ar67-m2-lf','NDOTS-n10-r4-v6a-ar67-m2-lf','NDOTS-n10-r4-v6b-ar67-m2-lf','NDOTS-n10-r4-v6c-ar67-m2-lf','NDOTS-n10-r4-v6d-ar67-m2-lf','NDOTS-n10-r4-v7e-ar67-m2-lf'}; %load('super-names-hf'); %{'NDOTS-n19-r4-v0-ar21-lf'};


params.f = sin(32.5*pi/180)*2*7.3*10^-5;
params.N = params.f*AR;

for i = 1:length(ys)
    i
    params.name_hf_loc = names_hf_loc;
    params.name_lf_loc = names_lf_loc;
    params.name_hf_nloc = names_hf_nloc;
    params.name_lf_nloc = names_lf_nloc;
    params.nu = nus(i);
    params.mu = mus(i);
    params.z  = 2; %(5+ys(i))/3;
    tic
    compute_fluxes_fun(params)
    toc
    
    tic
    compute_fluxes_low_freq_fun(params)
    toc
    %pause
end