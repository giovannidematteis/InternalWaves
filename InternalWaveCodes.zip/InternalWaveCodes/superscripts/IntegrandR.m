function [I1a,I1b,I2a,I2b,I3a,I3b,I1an,I1bn,I2an,I2bn,I3an,I3bn] = IntegrandR(k,k2,k3,m,n,mB,MB,oB,OB,params)
    f = params.f;
    N = params.N;%*1.25;
    alpha = params.alpha;
    %m_max = params.m_max;
    %m_min = params.m_min;
    %m_cut = m_max*20;
    
    R1a = 0;
    R1b = 0;
    R2a = 0;
    R2b = 0;
    R3a = 0;
    R3b = 0;
    R1an = 0;
    R1bn = 0;
    R2an = 0;
    R2bn = 0;
    R3an = 0;
    R3bn = 0;

    options = optimset('FunValCheck', 'off', 'Display','off');
  
    %[m2,m3] = m1a(k2,k3,params);
    [m2_0,m3_0] = m1a(k,k2,k3,m,params);
    fun = @(x) m_solve1(x,k2,k3,k,m,f,alpha);   % function of x alone
    m2 = fzero(fun,m2_0,options);
    m3 = m - m2;
%     m2 = m2_0;%fzero(fun,m2_0);
%     m3 = m3_0;%m - m2;
    om = sqrt(f^2 + alpha^2*k^2/m^2);
    om2 = sqrt(f^2 + alpha^2*k2^2/m2^2);
    om3 = sqrt(f^2 + alpha^2*k3^2/m3^2);
    if (om>N || om2>N || om3>N) % out of bounds
        R1a = 0;
        R1an = 0;
    else
        if((abs(m2)>mB && abs(m2)<MB && om2>oB && om2<OB) && (abs(m3)<mB || abs(m3)>MB || om3<oB || om3>OB))
            n2 = GM(k2,m2,params);
            n3 = GM(k3,m3,params);
            R1a = (om2/om)*k*k2*k3*Vsq123(k,k2,k3,om,om2,om3,f)*f123(k,k2,k3,n,n2,n3,params)/(g_abs(k2,k3,m2,m3,params)*Delta123(k,k2,k3));
        end
        if((abs(m3)>mB && abs(m3)<MB && om3>oB && om3<OB) && (abs(m2)<mB || abs(m2)>MB || om2<oB || om2>OB))
            n2 = GM(k2,m2,params);
            n3 = GM(k3,m3,params);
            R1a = (om3/om)*k*k2*k3*Vsq123(k,k2,k3,om,om2,om3,f)*f123(k,k2,k3,n,n2,n3,params)/(g_abs(k2,k3,m2,m3,params)*Delta123(k,k2,k3));
        end
        if((abs(m2)>mB && abs(m2)<MB && om2>oB && om2<OB) && (abs(m3)>mB && abs(m3)<MB && om3>oB && om3<OB))
            n2 = GM(k2,m2,params);
            n3 = GM(k3,m3,params);
            R1a = 1*k*k2*k3*Vsq123(k,k2,k3,om,om2,om3,f)*f123(k,k2,k3,n,n2,n3,params)/(g_abs(k2,k3,m2,m3,params)*Delta123(k,k2,k3));
        end
        if (isnan(m2))
            R1a = 0;
        end
    end
    if( ((abs(m2)/abs(m))<0.25) || ((abs(m2)/abs(m))>4) || ((abs(m3)/abs(m))<0.25) || ((abs(m3)/abs(m))>4) || ((om2/om)<0.25) || ((om2/om)>4) || ((om3/om)<0.25) || ((om3/om)>4) )
        R1an = R1a;
        R1a  = 0;
    end
    %[m2,m3] = m1b(k2,k3,params);
    [m2_0,m3_0] = m1b(k,k2,k3,m,params);
    fun = @(x) m_solve1(x,k2,k3,k,m,f,alpha);   % function of x alone
    m2 = fzero(fun,m2_0,options);
    m3 = m - m2;
%     m2 = m2_0;%fzero(fun,m2_0);
%     m3 = m3_0;%m - m3;
    %om = sqrt(f^2 + alpha^2*k^2/m^2);
    om2 = sqrt(f^2 + alpha^2*k2^2/m2^2);
    om3 = sqrt(f^2 + alpha^2*k3^2/m3^2);
    if (om>N || om2>N || om3>N) % out of bounds
        R1b = 0;
        R1bn = 0;
    else
        if((abs(m2)>mB && abs(m2)<MB && om2>oB && om2<OB) && (abs(m3)<mB || abs(m3)>MB || om3<oB || om3>OB))
            n2 = GM(k2,m2,params);
            n3 = GM(k3,m3,params);
            R1b = (om2/om)*k*k2*k3*Vsq123(k,k2,k3,om,om2,om3,f)*f123(k,k2,k3,n,n2,n3,params)/(g_abs(k2,k3,m2,m3,params)*Delta123(k,k2,k3));
        end
        if((abs(m2)<mB || abs(m2)>MB || om2<oB || om2>OB) && (abs(m3)>mB && abs(m3)<MB && om3>oB && om3<OB))
            n2 = GM(k2,m2,params);
            n3 = GM(k3,m3,params);
            R1b = (om3/om)*k*k2*k3*Vsq123(k,k2,k3,om,om2,om3,f)*f123(k,k2,k3,n,n2,n3,params)/(g_abs(k2,k3,m2,m3,params)*Delta123(k,k2,k3));
        end
        if((abs(m2)>mB && abs(m2)<MB && om2>oB && om2<OB) && (abs(m3)>mB && abs(m3)<MB && om3>oB && om3<OB))
            n2 = GM(k2,m2,params);
            n3 = GM(k3,m3,params);
            R1b = 1*k*k2*k3*Vsq123(k,k2,k3,om,om2,om3,f)*f123(k,k2,k3,n,n2,n3,params)/(g_abs(k2,k3,m2,m3,params)*Delta123(k,k2,k3));
        end
        if (isnan(m2))
            R1b = 0;
        end
    end
    if( ((abs(m2)/abs(m))<0.25) || ((abs(m2)/abs(m))>4) || ((abs(m3)/abs(m))<0.25) || ((abs(m3)/abs(m))>4) || ((om2/om)<0.25) || ((om2/om)>4) || ((om3/om)<0.25) || ((om3/om)>4) )
        R1bn = R1b;
        R1b  = 0;
    end
    %[m2,m3] = m2a(k2,k3,params);
    [m2_0,m3_0] = m2a(k,k2,k3,m,params);
    fun = @(x) m_solve2(x,k2,k3,k,m,f,alpha);   % function of x alone
    m2 = fzero(fun,m2_0,options);
    m3 = m2 - m;
%     m2 = m2_0;%fzero(fun,m2_0);
%     m3 = m3_0;%m - m3;
    %om = sqrt(f^2 + alpha^2*k^2/m^2);
    om2 = sqrt(f^2 + alpha^2*k2^2/m2^2);
    om3 = sqrt(f^2 + alpha^2*k3^2/m3^2);
    if (om>N || om2>N || om3>N) % out of bounds
        R2a = 0;
        R2an = 0;
    else
        if((abs(m2)>mB && abs(m2)<MB && om2>oB && om2<OB))
            n2 = GM(k2,m2,params);
            n3 = GM(k3,m3,params);
            R2a = k*k2*k3*Vsq213(k,k2,k3,om,om2,om3,f)*f123(k2,k,k3,n2,n,n3,params)/(g_abs(k2,k,m2,m,params)*Delta123(k,k2,k3));
        end
        if (isnan(m2))
            R2a = 0;
        end
    end
    if( ((abs(m2)/abs(m))<0.25) || ((abs(m2)/abs(m))>4) || ((abs(m3)/abs(m))<0.25) || ((abs(m3)/abs(m))>4) || ((om2/om)<0.25) || ((om2/om)>4) || ((om3/om)<0.25) || ((om3/om)>4) )
        R2an = R2a;
        R2a  = 0;
    end
        %[m2,m3] = m2b(k2,k3,params);
    [m2_0,m3_0] = m2b(k,k2,k3,m,params);
    fun = @(x) m_solve2(x,k2,k3,k,m,f,alpha);   % function of x alone
    m2 = fzero(fun,m2_0,options);
    m3 = m2 - m;
%     m2 = m2_0;%fzero(fun,m2_0);
%     m3 = m3_0;%m - m3;
    %om = sqrt(f^2 + alpha^2*k^2/m^2);
    om2 = sqrt(f^2 + alpha^2*k2^2/m2^2);
    om3 = sqrt(f^2 + alpha^2*k3^2/m3^2);
    if (om>N || om2>N || om3>N) % out of bounds
        R2b = 0;
        R2bn = 0;
    else
        if((abs(m2)>mB && abs(m2)<MB && om2>oB && om2<OB))
            n2 = GM(k2,m2,params);
            n3 = GM(k3,m3,params);
            R2b = k*k2*k3*Vsq213(k,k2,k3,om,om2,om3,f)*f123(k2,k,k3,n2,n,n3,params)/(g_abs(k2,k,m2,m,params)*Delta123(k,k2,k3));
        end
        if (isnan(m2))
            R2b = 0;
        end
    end
    if( ((abs(m2)/abs(m))<0.25) || ((abs(m2)/abs(m))>4) || ((abs(m3)/abs(m))<0.25) || ((abs(m3)/abs(m))>4) || ((om2/om)<0.25) || ((om2/om)>4) || ((om3/om)<0.25) || ((om3/om)>4) )
        R2bn = R2b;
        R2b  = 0;
    end
    %[m2,m3] = m3a(k2,k3,params);
    [m2_0,m3_0] = m3a(k,k2,k3,m,params);
    fun = @(x) m_solve3(x,k2,k3,k,m,f,alpha);   % function of x alone
    m2 = fzero(fun,m2_0,options);
    m3 = m + m2;
%     m2 = m2_0;%fzero(fun,m2_0);
%     m3 = m3_0;%m - m3;
    %om = sqrt(f^2 + alpha^2*k^2/m^2);
    om2 = sqrt(f^2 + alpha^2*k2^2/m2^2);
    om3 = sqrt(f^2 + alpha^2*k3^2/m3^2);
    if (om>N || om2>N || om3>N) % out of bounds
        R3a = 0;
        R3an = 0;
    else
        if((abs(m3)>mB && abs(m3)<MB && om3>oB && om3<OB))
            n2 = GM(k2,m2,params);
            n3 = GM(k3,m3,params);
            R3a = k*k2*k3*Vsq312(k,k2,k3,om,om2,om3,f)*f123(k3,k,k2,n3,n,n2,params)/(g_abs(k,k3,m,m3,params)*Delta123(k,k2,k3));
        end
        if (isnan(m2))
            R3a = 0;
        end
    end
    if( ((abs(m2)/abs(m))<0.25) || ((abs(m2)/abs(m))>4) || ((abs(m3)/abs(m))<0.25) || ((abs(m3)/abs(m))>4) || ((om2/om)<0.25) || ((om2/om)>4) || ((om3/om)<0.25) || ((om3/om)>4) )
        R3an = R3a;
        R3a  = 0;
    end
    %[m2,m3] = m3b(k2,k3,params);
    [m2_0,m3_0] = m3b(k,k2,k3,m,params);
    fun = @(x) m_solve3(x,k2,k3,k,m,f,alpha);   % function of x alone
    m2 = fzero(fun,m2_0,options);
    m3 = m + m2;
%     m2 = m2_0;%fzero(fun,m2_0);
%     m3 = m3_0;%m - m3;
    %om = sqrt(f^2 + alpha^2*k^2/m^2);
    om2 = sqrt(f^2 + alpha^2*k2^2/m2^2);
    om3 = sqrt(f^2 + alpha^2*k3^2/m3^2);
    if (om>N || om2>N || om3>N) % out of bounds
        R3b = 0;
        R3bn = 0;
    else
        if((abs(m3)>mB && abs(m3)<MB && om3>oB && om3<OB))
            n2 = GM(k2,m2,params);
            n3 = GM(k3,m3,params);
            R3b = k*k2*k3*Vsq312(k,k2,k3,om,om2,om3,f)*f123(k3,k,k2,n3,n,n2,params)/(g_abs(k,k3,m,m3,params)*Delta123(k,k2,k3));
        end
        if (isnan(m2))
            R3b = 0;
        end
    end
    if( ((abs(m2)/abs(m))<0.25) || ((abs(m2)/abs(m))>4) || ((abs(m3)/abs(m))<0.25) || ((abs(m3)/abs(m))>4) || ((om2/om)<0.25) || ((om2/om)>4) || ((om3/om)<0.25) || ((om3/om)>4) )
        R3bn = R3b;
        R3b  = 0;
    end
    %  I   = - R2b - R3b + R1a - R2a + R1b - R3a;
    I1a = + R1a;
    I1b = + R1b;
    I2a = - R2a;
    I2b = - R2b;
    I3a = - R3a;
    I3b = - R3b;
    I1an = + R1an;
    I1bn = + R1bn;
    I2an = - R2an;
    I2bn = - R2bn;
    I3an = - R3an;
    I3bn = - R3bn;
end