function IntegrandR = IntegrandRcond(k,k2,k3,m,n,mB,MB,oB,OB,params)
    f = params.f;
    %N = params.N*1.25;
    %m_min = params.m_min;
    %m_max = params.m_max;
    alpha = params.alpha;
    %m_cut = m_max*20;
    
    R1a = 0;
    R1b = 0;
    R2a = 0;
    R2b = 0;
    R3a = 0;
    R3b = 0;
    
    options = optimset('FunValCheck', 'off', 'Display','off');
    
    %[m2,m3] = m1a(k2,k3,params);
    [m2_0,m3_0] = m1a(k,k2,k3,m,params);
    fun = @(x) m_solve1(x,k2,k3,k,m,f,alpha);   % function of x alone
    m2 = fzero(fun,m2_0,options);
    m3 = m - m2;
    
    fun = @(x) m_solve1(x,k2,abs(k2-k),k,m,f,alpha);   % function of x alone
    m2c = fzero(fun,m2_0,optimset('FunValCheck', 'off', 'Display','off'));
    m3c = m - m2;
    om2c = sqrt(f^2 + alpha^2*k2^2/m2c^2);
    om3c = sqrt(f^2 + alpha^2*(k2-k)^2/m3c^2);
%     m2 = m2_0;%fzero(fun,m2_0);
%     m3 = m3_0;%m - m2;
    om = sqrt(f^2 + alpha^2*k^2/m^2);
    om2 = sqrt(f^2 + alpha^2*k2^2/m2^2);
    om3 = sqrt(f^2 + alpha^2*k3^2/m3^2);
    if((abs(m2)>mB && abs(m2)<MB && om2c>oB && om2c<OB) && (abs(m3)<mB || abs(m3)>MB || om3c<oB || om3c>OB))
        n2 = GM(k2,m2,params);
        n3 = GM(k3,m3,params);
        R1a = (om2/om)*k*k2*k3*Vsq123(k,k2,k3,om,om2,om3,f)*f123(k,k2,k3,n,n2,n3,params)/(g_abs(k2,k3,m2,m3,params)*Delta123(k,k2,k3));
    end
    if((abs(m3)>mB && abs(m3)<MB && om3c>oB && om3c<OB) && (abs(m2)<mB || abs(m2)>MB || om2c<oB || om2c>OB))
        n2 = GM(k2,m2,params);
        n3 = GM(k3,m3,params);
        R1a = (om3/om)*k*k2*k3*Vsq123(k,k2,k3,om,om2,om3,f)*f123(k,k2,k3,n,n2,n3,params)/(g_abs(k2,k3,m2,m3,params)*Delta123(k,k2,k3));
    end
    if((abs(m2)>mB && abs(m2)<MB && om2c>oB && om2c<OB) && (abs(m3)>mB && abs(m3)<MB && om3c>oB && om3c<OB))
        n2 = GM(k2,m2,params);
        n3 = GM(k3,m3,params);
        R1a = 1*k*k2*k3*Vsq123(k,k2,k3,om,om2,om3,f)*f123(k,k2,k3,n,n2,n3,params)/(g_abs(k2,k3,m2,m3,params)*Delta123(k,k2,k3));
    end
    if (isnan(m2))
        R1a = 0;
    end
    %[m2,m3] = m1b(k2,k3,params);
    [m2_0,m3_0] = m1b(k,k2,k3,m,params);
    fun = @(x) m_solve1(x,k2,k3,k,m,f,alpha);   % function of x alone
    m2 = fzero(fun,m2_0,options);
    m3 = m - m2;
    
    fun = @(x) m_solve1(x,k2,abs(k2-k),k,m,f,alpha);   % function of x alone
    m2c = fzero(fun,m2_0,optimset('FunValCheck', 'off', 'Display','off'));
    m3c = m - m2;
    om2c = sqrt(f^2 + alpha^2*k2^2/m2c^2);
    om3c = sqrt(f^2 + alpha^2*(k2-k)^2/m3c^2);
%     m2 = m2_0;%fzero(fun,m2_0);
%     m3 = m3_0;%m - m3;
    %om = sqrt(f^2 + alpha^2*k^2/m^2);
    om2 = sqrt(f^2 + alpha^2*k2^2/m2^2);
    om3 = sqrt(f^2 + alpha^2*k3^2/m3^2);
    if((abs(m2)>mB && abs(m2)<MB && om2c>oB && om2c<OB) && (abs(m3)<mB || abs(m3)>MB || om3c<oB || om3c>OB))
        n2 = GM(k2,m2,params);
        n3 = GM(k3,m3,params);
        R1b = (om2/om)*k*k2*k3*Vsq123(k,k2,k3,om,om2,om3,f)*f123(k,k2,k3,n,n2,n3,params)/(g_abs(k2,k3,m2,m3,params)*Delta123(k,k2,k3));
    end
    if((abs(m2)<mB || abs(m2)>MB || om2c<oB || om2c>OB) && (abs(m3)>mB && abs(m3)<MB && om3c>oB && om3c<OB))
        n2 = GM(k2,m2,params);
        n3 = GM(k3,m3,params);
        R1b = (om3/om)*k*k2*k3*Vsq123(k,k2,k3,om,om2,om3,f)*f123(k,k2,k3,n,n2,n3,params)/(g_abs(k2,k3,m2,m3,params)*Delta123(k,k2,k3));
    end
    if((abs(m2)>mB && abs(m2)<MB && om2c>oB && om2c<OB) && (abs(m3)>mB && abs(m3)<MB && om3c>oB && om3c<OB))
        n2 = GM(k2,m2,params);
        n3 = GM(k3,m3,params);
        R1b = 1*k*k2*k3*Vsq123(k,k2,k3,om,om2,om3,f)*f123(k,k2,k3,n,n2,n3,params)/(g_abs(k2,k3,m2,m3,params)*Delta123(k,k2,k3));
    end
    if (isnan(m2))
        R1b = 0;
    end
    %[m2,m3] = m2a(k2,k3,params);
    [m2_0,m3_0] = m2a(k,k2,k3,m,params);
    fun = @(x) m_solve2(x,k2,k3,k,m,f,alpha);   % function of x alone
    m2 = fzero(fun,m2_0,options);
    m3 = m2 - m;
    
    fun = @(x) m_solve2(x,k2,abs(k2-k),k,m,f,alpha);   % function of x alone
    m2c = fzero(fun,m2_0,optimset('FunValCheck', 'off', 'Display','off'));
    m3c = m - m2;
    om2c = sqrt(f^2 + alpha^2*k2^2/m2c^2);
    om3c = sqrt(f^2 + alpha^2*(k2-k)^2/m3c^2);
%     m2 = m2_0;%fzero(fun,m2_0);
%     m3 = m3_0;%m - m3;
    %om = sqrt(f^2 + alpha^2*k^2/m^2);
    om2 = sqrt(f^2 + alpha^2*k2^2/m2^2);
    om3 = sqrt(f^2 + alpha^2*k3^2/m3^2);
    if((abs(m2)>mB && abs(m2)<MB && om2c>oB && om2c<OB))
        n2 = GM(k2,m2,params);
        n3 = GM(k3,m3,params);
        R2a = k*k2*k3*Vsq213(k,k2,k3,om,om2,om3,f)*f123(k2,k,k3,n2,n,n3,params)/(g_abs(k2,k3,m2,m3,params)*Delta123(k,k2,k3));
    end
    if (isnan(m2))
        R2a = 0;
    end
    %[m2,m3] = m2b(k2,k3,params);
    [m2_0,m3_0] = m2b(k,k2,k3,m,params);
    fun = @(x) m_solve2(x,k2,k3,k,m,f,alpha);   % function of x alone
    m2 = fzero(fun,m2_0,options);
    m3 = m2 - m;
    
    fun = @(x) m_solve2(x,k2,abs(k2-k),k,m,f,alpha);   % function of x alone
    m2c = fzero(fun,m2_0,optimset('FunValCheck', 'off', 'Display','off'));
    m3c = m - m2;
    om2c = sqrt(f^2 + alpha^2*k2^2/m2c^2);
    om3c = sqrt(f^2 + alpha^2*(k2-k)^2/m3c^2);
%     m2 = m2_0;%fzero(fun,m2_0);
%     m3 = m3_0;%m - m3;
    %om = sqrt(f^2 + alpha^2*k^2/m^2);
    om2 = sqrt(f^2 + alpha^2*k2^2/m2^2);
    om3 = sqrt(f^2 + alpha^2*k3^2/m3^2);
    if((abs(m2)>mB && abs(m2)<MB && om2c>oB && om2c<OB))
        n2 = GM(k2,m2,params);
        n3 = GM(k3,m3,params);
        R2b = k*k2*k3*Vsq213(k,k2,k3,om,om2,om3,f)*f123(k2,k,k3,n2,n,n3,params)/(g_abs(k2,k3,m2,m3,params)*Delta123(k,k2,k3));
    end
    if (isnan(m2))
        R2b = 0;
    end
    %[m2,m3] = m3a(k2,k3,params);
    [m2_0,m3_0] = m3a(k,k2,k3,m,params);
    fun = @(x) m_solve3(x,k2,k3,k,m,f,alpha);   % function of x alone
    m2 = fzero(fun,m2_0,options);
    m3 = m + m2;
    
    fun = @(x) m_solve3(x,k2,abs(k2-k),k,m,f,alpha);   % function of x alone
    m2c = fzero(fun,m2_0,optimset('FunValCheck', 'off', 'Display','off'));
    m3c = m - m2;
    om2c = sqrt(f^2 + alpha^2*k2^2/m2c^2);
    om3c = sqrt(f^2 + alpha^2*(k2-k)^2/m3c^2);
%     m2 = m2_0;%fzero(fun,m2_0);
%     m3 = m3_0;%m - m3;
    %om = sqrt(f^2 + alpha^2*k^2/m^2);
    om2 = sqrt(f^2 + alpha^2*k2^2/m2^2);
    om3 = sqrt(f^2 + alpha^2*k3^2/m3^2);
    if((abs(m3)>mB && abs(m3)<MB && om3c>oB && om3c<OB))
        n2 = GM(k2,m2,params);
        n3 = GM(k3,m3,params);
        R3a = k*k2*k3*Vsq312(k,k2,k3,om,om2,om3,f)*f123(k3,k,k2,n3,n,n2,params)/(g_abs(k2,k3,m2,m3,params)*Delta123(k,k2,k3));
    end
    if (isnan(m2))
        R3a = 0;
    end
    %[m2,m3] = m3b(k2,k3,params);
    [m2_0,m3_0] = m3b(k,k2,k3,m,params);
    fun = @(x) m_solve3(x,k2,k3,k,m,f,alpha);   % function of x alone
    m2 = fzero(fun,m2_0,optimset('FunValCheck', 'off', 'Display','off'));
    m3 = m + m2;
    
    fun = @(x) m_solve3(x,k2,abs(k2-k),k,m,f,alpha);   % function of x alone
    m2c = fzero(fun,m2_0,optimset('FunValCheck', 'off', 'Display','off'));
    m3c = m - m2;
    om2c = sqrt(f^2 + alpha^2*k2^2/m2c^2);
    om3c = sqrt(f^2 + alpha^2*(k2-k)^2/m3c^2);
%     m2 = m2_0;%fzero(fun,m2_0);
%     m3 = m3_0;%m - m3;
    %om = sqrt(f^2 + alpha^2*k^2/m^2);
    om2 = sqrt(f^2 + alpha^2*k2^2/m2^2);
    om3 = sqrt(f^2 + alpha^2*k3^2/m3^2);
    if((abs(m3)>mB && abs(m3)<MB && om3c>oB && om3c<OB))
        n2 = GM(k2,m2,params);
        n3 = GM(k3,m3,params);
        R3b = k*k2*k3*Vsq312(k,k2,k3,om,om2,om3,f)*f123(k3,k,k2,n3,n,n2,params)/(g_abs(k2,k3,m2,m3,params)*Delta123(k,k2,k3));
    end
    if (isnan(m2))
        R3b = 0;
    end
    IntegrandR = - R2b - R3b + R1a - R2a + R1b - R3a;
end