function compute_fluxes_fun(params)

%resolution parameter (distance from optimal)
res = 4;

% spectral parameters
%params.nu = -0.3; %commented when running the superscript
%params.mu = 2.4;
params.a = 4-params.nu;
a = params.a;
nu = params.nu;
mu = params.mu;

% physical constants
params.g = 9.8;
%params.f = sin(32.5*pi/180)*2*7.3*10^-5;
%params.N = 0.00524;
params.rho = 1000;
g = params.g;
rho = params.rho;
N = params.N;
N0 = N;
f = params.f;
params.alpha = params.g/params.rho/params.N;
alpha = params.alpha;
params.m_star = 4*pi/1300*g/rho/N^2;
params.m_min = 2*pi/2600*g/rho/N^2;
params.m_max = 2*pi/10*g/rho/N^2;%/5 or /10?%%%%%%%%%%%%%%%%%%%%% tune m_max here: 10 is the standard choice
params.k_min = 2*pi/10^5;
params.k_max = 2*pi/5; %for test
% params.m_min = 0;
% params.m_max = 1000;
% params.k_min = 0;
% params.k_max = 1000;
m_star = params.m_star;
m_min = params.m_min;
m_max = params.m_max;
k_min = params.k_min;
k_max = params.k_max;

E = 6.3*10^-5; %GM energy level (non dimensional)
ell = 10;
c = 3;
b = 1300;
m_starCart = 4*pi/b;
k_star = c*m_starCart*f/N;

% Parameters for spectrum
s = 2*a - 7;
A = E*b^2*rho*f*m_starCart*N0/pi^3/N0/k_star^((1-s)/2);
V0sq = N0^2/32/g; %correct prefactor!!

nM = 10;
nO = nM+1;
NDOTS_loc_1a = zeros(nO,nM,81);
NDOTS_loc_1b = zeros(nO,nM,81);
NDOTS_loc_2a = zeros(nO,nM,81);
NDOTS_loc_2b = zeros(nO,nM,81);
NDOTS_loc_3a = zeros(nO,nM,81);
NDOTS_loc_3b = zeros(nO,nM,81);
NDOTS_nloc_1a = zeros(nO,nM,81);
NDOTS_nloc_1b = zeros(nO,nM,81);
NDOTS_nloc_2a = zeros(nO,nM,81);
NDOTS_nloc_2b = zeros(nO,nM,81);
NDOTS_nloc_3a = zeros(nO,nM,81);
NDOTS_nloc_3b = zeros(nO,nM,81);

%opts = parforOptions(parcluster,'RangePartitionMethod','fixed','SubrangeSize',4);
for cc=1:81
    tic
Input = floor((cc-1)/9);
Output = mod(cc-1,9);

% if(Input==Output)
%     n_dots = zeros(nA,nA);
%     NDOTS((nA*(cc-1)):(nA*cc),:) = n_dots;
%     continue
% end

% Determine boundaries of A and B
ind_i = mod(Input,3);
ind_j = floor(Input/3);
ind_ip = mod(Output,3);
ind_jp = floor(Output/3);
[ind_i,ind_j,ind_ip,ind_jp]

% Define matrices with boundaries
mss = [m_min,20*m_min,m_max,20*m_max];
oss = [1.05*f,5*f,20*f,N0];

mA = mss(ind_i+1);
MA = mss(ind_i+2);
oA = oss(ind_j+1);
OA = oss(ind_j+2);
mB = mss(ind_ip+1);
MB = mss(ind_ip+2);
oB = oss(ind_jp+1);
OB = oss(ind_jp+2);

msA = exp(linspace(log(mA),log(MA),nM));
osA = exp(linspace(log(oA),log(OA),nO));

if (ind_j==0)
    osA = [1.05,1.15,1.40,1.80,2.04,2.13,2.25,2.56,3.20,4,5]*f;
end

[OsA,MsA] = meshgrid(osA,msA);
OsA=OsA';
MsA=MsA';
RsA = sqrt(1./((OsA/f).^2 - 1));
% 
% NDOTS = zeros(nA*81,nA);
% NS = zeros(nA,nA);
% 
% for ii = 1:6

ns = A*(f*MsA./RsA/alpha).^(-4+nu).*(1+RsA.^2).^((mu-3)/2)./(1+(m_star./MsA).^2);

n_dots_loc_1a = zeros(nO,nM);
n_dots_loc_1b = zeros(nO,nM);
n_dots_loc_2a = zeros(nO,nM);
n_dots_loc_2b = zeros(nO,nM);
n_dots_loc_3a = zeros(nO,nM);
n_dots_loc_3b = zeros(nO,nM);
n_dots_nloc_1a = zeros(nO,nM);
n_dots_nloc_1b = zeros(nO,nM);
n_dots_nloc_2a = zeros(nO,nM);
n_dots_nloc_2b = zeros(nO,nM);
n_dots_nloc_3a = zeros(nO,nM);
n_dots_nloc_3b = zeros(nO,nM);
c_om = 0;
c_m = 0;

tic

for m = msA
    if(Input==Output)
        break
    end
    if (ind_j==0 && ind_jp==0)
        break
    end
    if (oA>OA || oB>OB)
        break
    end
    c_m = c_m + 1;
    for om = osA
        c_om = c_om + 1;
        
        r = sqrt(1/((om/f)^2-1));
        k = f*m/alpha/r;
        %k = 1;
        %compute limits
%         kappa_max0 = k_max/k;
%         kappa_max1 = (N/om)^2; % large to take away cutoff
%         kappa_max2 = (m_max/m)^2; %same
%         kappa_max = min([kappa_max0,kappa_max1,kappa_max2]);

        k_L = k/16;
        k_M = k*16;
%         if(kappa_max < 16)
%             k_M = k*kappa_max
%         end
        n = GM(k,m,params);
    
        %pause
    %tic
        % % Integrate over region 2
        N = 11 - res;%target:9;
        N2 = 2^N;
        N2b = 2^3;
        dk2 = k_L/N2b;
        dk = ((k - 2*k_L))/N2; % can be refined
        jx_loop = 1:floor(k_L/dk2);
        I2_loc = zeros(1,6);
        I2_nloc = zeros(1,6);
        for j = 1:(N2)
            k2 = k_L + j*dk;
            i2_loc = zeros(1,6);
            i2_nloc = zeros(1,6);
            for jx = jx_loop
                x = jx*dk2;
                [p1,p2,p3,p4,p5,p6,p7,p8,p9,p10,p11,p12] = IntegrandR(k,k2,k-k2+x,m,n,mB,MB,oB,OB,params);
                IR_loc = [p1,p2,p3,p4,p5,p6];
                IR_nloc = [p7,p8,p9,p10,p11,p12];
                
                %                 
% %                 
%                 %check decomposition into local and nonlocal
%                 [p1c,p2c,p3c,p4c,p5c,p6c] = IntegrandRtot(k,k2,k-k2+x,m,n,mB,MB,oB,OB,params);
%                 IR = [p1c,p2c,p3c,p4c,p5c,p6c];
%                 if(sum(IR)~=0)
%                 IR_loc + IR_nloc
%                 IR
%                 pause
%                 end
%                 
%                 
                
                [p1,p2,p3,p4,p5,p6,p7,p8,p9,p10,p11,p12] = IntegrandT(k,k2,k-k2,m,n,mB,MB,oB,OB,params);
                IT_loc = [p1,p2,p3,p4,p5,p6];
                jj2_loc = IR_loc - IT_loc/(sqrt(2*k*k2*(k-k2)*x));
                i2_loc = i2_loc + jj2_loc;
                IT_nloc = [p7,p8,p9,p10,p11,p12];
                jj2_nloc = IR_nloc - IT_nloc/(sqrt(2*k*k2*(k-k2)*x));
                i2_nloc = i2_nloc + jj2_nloc;
            end
            [p1,p2,p3,p4,p5,p6,p7,p8,p9,p10,p11,p12] = IntegrandT(k,k2,k-k2,m,n,mB,MB,oB,OB,params);
            IT_loc = [p1,p2,p3,p4,p5,p6];
            i2_loc = i2_loc*dk2 + IT_loc*sqrt(2*k_L)/(sqrt(k*k2*(k-k2)));
            I2_loc = I2_loc + i2_loc;
            IT_nloc = [p7,p8,p9,p10,p11,p12];
            i2_nloc = i2_nloc*dk2 + IT_nloc*sqrt(2*k_L)/(sqrt(k*k2*(k-k2)));
            I2_nloc = I2_nloc + i2_nloc;
        %         end
        end
        I2_loc = I2_loc*dk/k;
        I2_nloc = I2_nloc*dk/k;
% toc
% tic
        % Integrate over region 3
        N = 13 - res;%target:13; %vary
        N3 = 2^N;
        N3b = 2^3;
        dk = (k_M - k - k_L)/N3;
        dk2 = k_L/N3b;
        jx_loop = 1:floor(k_L/dk2);
        I3_loc = zeros(1,6);
        I3_nloc = zeros(1,6);
        for j = 1:N3
            k2 = k + k_L + j*dk;
    %         if (k2>k_min+1 && k2<k_max)
                i3_loc = zeros(1,6);
                i3_nloc = zeros(1,6);
                for jx = jx_loop
                    x = jx*dk2;
                    [p1,p2,p3,p4,p5,p6,p7,p8,p9,p10,p11,p12] = IntegrandR(k,k2,k2-k+x,m,n,mB,MB,oB,OB,params);
                    IR_loc = [p1,p2,p3,p4,p5,p6];
                    IR_nloc = [p7,p8,p9,p10,p11,p12];
                    
                    %                 
% %                 
%                 %check decomposition into local and nonlocal
%                 [p1c,p2c,p3c,p4c,p5c,p6c] = IntegrandRtot(k,k2,k-k2+x,m,n,mB,MB,oB,OB,params);
%                 IR = [p1c,p2c,p3c,p4c,p5c,p6c];
%                 if(sum(IR)~=0)
%                 IR_loc + IR_nloc
%                 IR
%                 pause
%                 end
%                 
% %                 
                    
                    [p1,p2,p3,p4,p5,p6,p7,p8,p9,p10,p11,p12] = IntegrandT(k,k2,k2-k,m,n,mB,MB,oB,OB,params);
                    IT_loc = [p1,p2,p3,p4,p5,p6];
                    jj3_loc = IR_loc - IT_loc/(sqrt(2*k*k2*(k2-k)*x));
                    i3_loc = i3_loc + jj3_loc;
                    IT_nloc = [p7,p8,p9,p10,p11,p12];
                    jj3_nloc = IR_nloc - IT_nloc/(sqrt(2*k*k2*(k2-k)*x));
                    i3_nloc = i3_nloc + jj3_nloc;
                end
                [p1,p2,p3,p4,p5,p6,p7,p8,p9,p10,p11,p12] = IntegrandT(k,k2,k2-k,m,n,mB,MB,oB,OB,params);
                IT_loc = [p1,p2,p3,p4,p5,p6];
                i3_loc = i3_loc*dk2 + IT_loc*sqrt(2*k_L)/(sqrt(k*k2*(k2-k)));
                I3_loc = I3_loc + i3_loc;
                IT_nloc = [p7,p8,p9,p10,p11,p12];
                i3_nloc = i3_nloc*dk2 + IT_nloc*sqrt(2*k_L)/(sqrt(k*k2*(k2-k)));
                I3_nloc = I3_nloc + i3_nloc;
    %         end
        end
        I3_loc = I3_loc*dk/k;
        I3_nloc = I3_nloc*dk/k;
% toc
% tic
        % Integrate over region 4a
        N = 10 - res;%target:9;
        dk = k/2^N;
        j1 = floor(k/dk+1);
        j_L = floor(k_L/dk)+1;
        j2_arr = floor((k_L)/dk+1):(k_M/dk);
        j3_arr = floor((k_L)/dk+1):(k_M/dk);
        I4_loc = zeros(1,6);
        I4_nloc = zeros(1,6);
        for j2 = j2_arr
            for j3 = j3_arr
                if (j3 > abs(j1 - j2) + j_L && j3 < j1 && j2 < j1 && j2>j_L)
                    k2 = j2*dk;
                    k3 = j3*dk;
    %                 if (k2>k_min && k2<k_max && k3>k_min && k3<k_max)
                    [p1,p2,p3,p4,p5,p6,p7,p8,p9,p10,p11,p12] = IntegrandR(k,k2,k3,m,n,mB,MB,oB,OB,params);
                    IR_loc = [p1,p2,p3,p4,p5,p6];
                    IR_nloc = [p7,p8,p9,p10,p11,p12];
                    
                    %                 
%                 
%                 %check decomposition into local and nonlocal
%                 [p1c,p2c,p3c,p4c,p5c,p6c] = IntegrandRtot(k,k2,k-k2+x,m,n,mB,MB,oB,OB,params);
%                 IR = [p1c,p2c,p3c,p4c,p5c,p6c];
%                 if(sum(IR)~=0)
%                 IR_loc + IR_nloc
%                 IR
%                 pause
%                 end
%                 
%                 
                    
                    I4_loc = I4_loc + IR_loc;
                    I4_nloc = I4_nloc + IR_nloc;
    %                 end
                end
            end
        end
        I4a_loc = dk^2/k*I4_loc;
        I4a_nloc = dk^2/k*I4_nloc;
% toc
% tic
        % Integrate over region 4b and 4c
        N = 9 - res; %target:9;
        dk = k/2^N;
        j1 = floor(k/dk+1);
        j_L = floor(k_L/dk)+1;
        j2_arr = floor((k_L)/dk+1):(k_M/dk);
        j3_arr = floor((k_L)/dk+1):(k_M/dk);
        I4b_loc = zeros(1,6);
        I4c_loc = zeros(1,6);
        I4b_nloc = zeros(1,6);
        I4c_nloc = zeros(1,6);
        for j2 = j2_arr
            j_Lmov = floor(j2*k_L/k);
            for j3 = j3_arr
                if (j3 > abs(j1 - j2) + j_L && j3 <= abs(j1 - j2) + j_Lmov && j2 > j1 && j2>j_L)
                    k2 = j2*dk;
                    k3 = j3*dk;
    %                 if (k2>k_min && k2<k_max && k3>k_min && k3<k_max)
                    [p1,p2,p3,p4,p5,p6,p7,p8,p9,p10,p11,p12] = IntegrandR(k,k2,k3,m,n,mB,MB,oB,OB,params);
                    IR_loc = [p1,p2,p3,p4,p5,p6];
                    IR_nloc = [p7,p8,p9,p10,p11,p12];
                    
                    %                 
%                 
%                 %check decomposition into local and nonlocal
%                 [p1c,p2c,p3c,p4c,p5c,p6c] = IntegrandRtot(k,k2,k-k2+x,m,n,mB,MB,oB,OB,params);
%                 IR = [p1c,p2c,p3c,p4c,p5c,p6c];
%                 if(sum(IR)~=0)
%                 IR_loc + IR_nloc
%                 IR
%                 pause
%                 end
%                 
%                 
                    
                    I4b_loc = I4b_loc + IR_loc;
                    I4b_nloc = I4b_nloc + IR_nloc;
    %                 end
                end
                if (j3 > abs(j1 - j2)+1 + j_Lmov && j3 < j2 && j2 > j1 && j2>j_L)
                    k2 = j2*dk;
                    k3 = j3*dk;
    %                 if (k2>k_min && k2<k_max && k3>k_min && k3<k_max)
                    [p1,p2,p3,p4,p5,p6,p7,p8,p9,p10,p11,p12] = IntegrandR(k,k2,k3,m,n,mB,MB,oB,OB,params);
                    IR_loc = [p1,p2,p3,p4,p5,p6];
                    IR_nloc = [p7,p8,p9,p10,p11,p12];
                    I4c_loc = I4c_loc + IR_loc;
                    I4c_nloc = I4c_nloc + IR_nloc;
    %                 end
                end
            end
        end
        I4b_loc = dk^2/k*I4b_loc;
        I4c_loc = dk^2/k*I4c_loc;
        I4b_nloc = dk^2/k*I4b_nloc;
        I4c_nloc = dk^2/k*I4c_nloc;
% toc
    % % Integrate over region 7
    % N = 8; %vary
    % dx = 1/k_D/2^N;
    % dy = dx;
    % x_arr = dx:dx:1/k_D;
    % I7 = 0;
    % for x = x_arr;
    %     y_arr = dx:dx:x;
    %     for y = y_arr;
    %         I7 = I7 + k^2/x^3*IntegrandR(k,k/x,k/x*(1+y-x),params) - ( -4*a*k^(2*a-5)*m*x^(a-8)*((x-y)^4 + x^2*(x-y)^2)/sqrt((2*x-y)*y) );
    %     end
    % end
    % I7 = 1/k*dx*dy*I7 + ( - 7/4*pi*a/(a-3) * k^(2*a-4)*m * (k/k_D)^(a-3) )

    I_loc = I2_loc + 2*I3_loc + I4a_loc + 2*I4b_loc + 2*I4c_loc;
    I_nloc = I2_nloc + 2*I3_nloc + I4a_nloc + 2*I4b_nloc + 2*I4c_nloc;
    n_dots_loc_1a(c_om,c_m) = I_loc(1);
    n_dots_loc_1b(c_om,c_m) = I_loc(2);
    n_dots_loc_2a(c_om,c_m) = I_loc(3);
    n_dots_loc_2b(c_om,c_m) = I_loc(4);
    n_dots_loc_3a(c_om,c_m) = I_loc(5);
    n_dots_loc_3b(c_om,c_m) = I_loc(6);
    n_dots_nloc_1a(c_om,c_m) = I_nloc(1);
    n_dots_nloc_1b(c_om,c_m) = I_nloc(2);
    n_dots_nloc_2a(c_om,c_m) = I_nloc(3);
    n_dots_nloc_2b(c_om,c_m) = I_nloc(4);
    n_dots_nloc_3a(c_om,c_m) = I_nloc(5);
    n_dots_nloc_3b(c_om,c_m) = I_nloc(6);
    %[I2,2*(I3+I4b),I4a,2*I4c];

%     [k,I/n]

% 
% I = I2 + 2*I3 + I4a + 2*I4b + 2*I4c
% Is2 = [Is2;I2];
% Is3 = [Is3;2*I3+2*I4b];
% Is4a = [Is4a;I4a];
% Is4c = [Is4c;2*I4c];


    end
c_om = 0;
end

n_dots_loc_1a = V0sq*A^2*8*pi*n_dots_loc_1a;
n_dots_loc_1b = V0sq*A^2*8*pi*n_dots_loc_1b;
n_dots_loc_2a = V0sq*A^2*8*pi*n_dots_loc_2a;
n_dots_loc_2b = V0sq*A^2*8*pi*n_dots_loc_2b;
n_dots_loc_3a = V0sq*A^2*8*pi*n_dots_loc_3a;
n_dots_loc_3b = V0sq*A^2*8*pi*n_dots_loc_3b;
n_dots_nloc_1a = V0sq*A^2*8*pi*n_dots_nloc_1a;
n_dots_nloc_1b = V0sq*A^2*8*pi*n_dots_nloc_1b;
n_dots_nloc_2a = V0sq*A^2*8*pi*n_dots_nloc_2a;
n_dots_nloc_2b = V0sq*A^2*8*pi*n_dots_nloc_2b;
n_dots_nloc_3a = V0sq*A^2*8*pi*n_dots_nloc_3a;
n_dots_nloc_3b = V0sq*A^2*8*pi*n_dots_nloc_3b;
%rates = n_dots./ns
%Nrates = 2*pi*rates./(OsA);

NDOTS_loc_1a(:,:,cc) = n_dots_loc_1a;
NDOTS_loc_1b(:,:,cc) = n_dots_loc_1b;
NDOTS_loc_2a(:,:,cc) = n_dots_loc_2a;
NDOTS_loc_2b(:,:,cc) = n_dots_loc_2b;
NDOTS_loc_3a(:,:,cc) = n_dots_loc_3a;
NDOTS_loc_3b(:,:,cc) = n_dots_loc_3b;
NDOTS_nloc_1a(:,:,cc) = n_dots_nloc_1a;
NDOTS_nloc_1b(:,:,cc) = n_dots_nloc_1b;
NDOTS_nloc_2a(:,:,cc) = n_dots_nloc_2a;
NDOTS_nloc_2b(:,:,cc) = n_dots_nloc_2b;
NDOTS_nloc_3a(:,:,cc) = n_dots_nloc_3a;
NDOTS_nloc_3b(:,:,cc) = n_dots_nloc_3b;
toc
end

NDOTSmat_loc_1a = zeros(81*nO,nM);
NDOTSmat_loc_1b = zeros(81*nO,nM);
NDOTSmat_loc_2a = zeros(81*nO,nM);
NDOTSmat_loc_2b = zeros(81*nO,nM);
NDOTSmat_loc_3a = zeros(81*nO,nM);
NDOTSmat_loc_3b = zeros(81*nO,nM);
NDOTSmat_nloc_1a = zeros(81*nO,nM);
NDOTSmat_nloc_1b = zeros(81*nO,nM);
NDOTSmat_nloc_2a = zeros(81*nO,nM);
NDOTSmat_nloc_2b = zeros(81*nO,nM);
NDOTSmat_nloc_3a = zeros(81*nO,nM);
NDOTSmat_nloc_3b = zeros(81*nO,nM);
for j=1:81
    NDOTSmat_loc_1a(((j-1)*nO+1):(j*nO),:) = NDOTS_loc_1a(:,:,j);
    NDOTSmat_loc_1b(((j-1)*nO+1):(j*nO),:) = NDOTS_loc_1b(:,:,j);
    NDOTSmat_loc_2a(((j-1)*nO+1):(j*nO),:) = NDOTS_loc_2a(:,:,j);
    NDOTSmat_loc_2b(((j-1)*nO+1):(j*nO),:) = NDOTS_loc_2b(:,:,j);
    NDOTSmat_loc_3a(((j-1)*nO+1):(j*nO),:) = NDOTS_loc_3a(:,:,j);
    NDOTSmat_loc_3b(((j-1)*nO+1):(j*nO),:) = NDOTS_loc_3b(:,:,j);
    NDOTSmat_nloc_1a(((j-1)*nO+1):(j*nO),:) = NDOTS_nloc_1a(:,:,j);
    NDOTSmat_nloc_1b(((j-1)*nO+1):(j*nO),:) = NDOTS_nloc_1b(:,:,j);
    NDOTSmat_nloc_2a(((j-1)*nO+1):(j*nO),:) = NDOTS_nloc_2a(:,:,j);
    NDOTSmat_nloc_2b(((j-1)*nO+1):(j*nO),:) = NDOTS_nloc_2b(:,:,j);
    NDOTSmat_nloc_3a(((j-1)*nO+1):(j*nO),:) = NDOTS_nloc_3a(:,:,j);
    NDOTSmat_nloc_3b(((j-1)*nO+1):(j*nO),:) = NDOTS_nloc_3b(:,:,j);
end

% NDOTS(N_om*(ii-1)+(1:N_om),:) = n_dots;
% NS(N_om*(ii-1)+(1:N_om),:) = ns;
% 
% end
% 
name_hf_loc_1a = params.name_hf_loc{1};
name_hf_loc_1b = params.name_hf_loc{2};
name_hf_loc_2a = params.name_hf_loc{3};
name_hf_loc_2b = params.name_hf_loc{4};
name_hf_loc_3a = params.name_hf_loc{5};
name_hf_loc_3b = params.name_hf_loc{6};
name_hf_nloc_1a = params.name_hf_nloc{1};
name_hf_nloc_1b = params.name_hf_nloc{2};
name_hf_nloc_2a = params.name_hf_nloc{3};
name_hf_nloc_2b = params.name_hf_nloc{4};
name_hf_nloc_3a = params.name_hf_nloc{5};
name_hf_nloc_3b = params.name_hf_nloc{6};
save(name_hf_loc_1a,'NDOTSmat_loc_1a','-ascii')
save(name_hf_loc_1b,'NDOTSmat_loc_1b','-ascii')
save(name_hf_loc_2a,'NDOTSmat_loc_2a','-ascii')
save(name_hf_loc_2b,'NDOTSmat_loc_2b','-ascii')
save(name_hf_loc_3a,'NDOTSmat_loc_3a','-ascii')
save(name_hf_loc_3b,'NDOTSmat_loc_3b','-ascii')
save(name_hf_nloc_1a,'NDOTSmat_nloc_1a','-ascii')
save(name_hf_nloc_1b,'NDOTSmat_nloc_1b','-ascii')
save(name_hf_nloc_2a,'NDOTSmat_nloc_2a','-ascii')
save(name_hf_nloc_2b,'NDOTSmat_nloc_2b','-ascii')
save(name_hf_nloc_3a,'NDOTSmat_nloc_3a','-ascii')
save(name_hf_nloc_3b,'NDOTSmat_nloc_3b','-ascii')
% save('NS','NS','-ascii')

end