%% load and plot strain estimate global maps from Caitlin Whalen

load('av_world_e_250to500m_3_1p5deg_2017.mat')
e1 = e;
Lat=repmat(lat,1,240);
Lon=repmat(lon,87,1);

load('av_world_e_500to1000m_3_1p5deg_2017.mat')
e2 = e;

load('av_world_e_1000to2000m_3_1p5deg_2017.mat')
e3 = e;


%% load from Pollmann's dataset
load('Pollmann_data_eps_new.mat');
Plat = P.lat;
Plon = P.lon;
Pep1 = P.ep1;
Pep2 = P.ep2;
Pep3 = P.ep3;
Pn1  = P.n1;
Pn2  = P.n2;
Pn3  = P.n3;
Pep1(Pep1>1) = nan;
Pep2(Pep2>1) = nan;
Pep3(Pep3>1) = nan;
pause

set(groot,'defaulttextinterpreter','latex');  
set(groot, 'defaultAxesTickLabelInterpreter','latex');  
set(groot, 'defaultLegendInterpreter','latex');


% %% Caitlin's epsilon
% figure(50);clf;
% subplot(1,3,1)
% Pee = e1(:);
% Pla = Lat(:);
% Plo = Lon(:);
% Pla = Pla(logical((Pee>0).*(Pee<1)));
% Plo = Plo(logical((Pee>0).*(Pee<1)));
% Pee = Pee(logical((Pee>0).*(Pee<1)));
% pointsize = 1;
% geoscatter(Pla,Plo,pointsize, log10(Pee),'s', 'filled')
% caxis([-11,-7])
% geolimits([-80,80],[0,360])
% geobasemap('grayland')
% txt = '$250-500$ m';
% title(txt)
% 
% subplot(1,3,2)
% Pee = e2(:);
% Pla = Lat(:);
% Plo = Lon(:);
% Pla = Pla(logical((Pee>0).*(Pee<1)));
% Plo = Plo(logical((Pee>0).*(Pee<1)));
% Pee = Pee(logical((Pee>0).*(Pee<1)));
% pointsize = 1;
% geoscatter(Pla,Plo,pointsize, log10(Pee),'s', 'filled')
% caxis([-11,-7])
% geolimits([-80,80],[0,360])
% geobasemap('grayland')
% txt = '$250-500$ m';
% title(txt)
% 
% subplot(1,3,3)
% Pee = e3(:);
% Pla = Lat(:);
% Plo = Lon(:);
% Pla = Pla(logical((Pee>0).*(Pee<1)));
% Plo = Plo(logical((Pee>0).*(Pee<1)));
% Pee = Pee(logical((Pee>0).*(Pee<1)));
% pointsize = 1;
% geoscatter(Pla,Plo,pointsize, log10(Pee),'s', 'filled')
% caxis([-11,-7])
% geolimits([-80,80],[0,360])
% geobasemap('grayland')
% txt = '$250-500$ m';
% title(txt)

%% Friederike's epsilon
% figure(46);clf;
% subplot(3,1,1)
% Pee = Pep1(:);
% Pla = Plat(:);
% Plo = Plon(:);
% Pla = Pla(logical((Pee>0).*(Pee<1)));
% Plo = Plo(logical((Pee>0).*(Pee<1)));
% Pee = Pee(logical((Pee>0).*(Pee<1)));
% E2_u = Pep1;
% longitude = -180:1.5:180;
% latitude = -90:1.5:90;
% plot_e2 = [E2_u'; zeros(1,240)];
% plot_e2 = [plot_e2 zeros(121,1)];
% %axes('Position',[.1 .54 .8 .4])
% pcolor(longitude,latitude,real(log10(plot_e2)))
% shading flat
% hold on
% geoshow('landareas.shp', 'FaceColor', 'gray');
% %hold off
% % set(gca,'xtick',[-180:30:180])
% % set(gca,'ytick',[-90:30:90])
% ylim([-70 60])
% %xlim([-180 180])
% 
% % set(gca,'ytick',-90:30:90)
% % set(gca,'xtick',-180:30:180,'xticklabel',{''})
% caxis([-11,-7])
% 
% 
% % Pee = Pep1(:);
% % Pla = Plat(:);
% % Plo = Plon(:);
% % Pla = Pla(logical((Pee>0).*(Pee<1)));
% % Plo = Plo(logical((Pee>0).*(Pee<1)));
% % Pee = Pee(logical((Pee>0).*(Pee<1)));
% % pointsize = 3;
% % geoscatter(Pla,Plo,pointsize, log10(Pee),'s', 'filled')
% % caxis([-11,-7])
% % geolimits([-70,60],[0,360])
% % geobasemap('grayland')
% txt = '$250-500$ m';
% title(txt)
% pause
% 
% subplot(3,1,2)
% Pee = Pep2(:);
% Pla = Plat(:);
% Plo = Plon(:);
% Pla = Pla(logical((Pee>0).*(Pee<1)));
% Plo = Plo(logical((Pee>0).*(Pee<1)));
% Pee = Pee(logical((Pee>0).*(Pee<1)));
% pointsize = 3;
% geoscatter(Pla,Plo,pointsize, log10(Pee),'s', 'filled')
% caxis([-11,-7])
% geolimits([-70,60],[0,360])
% geobasemap('grayland')
% txt = '$500-1000$ m';
% title(txt)
% 
% subplot(3,1,3)
% Pee = Pep3(:);
% Pla = Plat(:);
% Plo = Plon(:);
% Pla = Pla(logical((Pee>0).*(Pee<1)));
% Plo = Plo(logical((Pee>0).*(Pee<1)));
% Pee = Pee(logical((Pee>0).*(Pee<1)));
% pointsize = 3;
% geoscatter(Pla,Plo,pointsize, log10(Pee),'s', 'filled')
% caxis([-11,-7])
% geolimits([-70,60],[0,360])
% geobasemap('grayland')
% txt = '$1000-2000$ m';
% title(txt)

%E2_u = Pep1;
figure(51);clf;
subplot(3,1,1)
Pee = Pep1(:);
Pla = Plat(:);
Plo = Plon(:);
Pla = Pla(logical((Pee>0).*(Pee<1)));
Plo = Plo(logical((Pee>0).*(Pee<1)));
Pee = Pee(logical((Pee>0).*(Pee<1)));
pointsize = 3;
Pee1 = Pee;
Pee1(abs(Pla)>38)=nan;
geoscatter(Pla,Plo,pointsize, log10(Pee1),'s', 'filled')
geolimits([-70,60],[0,360])
hold on
pause
pointsize = 6;
Pee1 = Pee;
Pee1(abs(Pla)<37)=nan;
geoscatter(Pla,Plo,pointsize, log10(Pee1),'s', 'filled')
pause
pointsize = 10;
Pee1 = Pee;
Pee1(abs(Pla)<56)=nan;
geoscatter(Pla,Plo,pointsize, log10(Pee1),'s', 'filled')
pause
pointsize = 14;
Pee1 = Pee;
Pee1(abs(Pla)<62)=nan;
geoscatter(Pla,Plo,pointsize, log10(Pee1),'s', 'filled')
pause
pointsize = 18;
Pee1 = Pee;
Pee1(abs(Pla)<68)=nan;
geoscatter(Pla,Plo,pointsize, log10(Pee1),'s', 'filled')
caxis([-11,-7])
geolimits([-70,60],[0,360])
geobasemap('grayland')
txt = '$250-500$ m';
title(txt)
pause

subplot(3,1,2)
Pee = Pep2(:);
Pla = Plat(:);
Plo = Plon(:);
Pla = Pla(logical((Pee>0).*(Pee<1)));
Plo = Plo(logical((Pee>0).*(Pee<1)));
Pee = Pee(logical((Pee>0).*(Pee<1)));
pointsize = 3;
geoscatter(Pla,Plo,pointsize, log10(Pee),'s', 'filled')
hold on
pause
pointsize = 6;
Pee1 = Pee;
Pee1(abs(Pla)<37)=nan;
geoscatter(Pla,Plo,pointsize, log10(Pee1),'s', 'filled')
pause
pointsize = 10;
Pee1 = Pee;
Pee1(abs(Pla)<56)=nan;
geoscatter(Pla,Plo,pointsize, log10(Pee1),'s', 'filled')
pause
pointsize = 14;
Pee1 = Pee;
Pee1(abs(Pla)<62)=nan;
geoscatter(Pla,Plo,pointsize, log10(Pee1),'s', 'filled')
pause
pointsize = 18;
Pee1 = Pee;
Pee1(abs(Pla)<68)=nan;
geoscatter(Pla,Plo,pointsize, log10(Pee1),'s', 'filled')
caxis([-11,-7])
geolimits([-70,60],[0,360])
geobasemap('grayland')
txt = '$500-1000$ m';
title(txt)

subplot(3,1,3)
Pee = Pep3(:);
Pla = Plat(:);
Plo = Plon(:);
Pla = Pla(logical((Pee>0).*(Pee<1)));
Plo = Plo(logical((Pee>0).*(Pee<1)));
Pee = Pee(logical((Pee>0).*(Pee<1)));
pointsize = 3;
geoscatter(Pla,Plo,pointsize, log10(Pee),'s', 'filled')
hold on
pause
pointsize = 6;
Pee1 = Pee;
Pee1(abs(Pla)<37)=nan;
geoscatter(Pla,Plo,pointsize, log10(Pee1),'s', 'filled')
pause
pointsize = 10;
Pee1 = Pee;
Pee1(abs(Pla)<56)=nan;
geoscatter(Pla,Plo,pointsize, log10(Pee1),'s', 'filled')
pause
pointsize = 14;
Pee1 = Pee;
Pee1(abs(Pla)<62)=nan;
geoscatter(Pla,Plo,pointsize, log10(Pee1),'s', 'filled')
pause
pointsize = 18;
Pee1 = Pee;
Pee1(abs(Pla)<68)=nan;
geoscatter(Pla,Plo,pointsize, log10(Pee1),'s', 'filled')
caxis([-11,-7])
geolimits([-70,60],[0,360])
geobasemap('grayland')
txt = '$1000-2000$ m';
title(txt)


%% put the 2 together: Caitlin's on Friederike's grid
% Caitlin's scattered data
Cep1 = Pep1*nan;
Cep2 = Pep1*nan;
Cep3 = Pep1*nan;
Pee1 = e1(:);
Pee2 = e2(:);
Pee3 = e3(:);
Pla = Lat(:);
Plo = Lon(:);
F1 = scatteredInterpolant(Pla,Plo,log10(Pee1));
F1.ExtrapolationMethod = 'none';
F2 = scatteredInterpolant(Pla,Plo,log10(Pee2));
F2.ExtrapolationMethod = 'none';
F3 = scatteredInterpolant(Pla,Plo,log10(Pee3));
F3.ExtrapolationMethod = 'none';
for i=1:240
    for j=1:120
        % Friederike's query points
        latq = Plat(i,j);
        lonq = Plon(i,j);
        Cep1(i,j) = 10.^(F1(latq,lonq));
        Cep2(i,j) = 10.^(F2(latq,lonq));
        Cep3(i,j) = 10.^(F3(latq,lonq));
    end
end
diff1 = log10(Cep1./Pep1);
diff2 = log10(Cep2./Pep2);
diff3 = log10(Cep3./Pep3);


figure(52);clf;
subplot(3,1,1)
Pee = diff1(:);
Pla = Plat(:);
Plo = Plon(:);
Pla = Pla(logical((Pee>-3).*(Pee<3)));
Plo = Plo(logical((Pee>-3).*(Pee<3)));
Pee = Pee(logical((Pee>-3).*(Pee<3)));
pointsize = 1;
geoscatter(Pla,Plo,pointsize, (Pee),'s', 'filled')
caxis([-2,1.5])
geolimits([-80,80],[0,360])
geobasemap('grayland')
txt = '$250-500$ m';
title(txt)

subplot(3,1,2)
Pee = diff2(:);
Pla = Plat(:);
Plo = Plon(:);
Pla = Pla(logical((Pee>-3).*(Pee<3)));
Plo = Plo(logical((Pee>-3).*(Pee<3)));
Pee = Pee(logical((Pee>-3).*(Pee<3)));
pointsize = 1;
geoscatter(Pla,Plo,pointsize, (Pee),'s', 'filled')
caxis([-2,1.5])
geolimits([-80,80],[0,360])
geobasemap('grayland')
txt = '$250-500$ m';
title(txt)

subplot(3,1,3)
Pee = diff3(:);
Pla = Plat(:);
Plo = Plon(:);
Pla = Pla(logical((Pee>-3).*(Pee<3)));
Plo = Plo(logical((Pee>-3).*(Pee<3)));
Pee = Pee(logical((Pee>-3).*(Pee<3)));
pointsize = 1;
geoscatter(Pla,Plo,pointsize, (Pee),'s', 'filled')
caxis([-2,1.5])
geolimits([-80,80],[0,360])
geobasemap('grayland')
txt = '$250-500$ m';
title(txt)

figure(53);clf;
subplot(3,1,1)
plot(log10(Cep1(:)),log10(Pep1(:)),'.','markersize',5)
hold on
plot([-11,-7],[-11,-7],'r','linewidth',2)
plot([-11,-7],[-11,-7]+0.48,'g','linewidth',2)
plot([-11,-7],[-11,-7]-0.48,'g','linewidth',2)
xlabel('Caitlin epsilon','interpreter','latex')
ylabel('Friederike epsilon','interpreter','latex')
xlim([-11,-7])
ylim([-11,-7])
subplot(3,1,2)
plot(log10(Cep2(:)),log10(Pep2(:)),'.','markersize',5)
hold on
plot([-11,-7],[-11,-7],'r','linewidth',2)
plot([-11,-7],[-11,-7]+0.48,'g','linewidth',2)
plot([-11,-7],[-11,-7]-0.48,'g','linewidth',2)
xlabel('Caitlin epsilon','interpreter','latex')
ylabel('Friederike epsilon','interpreter','latex')
xlim([-11,-7])
ylim([-11,-7])
subplot(3,1,3)
plot(log10(Cep3(:)),log10(Pep3(:)),'.','markersize',5)
hold on
plot([-11,-7],[-11,-7],'r','linewidth',2)
plot([-11,-7],[-11,-7]+0.48,'g','linewidth',2)
plot([-11,-7],[-11,-7]-0.48,'g','linewidth',2)
xlabel('Caitlin epsilon','interpreter','latex')
ylabel('Friederike epsilon','interpreter','latex')
xlim([-11,-7])
ylim([-11,-7])



% %% put the 2 together: Friederike's on Caitlin's grid
% % Caitlin's scattered data
% Fep1 = e1*nan;
% Fep2 = e1*nan;
% Fep3 = e1*nan;
% Pee1 = Pep1(:);
% Pee2 = Pep2(:);
% Pee3 = Pep3(:);
% Pla = Plat(:);
% Plo = Plon(:);
% F1 = scatteredInterpolant(Pla,Plo,Pee1);
% F1.ExtrapolationMethod = 'none';
% F2 = scatteredInterpolant(Pla,Plo,Pee2);
% F2.ExtrapolationMethod = 'none';
% F3 = scatteredInterpolant(Pla,Plo,Pee3);
% F3.ExtrapolationMethod = 'none';
% for i=1:240
%     for j=1:87
%         % Caitlin's query points
%         latq = Lat(j,i);
%         lonq = Lon(j,i);
%         Fep1(j,i) = F1(latq,lonq);
%         Fep2(j,i) = F2(latq,lonq);
%         Fep3(j,i) = F3(latq,lonq);
%     end
% end
% diff1 = log10(e1./Fep1);
% diff2 = log10(e2./Fep2);
% diff3 = log10(e3./Fep3);

Platit = [Plat(:),Plat(:)];%,Plat(:)];
p1_ = [Pep1(:),Pep2(:)];%,Pep3(:)];
p2_ = [Cep3(:),Cep2(:)];%,Cep3(:)];
plat = Platit(logical(1-isnan(p1_.*p2_)));
p1 = p1_(logical(1-isnan(p1_.*p2_)));
p2 = p2_(logical(1-isnan(p1_.*p2_)));
p1 = p1(logical((abs(plat)>29).*(abs(plat)<52)));
p2 = p2(logical((abs(plat)>29).*(abs(plat)<52)));
pp1 = p1;
pp2 = p2;
%% build histogram
nbins = 26;%26;%26best, 31too
[counts, centers] = hist(log10(p1),nbins);
de = centers(2)-centers(1);
e_moors = [];
e_moors_lin = [];
errs = [];
cis = [];
for j=1:nbins
    ci = 0;
    kk = 0;
    yy = 0
    if j==1
        kk=0.2;
    end
    if j==nbins
        yy=0.2
    end
    tot_i = [];
    tot_i_lin = [];
    for i = 1:length(p2)
        if logical(1-isnan(p1(i)))
            if (log10(p1(i))>centers(j)-de/2-kk)&&(log10(p1(i))<centers(j)+de/2+yy)
                ci = ci + 1;
                tot_i = [tot_i, log10(p2(i))];
                tot_i_lin = [tot_i_lin, (p2(i))];
            end
        end
    end
    %counts(j)/ci
    e_moors = [e_moors, (mean(tot_i,'omitnan'))];
    e_moors_lin = [e_moors_lin, log10(mean(tot_i_lin,'omitnan'))];
    errs = [errs, std(tot_i,'omitnan')];%/sqrt(ci)];
    cis = [cis,ci];
    
end

figure(70);clf;
%errorbar(centers(1:nbins),e_moors(1:nbins),errs(1:nbins),'*','markersize',3,'linewidth',.5)
%taylored for n_bins=24
std1 = sqrt((errs(4))^2 + (errs(3))^2 + ((e_moors(2)+e_moors(1))/2 - ((e_moors(2)+e_moors(1))/2+e_moors(3)+e_moors(4))/3)^2)/sqrt(3);
%errorbar([(centers(2)+centers(3))/2,centers(5:nbins-4),(centers(end-2)+centers(end-1))/2],[((e_moors(2)+e_moors(1))/2+e_moors(3)+e_moors(4))/3,e_moors(5:nbins-4),(e_moors(end-3)+e_moors(end-1))/2],[std1,errs(5:nbins-4),abs(e_moors(end-3)-e_moors(end-1))/sqrt(3)],'.','markersize',12,'linewidth',.5)
%hold on
%errorbar([(centers(2)+centers(3))/2,centers(5:nbins-4),(centers(end-2)+centers(end-1))/2],[((e_moors(2)+e_moors(1))/2+e_moors(3)+e_moors(4))/3,e_moors(5:nbins-4),(e_moors(end-3)+e_moors(end-1))/2],[std1,errs(5:nbins-4),abs(e_moors(end-3)-e_moors(end-1))/sqrt(3)],'.','markersize',12,'linewidth',.5)
ccc = 1;
% errorbar(centers(cis>ccc),e_moors(cis>ccc),2*errs(cis>ccc),'.','markersize',16,'linewidth',1)
% hold on
%errorbar(centers(cis>ccc),e_moors(cis>ccc),2*errs(cis>ccc),'.','markersize',16,'linewidth',1)
errorbar([centers(cis>ccc),(centers(end-1)+centers(end))/2],[e_moors(cis>ccc),(e_moors(end-1)+e_moors(end))/2]-log10(1),2*[errs(cis>ccc),(e_moors(end-1)-e_moors(end))/2],'.','markersize',16,'linewidth',1)
hold on
% Make patch of transparent color.
xBox = [-10.5          -6          -6          -10.5          -10.5];
yBox = [-10.5-log10(2) -6-log10(2) -6+log10(2) -10.5+log10(2) -10.5-log10(2)];
patch(xBox, yBox, 'black', 'FaceColor', 'green', 'FaceAlpha', 0.1);
% Make patch of transparent color.
xBox = [-10.5          -6          -6          -10.5          -10.5];
yBox = [-10.5+log10(2) -6+log10(2) -6+log10(3) -10.5+log10(3) -10.5+log10(2)];
patch(xBox, yBox, 'black', 'FaceColor', 'red', 'FaceAlpha', 0.1);
% Make patch of transparent color.
xBox = [-10.5          -6          -6          -10.5          -10.5];
yBox = [-10.5-log10(2) -6-log10(2) -6-log10(3) -10.5-log10(3) -10.5-log10(2)];
patch(xBox, yBox, 'black', 'FaceColor', 'red', 'FaceAlpha', 0.1);
plot([-11 -6.],[-11 -6.],'k','linewidth',1)
plot([-11 -6.],[-11+0.48 -6.+0.48],'k')
plot([-11 -6.],[-11-0.48 -6.-0.48],'k')
plot([-11 -6.],[-11+0.3 -6.+0.3],'k')
plot([-11 -6.],[-11-0.3 -6.-0.3],'k')
xlabel('$\log_{10}\epsilon$ strain-based Argo (Pollmann)')
ylabel('$\log_{10}\epsilon$ theory w/ mooring + Pollmann`s m slopes')
xlim([-10.5 -6])
ylim([-10.5 -6])
cis(end)=1;
for j=1:nbins
    text(centers(j),centers(j)-0.5,sprintf('%u',cis(j)),'Interpreter','latex')
end

clear('p1');
clear('p2');
%pause

% figure(62);clf;
% subplot(1,3,1)
% Pee = diff1(:);
% Pla = Lat(:);
% Plo = Lon(:);
% Pla = Pla(logical((Pee>-3).*(Pee<3)));
% Plo = Plo(logical((Pee>-3).*(Pee<3)));
% Pee = Pee(logical((Pee>-3).*(Pee<3)));
% pointsize = 1;
% geoscatter(Pla,Plo,pointsize, (Pee),'s', 'filled')
% caxis([-2,1.5])
% geolimits([-80,80],[0,360])
% geobasemap('grayland')
% txt = '$250-500$ m';
% title(txt)
% 
% subplot(1,3,2)
% Pee = diff2(:);
% Pla = Lat(:);
% Plo = Lon(:);
% Pla = Pla(logical((Pee>-3).*(Pee<3)));
% Plo = Plo(logical((Pee>-3).*(Pee<3)));
% Pee = Pee(logical((Pee>-3).*(Pee<3)));
% pointsize = 1;
% geoscatter(Pla,Plo,pointsize, (Pee),'s', 'filled')
% caxis([-2,1.5])
% geolimits([-80,80],[0,360])
% geobasemap('grayland')
% txt = '$250-500$ m';
% title(txt)
% 
% subplot(1,3,3)
% Pee = diff3(:);
% Pla = Lat(:);
% Plo = Lon(:);
% Pla = Pla(logical((Pee>-3).*(Pee<3)));
% Plo = Plo(logical((Pee>-3).*(Pee<3)));
% Pee = Pee(logical((Pee>-3).*(Pee<3)));
% pointsize = 1;
% geoscatter(Pla,Plo,pointsize, (Pee),'s', 'filled')
% caxis([-2,1.5])
% geolimits([-80,80],[0,360])
% geobasemap('grayland')
% txt = '$250-500$ m';
% title(txt)
% 
% figure(63);clf;
% subplot(1,3,1)
% plot(log10(e1(:)),log10(Fep1(:)),'.','markersize',5)
% hold on
% plot([-11,-7],[-11,-7],'r','linewidth',2)
% plot([-11,-7],[-11,-7]+0.48,'g','linewidth',2)
% plot([-11,-7],[-11,-7]-0.48,'g','linewidth',2)
% xlabel('Caitlin epsilon','interpreter','latex')
% ylabel('Friederike epsilon','interpreter','latex')
% xlim([-11,-7])
% ylim([-11,-7])
% subplot(1,3,2)
% plot(log10(e2(:)),log10(Fep2(:)),'.','markersize',5)
% hold on
% plot([-11,-7],[-11,-7],'r','linewidth',2)
% plot([-11,-7],[-11,-7]+0.48,'g','linewidth',2)
% plot([-11,-7],[-11,-7]-0.48,'g','linewidth',2)
% xlabel('Caitlin epsilon','interpreter','latex')
% ylabel('Friederike epsilon','interpreter','latex')
% xlim([-11,-7])
% ylim([-11,-7])
% subplot(1,3,3)
% plot(log10(e3(:)),log10(Fep3(:)),'.','markersize',5)
% hold on
% plot([-11,-7],[-11,-7],'r','linewidth',2)
% plot([-11,-7],[-11,-7]+0.48,'g','linewidth',2)
% plot([-11,-7],[-11,-7]-0.48,'g','linewidth',2)
% xlabel('Caitlin epsilon','interpreter','latex')
% ylabel('Friederike epsilon','interpreter','latex')
% xlim([-11,-7])
% ylim([-11,-7])
% figure(8)
% pause

% figure(1);clf;
% subplot(1,3,1)
% surf(Lat,Lon,log10(e1),'edgecolor','none')
% view(90,-90)
% zlim([-11,-6.8])
% xlabel('latitude')
% ylabel('longitude')
% txt = '$250-500$ m';
% title(txt)
% subplot(1,3,2)
% surf(Lat,Lon,log10(e2),'edgecolor','none')
% view(90,-90)
% zlim([-11,-6.8])
% ylabel('longitude')
% txt = '$500-1000$ m';
% title(txt)
% subplot(1,3,3)
% surf(Lat,Lon,log10(e3),'edgecolor','none')
% view(90,-90)
% zlim([-11,-6.8])
% ylabel('longitude')
% txt = '$1000-2000$ m';
% title(txt)

%% load Friederike's dataset
Plon = P.lon;
Plat = P.lat;
Pep1 = P.ep1;
Pep2 = P.ep2;
Pep3 = P.ep3;
Pn1  = P.n1;
Pn2  = P.n2;
Pn3  = P.n3;


%% load and plot our mooring estimate global maps
%load('mooring_Stat_N0_Pollmann_eps_ave.mat');
%load('mooring_Stat_N0_Pollmann_eps1ok.mat');
%load('mooring_Stat_N0_Pollmann_eps_TotE1.mat'); % this is the good one
load('mooring_Stat_N0_Pollmann_eps_mstar_analytical.mat'); % this is the good one after Olbers correction Sep 2023
%load('mooring_Stat_N0_Pollmann_eps_mstar_analytical_kurt_test.mat');
mean_NI = MooringBins.mean_NI;
mean_con = MooringBins.mean_con;
mean_e0 = MooringBins.mean_e0;
mean_e0WKB = MooringBins.mean_e0WKB;
mean_eps = 0.83*MooringBins.mean_eps;%*8*pi; % watch out: used Osborn parameterization here
mean_N = MooringBins.mean_N;
mean_f = MooringBins.mean_f;
mean_mslope = MooringBins.mean_mslope;
mean_mE = MooringBins.mean_mE;
mean_mstar = MooringBins.mean_mstar;
std_NI = MooringBins.std_NI;
std_con = MooringBins.std_con;
%std_e0 = MooringBins.std_e0;
std_e0WKB = MooringBins.std_e0WKB;
std_eps = 0.83*MooringBins.std_eps;%*8*pi;
std_N = MooringBins.std_N;
std_f = MooringBins.std_f;
std_mslope = MooringBins.std_mslope;
std_mE = MooringBins.std_mE;
std_mstar = MooringBins.std_mstar;
nsample = MooringBins.mean_nsamples;
% mean_eps = mean_eps./(0.0052^2).*(mean_N.^2);

%pause

%temporary correction by GM difference from 0.003
% + f correction: 2 powers from V^2, 2 powers from omega^2 in 2D energy
% density def, and 1 power from integration in d omega
f0 = sin(32.5*pi/180)*2*7.3*10^-5;
N0 = f0*66.8;
%mean_eps = mean_eps/(1.^2).*((mean_N/N0).^(4-2*mean_con));%.*((mean_f/f0).^5);

% figure(7);clf;
% hist()

% create pairs of points from same bin whenever both mooring and strain
% estimates are not NaN

count1 = 0;
count2 = 0;
count3 = 0;
pairs = [];
clat = 0;
for dlat = (-90:1.5:88.5)+0.75 % Friederike's grid
    clat = clat + 1;
    clon = 0;
    for dlon = linspace(0.75,359.25,240)
        clon = clon + 1;
        for ddepth = 1:3
            e_moor = mean_eps(clat,clon,ddepth);
            std_moor = std_eps(clat,clon,ddepth);
            nsamp = nsample(clat,clon,ddepth);
            NI = mean_NI(clat,clon,ddepth);
            con = mean_con(clat,clon,ddepth);
            e0 = mean_e0(clat,clon,ddepth);
            e0WKB = mean_e0WKB(clat,clon,ddepth);
            N = mean_N(clat,clon,ddepth);
            f = mean_f(clat,clon,ddepth);
            mslope = mean_mslope(clat,clon,ddepth);
            mE = mean_mE(clat,clon,ddepth);
            mstar = mean_mstar(clat,clon,ddepth);
            st_N = std_N(clat,clon,ddepth);
            st_f = std_f(clat,clon,ddepth);
           % e_moor = e_moor.*(f.^2)/(7.3*10^-5)^2; % correction for missing f in compute_slopes_all for total kinetic energy
            if ddepth==1
                e_str = Pep1(clon,clat); % Friederike's estimates
                nn    = Pn1(clon,clat);
            end
            if ddepth==2
                e_str = Pep2(clon,clat);
                nn    = Pn2(clon,clat);
            end
            if ddepth==3
                e_str = Pep3(clon,clat);
                nn    = Pn3(clon,clat);
            end
            if 1-isnan(e_moor*e_str)
                if ddepth==1
                    count1 = count1+1;
                end
                if ddepth==2
                    count2 = count2+1;
                end
                if ddepth==3
                    count3 = count3+1;
                end
                pairs = [pairs, [e_str, e_moor, dlat, dlon, ddepth, std_moor, nsamp, NI, con, e0, N, f, st_N, st_f, nn, mslope, mE, mstar, e0WKB]'];
                %pause            p1     p2     p3     p4    p5      p6
            end
        end
    end
end

SS = size(pairs);
%pause

%figure(8);clf;

% New flags that could work:
% mslope < 1.45
% energy level < 3
% energy level > 0.2



% p3 = pairs(3,:);
% pairs = pairs(:,abs(p3)>32);
% p3 = pairs(3,:);
% pairs = pairs(:,abs(p3)<45);
%remove flagged points:

%longitude flags
%pairs(:,logical((pairs(4,:)>0) .* (pairs(4,:)<10) .* (pairs(3,:)>40)))=NaN; % north mediterranean
% 

%Save aside excluded points
EXpairs = [];




%latitude flags
pairs(:,abs(pairs(3,:))>50)=NaN;
pairs(:,abs(pairs(3,:))<0)=NaN;
% EXpairs(:,abs(EXpairs(3,:))>52)=NaN;
% EXpairs(:,abs(EXpairs(3,:))<20)=NaN;
% 
%%aspect ratio flags
pairs(:,abs(pairs(11,:)./pairs(12,:))<10)=NaN;
pairs(:,abs(pairs(11,:)./pairs(12,:))>90)=NaN;
% EXpairs(:,abs(EXpairs(11,:)./EXpairs(12,:))<15)=NaN;
% EXpairs(:,abs(EXpairs(11,:)./EXpairs(12,:))>70)=NaN;


% %longitude flags
% 
%energy level flags
pairs(:,abs(pairs(10,:))>3.5)=NaN; %3.5 for non-WKB
pairs(:,abs(pairs(10,:))<0.2)=NaN; %0.2 for non-WKB
% EXpairs(:,abs(EXpairs(10,:))>3)=NaN;
% EXpairs(:,abs(EXpairs(10,:))<0.1)=NaN;

%continuum slope flags
pairs(:,abs(pairs(9,:))>2.3)=NaN;
pairs(:,abs(pairs(9,:))<1.3)=NaN;
% EXpairs(:,abs(EXpairs(9,:))>2.5)=NaN;
% EXpairs(:,abs(EXpairs(9,:))<1.3)=NaN;
% 
%NI slope flags
pairs(:,abs(pairs(8,:))<0.3)=NaN;     %%% it was 16 (error)
pairs(:,abs(pairs(8,:))>2.1)=NaN;
% EXpairs(:,abs(EXpairs(8,:))<0.2)=NaN;
% EXpairs(:,abs(EXpairs(8,:))>2.3)=NaN;
%
%m slope flags
pairs(:,abs(pairs(16,:))>2.4)=NaN;    %%% it was 9 (error)
pairs(:,abs(pairs(16,:))<1.4)=NaN;
% EXpairs(:,abs(EXpairs(9,:))>2.5)=NaN;
% EXpairs(:,abs(EXpairs(9,:))<1.3)=NaN;
%
%m star flags
pairs(:,abs(pairs(18,:))<0.0002)=NaN;    
pairs(:,abs(pairs(18,:))>0.04)=NaN;
% EXpairs(:,abs(EXpairs(9,:))>2.5)=NaN;
% EXpairs(:,abs(EXpairs(9,:))<1.3)=NaN;

%eps_argo error: remove value of zero (here by mistake)
pairs(:,abs(pairs(1,:))<10^-20)=NaN;    %%% it was 9 (error)
%pairs(:,abs(pairs(1,:))<1.4)=NaN;


p1 = pairs(1,:);
p2 = pairs(2,:);
p3 = pairs(3,:);
p4 = pairs(4,:);
p5 = pairs(5,:);
p6 = pairs(6,:);
p7 = pairs(7,:);
p8 = pairs(8,:);
p9 = pairs(9,:);
p10 = pairs(10,:);
p11 = pairs(11,:);
p12 = pairs(12,:);
p13 = pairs(13,:);
p14 = pairs(14,:);
p15 = pairs(15,:);
p16 = pairs(16,:);
p17 = pairs(17,:);
p18 = pairs(18,:);
p19 = pairs(19,:);


% Try WKB correction to mstar correction
%p2 = p2.*(N0./p11).^(p16-1);


%% Correction for m_star % Comment if already implemented in mooring_bins!!!!

% m_star = 4*pi/1300;
% m_min = 2*pi/2600;
% m_max = 2*pi/10;
% m = linspace(m_min,m_max, 10000);
% 
% for ii=1:length(p18)
%     s_m = p16(ii);
%     e_m = 1./(1+(m/m_star).^s_m);
%     m_starp = p18(ii);
%     e_mp = 1./(1+(m/m_starp).^s_m);
%     start = 1;
%     A1 = trapz(m(start:end),e_m(start:end));
%     A2 = trapz(m(start:end),e_mp(start:end));
%     e_mp = e_mp*A1/A2; %the two spectra are now normalized to the same total energy density
%     final = 400;
%     A1 = trapz(m(final:end),e_m(final:end));
%     A2 = trapz(m(final:end),e_mp(final:end));
%     %e_m = e_m*A2/A1; %e_m needs to be normalized by this factor to reach the same high-wn scaling as e_mp
%     corr_mstar = (A2/A1)^2 %correction to epsilon goes like energy squared  
%     p2(ii) = p2(ii)*corr_mstar;
% end
    




% Condition based on discrepancy between energy from strain and moorings
% p1(abs(log10(p10*0.003./p17))>log10(3)) = nan;
% p2(abs(log10(p10*0.003./p17))>log10(3)) = nan;

%p1((log10(p10*0.003./p17))>log10(1.5)) = nan;
%p2(abs(log10(p10*0.003./p17))>log10(2.5)) = nan;


% figure(49);clf;
% plot3(log10(p1(p5==1)),log10(p2(p5==1)),log10(p10(p5==1)*0.003./p17(p5==1)),'.','markersize',15)
% hold on
% plot3(log10(p1(p5==2)),log10(p2(p5==2)),log10(p10(p5==2)*0.003./p17(p5==2)),'.','markersize',15)
% plot3(log10(p1(p5==3)),log10(p2(p5==3)),log10(p10(p5==3)*0.003./p17(p5==3)),'.','markersize',15)
% plot3([-11,-7],[-11,-7],[0,0],'k')
% zlim([-.6,.6])
% xlabel('$\log_{10}\epsilon$ strain')
% ylabel('$\log_{10}\epsilon$ mooring')
% zlabel('$\ log_{10}$ Emooring/Estrain')
% view(-51,16)

figure(8);
%clean up a bit
pause
clf;
cond = logical(((p18)<0.15).*((p18)>0.01).*((p10)>0));%logical((abs(p3)<90).*(abs(p3)>0));%.*(p6<p2));
%plot(p1,p2,'*','markersize',3,'linewidth',4)
%plot(log10(p1(p5==3)),log10(p2(p5==3)),'*')
pp6=p6;
%pp6(p6>p2)= p2(p6>p2)*0.99999;
%plot(p1(cond),p2(cond),'*','markersize',3,'linewidth',4)
loglog(10.^[-11 -6.5],10.^[-11 -6.5],'k','linewidth',.5)
hold on
errorbar(p1,p2,p6,'.','markersize',15,'linewidth',.5)
errorbar(p1(cond),p2(cond),p6(cond),'.','markersize',15,'linewidth',.5)

plot(10.^[-11 -6.5],10.^[-11+0.48 -6.5+0.48],'k')
plot(10.^[-11 -6.5],10.^[-11-0.48 -6.5-0.48],'k')

xlabel('$\log_{10}\epsilon$ strain-based Argo (Pollmann)')
ylabel('$\log_{10}\epsilon$ theory w/ mooring + Pollmann`s m slopes')
xlim([10^-11 10^-7])
%legend('agreement up to factor $3$','$s<0.9$','$s>0.9$','Interpreter','latex')
10.^(mean(log10(p2(cond))-log10(p1(cond))))
10.^(std(log10(p2(cond))-log10(p1(cond))))
pause

% figure(9);clf;
% loglog(p1,p2,'.','markersize',15,'linewidth',.5)
% hold on
% cond = logical(((p8)>0.).*((p9)<1.5).*((p10)>0));%logical((abs(p3)<90).*(abs(p3)>0));%.*(p6<p2));
% plot(p1(cond),p2(cond),'.','markersize',20,'linewidth',.5)
% cond = logical(((p8)>0.).*((p9)>2.1).*((p10)>0));%logical((abs(p3)<90).*(abs(p3)>0));%.*(p6<p2));
% plot(p1(cond),p2(cond),'.','markersize',20,'linewidth',.5)
% %%%%use to detect rogue points
% cond = logical(((p8)<0.8));%logical((abs(p3)<90).*(abs(p3)>0));%.*(p6<p2));
% plot(p1(cond),p2(cond),'.','markersize',20,'linewidth',.5)
% loglog(10.^[-11 -6.5],10.^[-11 -6.5],'k')
% plot(10.^[-11 -6.5],10.^[-11+0.7 -6.5+0.7],'k')
% plot(10.^[-11 -6.5],10.^[-11-0.7 -6.5-0.7],'k')
% legend('all points','$y<1.5$','$y>2.1$')
% 
% xlabel('$\epsilon$ strain')
% ylabel('$\epsilon$ mooring')
% xlim([10^-11 10^-7])

% z = (p2-p1)./p6;
% hist(z,1000)
% xlim([-10,10])
% 
% figure(10);clf;
% z = (p2(cond)-p1(cond))./p6(cond);
% hist(z,200)
% xlim([-10,10])

%% compute centroids linear scale

%e0: e0=1 (GM energy level is the separation)
cond = logical(((p8)>-1).*((p9)>1).*((p10)>1));
mean_str_e0_g = mean(p1(cond),'omitnan');
std_str_e0_g = std(p1(cond),'omitnan');
mean_str_e0_l = mean(p1(logical(1-cond)),'omitnan');
std_str_e0_l = std(p1(logical(1-cond)),'omitnan');
mean_moor_e0_g = mean(p2(cond),'omitnan');
std_moor_e0_g = std(p2(cond),'omitnan');
mean_moor_e0_l = mean(p2(logical(1-cond)),'omitnan');
std_moor_e0_l = std(p2(logical(1-cond)),'omitnan');

%cont: cont_slope=2
cond = logical(((p8)>-1).*((p9)>1.7).*((p10)>0));
mean_str_con_g = mean(p1(cond),'omitnan');
std_str_con_g = std(p1(cond),'omitnan');
mean_str_con_l = mean(p1(logical(1-cond)),'omitnan');
std_str_con_l = std(p1(logical(1-cond)),'omitnan');
mean_moor_con_g = mean(p2(cond),'omitnan');
std_moor_con_g = std(p2(cond),'omitnan');
mean_moor_con_l = mean(p2(logical(1-cond)),'omitnan');
std_moor_con_l = std(p2(logical(1-cond)),'omitnan');

%cont: NI_slope=1
cond = logical(((p8)>0.8).*((p9)>1).*((p10)>0));
mean_str_NI_g = mean(p1(cond),'omitnan');
std_str_NI_g = std(p1(cond),'omitnan');
mean_str_NI_l = mean(p1(logical(1-cond)),'omitnan');
std_str_NI_l = std(p1(logical(1-cond)),'omitnan');
mean_moor_NI_g = mean(p2(cond),'omitnan');
std_moor_NI_g = std(p2(cond),'omitnan');
mean_moor_NI_l = mean(p2(logical(1-cond)),'omitnan');
std_moor_NI_l = std(p2(logical(1-cond)),'omitnan');

% figure(11);clf;
% semilogy([mean_str_NI_g mean_str_NI_l],[mean_moor_NI_g mean_moor_NI_l],'*')
% hold on
% semilogy([mean_str_con_g mean_str_con_l],[mean_moor_con_g mean_moor_con_l],'*')
% semilogy([mean_str_e0_g mean_str_e0_l],[mean_moor_e0_g mean_moor_e0_l],'*')

%% compute centroids log scale (use for std, linear std are graphically meaningless)

%e0: e0=1 (GM energy level is the separation)
cond = logical(((p8)>-1).*((p9)>1).*((p10)>1));
mean_str_e0_g = 10.^(mean(log10(p1(cond)),'omitnan'));
std_str_e0_g = std(log10(p1(cond)),'omitnan');
mean_str_e0_l = 10.^(mean(log10(p1(logical(1-cond))),'omitnan'));
std_str_e0_l = std(log10(p1(logical(1-cond))),'omitnan');
mean_moor_e0_g = 10.^(mean(log10(p2(cond)),'omitnan'));
std_moor_e0_g = std(log10(p2(cond)),'omitnan');
mean_moor_e0_l = 10.^(mean(log10(p2(logical(1-cond))),'omitnan'));
std_moor_e0_l = std(log10(p2(logical(1-cond))),'omitnan');

%cont: cont_slope=1.85
cond = logical(((p8)>-1).*((p9)>1.7).*((p10)>0));
mean_str_con_g = 10.^(mean(log10(p1(cond)),'omitnan'));
std_str_con_g = std(log10(p1(cond)),'omitnan');
mean_str_con_l = 10.^(mean(log10(p1(logical(1-cond))),'omitnan'));
std_str_con_l = std(log10(p1(logical(1-cond))),'omitnan');
mean_moor_con_g = 10.^(mean(log10(p2(cond)),'omitnan'));
std_moor_con_g = std(log10(p2(cond)),'omitnan');
mean_moor_con_l = 10.^(mean(log10(p2(logical(1-cond))),'omitnan'));
std_moor_con_l = std(log10(p2(logical(1-cond))),'omitnan');

%cont: NI_slope=0.8
cond = logical(((p8)>0.8).*((p9)>1).*((p10)>0));
mean_str_NI_g = 10.^(mean(log10(p1(cond)),'omitnan'));
std_str_NI_g = std(log10(p1(cond)),'omitnan');
mean_str_NI_l = 10.^(mean(log10(p1(logical(1-cond))),'omitnan'));
std_str_NI_l = std(log10(p1(logical(1-cond))),'omitnan');
mean_moor_NI_g = 10.^(mean(log10(p2(cond)),'omitnan'));
std_moor_NI_g = std(log10(p2(cond)),'omitnan');
mean_moor_NI_l = 10.^(mean(log10(p2(logical(1-cond))),'omitnan'));
std_moor_NI_l = std(log10(p2(logical(1-cond))),'omitnan');

% figure(12);clf;
% plot([mean_str_NI_g mean_str_NI_l],[mean_moor_NI_g mean_moor_NI_l],'*')
% hold on
% plot([mean_str_con_g mean_str_con_l],[mean_moor_con_g mean_moor_con_l],'*')
% plot([mean_str_e0_g mean_str_e0_l],[mean_moor_e0_g mean_moor_e0_l],'*')

figure(13);clf;
subplot(1,3,1)
C = log10([mean_str_e0_g mean_moor_e0_g]) ;  % center 
a = 2*std_str_e0_g;      % major axis 
b = 2*std_moor_e0_g; % minor axis
th = linspace(0,2*pi) ; 
xe = C(1)+a*cos(th) ; 
ye = C(2)+b*sin(th) ; 
patch(xe, ye, 'r','facealpha',0.3)
hold on
C = log10([mean_str_e0_l mean_moor_e0_l]) ;  % center 
a = 2*std_str_e0_l;      % major axis 
b = 2*std_moor_e0_l; % minor axis
th = linspace(0,2*pi) ; 
xe = C(1)+a*cos(th) ; 
ye = C(2)+b*sin(th) ; 
patch(xe, ye, 'b','facealpha',0.3)
plot(log10(mean_str_e0_l), log10(mean_moor_e0_l),'.','markersize',20)
plot(log10(mean_str_e0_g), log10(mean_moor_e0_g),'.','markersize',20)
plot([-12,-6],[-12,-6],'k')
plot([-12,-6],[-12,-6]+1,'k')
plot([-12,-6],[-12,-6]-1,'k')
xlim([-12 -6])
ylim([-12 -6])
legend('KE $>$ GM level','KE $<$ GM level')
xlabel('$\epsilon$ strain')
ylabel('$\epsilon$ mooring')

subplot(1,3,2)
C = log10([mean_str_con_g mean_moor_con_g]) ;  % center
a = 2*std_str_con_g;      % major axis
b = 2*std_moor_con_g; % minor axis
th = linspace(0,2*pi) ;
xe = C(1)+a*cos(th) ;
ye = C(2)+b*sin(th) ;
patch(xe, ye, 'r','facealpha',0.3)
hold on
C = log10([mean_str_con_l mean_moor_con_l]) ;  % center
a = 2*std_str_con_l;      % major axis
b = 2*std_moor_con_l; % minor axis
th = linspace(0,2*pi) ;
xe = C(1)+a*cos(th) ;
ye = C(2)+b*sin(th) ;
patch(xe, ye, 'b','facealpha',0.3)
plot(log10(mean_str_con_l), log10(mean_moor_con_l),'.','markersize',20)
plot(log10(mean_str_con_g), log10(mean_moor_con_g),'.','markersize',20)
plot([-12,-6],[-12,-6],'k')
plot([-12,-6],[-12,-6]+1,'k')
plot([-12,-6],[-12,-6]-1,'k')
xlim([-12 -6])
ylim([-12 -6])
legend('cont slope $>1.7$','cont slope $<1.7$')
xlabel('$\epsilon$ strain')
ylabel('$\epsilon$ mooring')

subplot(1,3,3)
C = log10([mean_str_NI_g mean_moor_NI_g]) ;  % center
a = 2*std_str_NI_g;      % major axis
b = 2*std_moor_NI_g; % minor axis
th = linspace(0,2*pi) ;
xe = C(1)+a*cos(th) ;
ye = C(2)+b*sin(th) ;
patch(xe, ye, 'r','facealpha',0.3)
hold on
C = log10([mean_str_NI_l mean_moor_NI_l]) ;  % center 
a = 2*std_str_NI_l;      % major axis 
b = 2*std_moor_NI_l; % minor axis
th = linspace(0,2*pi) ; 
xe = C(1)+a*cos(th) ; 
ye = C(2)+b*sin(th) ; 
patch(xe, ye, 'b','facealpha',0.3)
plot(log10(mean_str_NI_l), log10(mean_moor_NI_l),'.','markersize',20)
plot(log10(mean_str_NI_g), log10(mean_moor_NI_g),'.','markersize',20)
plot([-12,-6],[-12,-6],'k')
plot([-12,-6],[-12,-6]+1,'k')
plot([-12,-6],[-12,-6]-1,'k')
plot([-12,-6],[-12,-6],'k')
xlim([-12 -6])
ylim([-12 -6])
legend('strong NI peak','weak NI peak')
xlabel('$\epsilon$ strain')
ylabel('$\epsilon$ mooring')

%% plot 3D

figure(14);clf;
plot3(log10(p1(p5==1)),log10(p2(p5==1)),abs(p3(p5==1)),'.','markersize',15)
hold on
plot3(log10(p1(p5==2)),log10(p2(p5==2)),abs(p3(p5==2)),'.','markersize',15)
plot3(log10(p1(p5==3)),log10(p2(p5==3)),abs(p3(p5==3)),'.','markersize',15)
plot3([-11,-7],[-11,-7],[0,0],'k')
xlabel('$\log_{10}\epsilon$ strain')
ylabel('$\log_{10}\epsilon$ mooring')
zlabel('latitude')
view(-51,16)

figure(15);clf;
plot3(log10(p1(p5==1)),log10(p2(p5==1)),p4(p5==1),'.','markersize',15)
hold on
plot3(log10(p1(p5==2)),log10(p2(p5==2)),p4(p5==2),'.','markersize',15)
plot3(log10(p1(p5==3)),log10(p2(p5==3)),p4(p5==3),'.','markersize',15)
plot3([-11,-7],[-11,-7],[0,0],'k')
xlabel('$\log_{10}\epsilon$ strain')
ylabel('$\log_{10}\epsilon$ mooring')
zlabel('longitude')
view(-51,16)

figure(16);clf;
plot3(log10(p1(p5==1)),log10(p2(p5==1)),p5(p5==1),'.','markersize',15)
hold on
plot3(log10(p1(p5==2)),log10(p2(p5==2)),p5(p5==2),'.','markersize',15)
plot3(log10(p1(p5==3)),log10(p2(p5==3)),p5(p5==3),'.','markersize',15)
plot3([-11,-7],[-11,-7],[0,0],'k')
xlabel('$\log_{10}\epsilon$ strain')
ylabel('$\log_{10}\epsilon$ mooring')
zlabel('depth')
view(-51,16)

figure(17);clf;
plot3(log10(p1(p5==1)),log10(p2(p5==1)),(p10(p5==1)),'.','markersize',15) %p19 is WKB-scaled, p10 not
hold on
plot3(log10(p1(p5==2)),log10(p2(p5==2)),(p10(p5==2)),'.','markersize',15)
plot3(log10(p1(p5==3)),log10(p2(p5==3)),(p10(p5==3)),'.','markersize',15)
plot3([-11,-7],[-11,-7],[0,0],'k')
xlabel('$\log_{10}\epsilon$ strain')
ylabel('$\log_{10}\epsilon$ mooring')
zlabel('energy level')
zlim([0,15])
view(-51,16)

figure(18);clf;
plot3(log10(p1(p5==1)),log10(p2(p5==1)),(p9(p5==1)),'.','markersize',15)
hold on
plot3(log10(p1(p5==2)),log10(p2(p5==2)),(p9(p5==2)),'.','markersize',15)
plot3(log10(p1(p5==3)),log10(p2(p5==3)),(p9(p5==3)),'.','markersize',15)
plot3([-11,-7],[-11,-7],[1,1],'k')
xlabel('$\log_{10}\epsilon$ strain')
ylabel('$\log_{10}\epsilon$ mooring')
zlabel('continuum slope')
zlim([1,3])
view(-51,16)

figure(19);clf;
plot3(log10(p1(p5==1)),log10(p2(p5==1)),(p8(p5==1)),'.','markersize',15)
hold on
plot3(log10(p1(p5==2)),log10(p2(p5==2)),(p8(p5==2)),'.','markersize',15)
plot3(log10(p1(p5==3)),log10(p2(p5==3)),(p8(p5==3)),'.','markersize',15)
plot3([-11,-7],[-11,-7],[0,0],'k')
xlabel('$\log_{10}\epsilon$ strain')
ylabel('$\log_{10}\epsilon$ mooring')
zlabel('NI slope')
view(-51,16)

figure(20);clf;
plot3(log10(p1(p5==1)),log10(p2(p5==1)),(p16(p5==1)),'.','markersize',15)
hold on
plot3(log10(p1(p5==2)),log10(p2(p5==2)),(p16(p5==2)),'.','markersize',15)
plot3(log10(p1(p5==3)),log10(p2(p5==3)),(p16(p5==3)),'.','markersize',15)
plot3([-11,-7],[-11,-7],[1,1],'k')
xlabel('$\log_{10}\epsilon$ strain')
ylabel('$\log_{10}\epsilon$ mooring')
zlabel('m slope')
zlim([1,3])
view(-51,16)




%% build histogram
nbins = 13;%14;%26;%26best, 31too
[counts, centers] = hist(log10(p1),nbins);
de = centers(2)-centers(1);
e_moors = [];
e_moors_lin = [];
errs = [];
errs_lin = [];
E_moors = [];
E_moors_lin = [];
Errs = [];
Errs_lin = [];
cis = [];
dis = [];
for j=1:nbins
    ci = 0;
    di = 0;
    kk = 0;
    yy = 0;
    if j==1
        kk=0.2;
    end
    if j==nbins
        yy=0.2;
    end
    tot_i = [];
    tot_i_lin = [];
    for i = 1:length(p2)
        if logical(1-isnan(p1(i)))
            if (log10(p1(i))>centers(j)-de/2-kk)&&(log10(p1(i))<centers(j)+de/2+yy ) && (log10(p1(i))>log10(8.5*10^-11))
                ci = ci + 1;
                tot_i = [tot_i, log10(p2(i))];
                tot_i_lin = [tot_i_lin, (p2(i))];
            end
        end
    end
    %counts(j)/ci
    e_moors = [e_moors, (mean(tot_i,'omitnan'))];
    e_moors_lin = [e_moors_lin, log10(mean(tot_i_lin,'omitnan'))];
    errs = [errs, std(tot_i,'omitnan')/sqrt(ci)];
    errs_lin = [errs_lin, std(tot_i_lin,'omitnan')/sqrt(ci)];
    errs_lin_p = log10(10.^e_moors_lin + 2*errs_lin) - e_moors_lin;
    errs_lin_m = e_moors_lin - log10(10.^e_moors_lin - 2*errs_lin);
    cis = [cis,ci];
end


Centers = [centers,-7.40];
for j=1:nbins+1
    ci = 0;
    di = 0;
    kk = 0;
    yy = 0;
    if j==1
        kk=0.2;
    end
    if j==nbins+1
        yy=0.2;
    end
    Tot_i = [];
    Tot_i_lin = [];
    for i = 1:length(pp2)
        if (log10(pp1(i))>Centers(j)-de/2-kk)&&(log10(pp1(i))<Centers(j)+de/2+yy)
            di = di + 1;
            Tot_i = [Tot_i, log10(pp2(i))];
            Tot_i_lin = [Tot_i_lin, (pp2(i))];
        end
    end
    %counts(j)/ci
    E_moors = [E_moors, (mean(Tot_i,'omitnan'))];
    E_moors_lin = [E_moors_lin, log10(mean(Tot_i_lin,'omitnan'))];
    Errs = [Errs, std(Tot_i,'omitnan')];%/sqrt(ci)];
    Errs_lin = [Errs_lin,std(Tot_i_lin,'omitnan')];
    dis = [dis,di];
    
end

figure(80);clf;
%errorbar(centers(1:nbins),e_moors(1:nbins),errs(1:nbins),'*','markersize',3,'linewidth',.5)
%taylored for n_bins=24
std1 = sqrt((errs(4))^2 + (errs(3))^2 + ((e_moors(2)+e_moors(1))/2 - ((e_moors(2)+e_moors(1))/2+e_moors(3)+e_moors(4))/3)^2)/sqrt(3);
%errorbar([(centers(2)+centers(3))/2,centers(5:nbins-4),(centers(end-2)+centers(end-1))/2],[((e_moors(2)+e_moors(1))/2+e_moors(3)+e_moors(4))/3,e_moors(5:nbins-4),(e_moors(end-3)+e_moors(end-1))/2],[std1,errs(5:nbins-4),abs(e_moors(end-3)-e_moors(end-1))/sqrt(3)],'.','markersize',12,'linewidth',.5)
%hold on
%errorbar([(centers(2)+centers(3))/2,centers(5:nbins-4),(centers(end-2)+centers(end-1))/2],[((e_moors(2)+e_moors(1))/2+e_moors(3)+e_moors(4))/3,e_moors(5:nbins-4),(e_moors(end-3)+e_moors(end-1))/2],[std1,errs(5:nbins-4),abs(e_moors(end-3)-e_moors(end-1))/sqrt(3)],'.','markersize',12,'linewidth',.5)
ccc = 1;
% errorbar(centers(cis>ccc),e_moors(cis>ccc),2*errs(cis>ccc),'.','markersize',16,'linewidth',1)
% hold on

%linear
errorbar(centers(cis>ccc),e_moors_lin(cis>ccc),errs_lin_m(cis>ccc),errs_lin_p(cis>ccc),'.','markersize',16,'linewidth',1);%,'color',	"#EDB120")
%pause
%log
%errorbar(centers(cis>ccc),e_moors(cis>ccc),2*errs(cis>ccc),'.','markersize',16,'linewidth',1);%,'color',	"#EDB120")

%errorbar([centers(cis>ccc),(centers(end-1)+centers(end))/2],[e_moors(cis>ccc),(e_moors(end-1)+e_moors(end))/2]-log10(1),2*[errs(cis>ccc),(e_moors(end-1)-e_moors(end))/2],'.','markersize',16,'linewidth',1)
hold on
%errorbar(Centers(cis>0)+0.01,E_moors(cis>0),2*Errs(cis>0),'.','markersize',16,'linewidth',1)
% Make patch of transparent color.
xBox = [-11          -6          -6          -11          -11];
yBox = [-11-log10(2) -6-log10(2) -6+log10(2) -11+log10(2) -11-log10(2)];
patch(xBox, yBox, 'black', 'FaceColor', 'green', 'FaceAlpha', 0.1);
% Make patch of transparent color.
xBox = [-11          -6          -6          -11          -11];
yBox = [-11+log10(2) -6+log10(2) -6+log10(3) -11+log10(3) -11+log10(2)];
patch(xBox, yBox, 'black', 'FaceColor', 'red', 'FaceAlpha', 0.1);
% Make patch of transparent color.
xBox = [-11          -6          -6          -11          -11];
yBox = [-11-log10(2) -6-log10(2) -6-log10(3) -11-log10(3) -11-log10(2)];
patch(xBox, yBox, 'black', 'FaceColor', 'red', 'FaceAlpha', 0.1);
plot([-11 -6.],[-11 -6.],'k','linewidth',1)
plot([-11 -6.],[-11+0.48 -6.+0.48],'k')
plot([-11 -6.],[-11-0.48 -6.-0.48],'k')
plot([-11 -6.],[-11+0.3 -6.+0.3],'k')
plot([-11 -6.],[-11-0.3 -6.-0.3],'k')
xlabel('$\log_{10}(\epsilon)$ strain FP / Argo data [Wkg$^{-1}$]')
ylabel('$\log_{10}(\epsilon)$ theory / GMACMD + Argo data [Wkg$^{-1}$]')
xlim([-10.5 -7.5])
ylim([-10.5 -7.5])
%cis(end)=1;
for j=1:nbins
   text(centers(j)+0.02,centers(j)-0.55,sprintf('%u',cis(j)),'Interpreter','latex')
end
legend('$95\%$ confidence intervals','within factor of 2','within factor of 3','Interpreter','latex')

%% alternative way to demonstrate statistical agreement via z variable

znbins = 1000;
zs = (p2-p1)./p6;
[zcounts, zcenters] = hist(zs,znbins);
figure(21);clf;
%hist(zs,znbins)
bar(zcenters,zcounts/sum(zcounts))
%plot(zcenters,zcounts/sum(zcounts),'.','markersize',15)
xlim([-10,10])
ylim([0,0.2])
hold on
a = area([-2,2],[0.45,0.45],'facealpha',0.2)
a(1).FaceColor = [0 0.4470 0.7410];
a(1).EdgeColor = [0 0.4470 0.7410];

txt = '$\sim 60\%$ of histogram area';
text(-7,0.16,txt,'interpreter','latex','Color', 'k')
txt = 'within 95\% confidence interval';
text(-8.5,0.15,txt,'interpreter','latex','Color', 'k')
xlabel('$z = \frac{mean(\epsilon^{strain}_i)-mean(\epsilon^{mooring}_i)}{std(\epsilon^{mooring}_i)}$')
legend('fraction of points in each bin','$95\%$ confidence interval')

% 95% confidence interval calculation
frac95 = (sum(zcounts(952:960)) + zcounts(961)/2)/sum(zcounts)
frac99p7 = (sum(zcounts(950:962)) + zcounts(963)/2)/sum(zcounts)

figure(22);clf;
plot(zs(p5==1),abs(p3(p5==1)),'.','markersize',12)
hold on
plot(zs(p5==2),abs(p3(p5==2)),'.','markersize',12)
plot(zs(p5==3),abs(p3(p5==3)),'.','markersize',12)
a = area([-2,2],[60,60],'facealpha',0.1)
a(1).FaceColor = [0.2 0.2 0.2];
a(1).EdgeColor = [0.2 0.2 0.2];
xlabel('$z$')
ylabel('latitude')
xlim([-10,10])

figure(23);clf;
plot(zs(p5==1),abs(p4(p5==1)),'.','markersize',12)
hold on
plot(zs(p5==2),abs(p4(p5==2)),'.','markersize',12)
plot(zs(p5==3),abs(p4(p5==3)),'.','markersize',12)
a = area([-2,2],[360,360],'facealpha',0.1)
a(1).FaceColor = [0.2 0.2 0.2];
a(1).EdgeColor = [0.2 0.2 0.2];
xlabel('$z$')
ylabel('longitude')
ylim([0,360])
xlim([-10,10])

figure(24);clf;
plot(zs(p5==1),abs(p5(p5==1)),'.','markersize',12)
hold on
plot(zs(p5==2),abs(p5(p5==2)),'.','markersize',12)
plot(zs(p5==3),abs(p5(p5==3)),'.','markersize',12)
a = area([-2,2],[3,3],'facealpha',0.1)
a(1).FaceColor = [0.2 0.2 0.2];
a(1).EdgeColor = [0.2 0.2 0.2];
xlabel('$z$')
ylabel('depth')
xlim([-10,10])

figure(25);clf;
plot(zs(p5==1),abs(p10(p5==1)),'.','markersize',12)
hold on
plot(zs(p5==2),abs(p10(p5==2)),'.','markersize',12)
plot(zs(p5==3),abs(p10(p5==3)),'.','markersize',12)
a = area([-2,2],[18,18],'facealpha',0.1)
a(1).FaceColor = [0.2 0.2 0.2];
a(1).EdgeColor = [0.2 0.2 0.2];
xlabel('$z$')
ylabel('energy level')
xlim([-10,10])

figure(26);clf;
plot(zs(p5==1),abs(p9(p5==1)),'.','markersize',12)
hold on
plot(zs(p5==2),abs(p9(p5==2)),'.','markersize',12)
plot(zs(p5==3),abs(p9(p5==3)),'.','markersize',12)
a = area([-2,2],[4,4],'facealpha',0.1)
a(1).FaceColor = [0.2 0.2 0.2];
a(1).EdgeColor = [0.2 0.2 0.2];
xlabel('$z$')
ylabel('continuum slope')
xlim([-10,10])

figure(27);clf;
plot(zs(p5==1),abs(p8(p5==1)),'.','markersize',12)
hold on
plot(zs(p5==2),abs(p8(p5==2)),'.','markersize',12)
plot(zs(p5==3),abs(p8(p5==3)),'.','markersize',12)
a = area([-2,2],[3.5,3.5],'facealpha',0.1)
a(1).FaceColor = [0.2 0.2 0.2];
a(1).EdgeColor = [0.2 0.2 0.2];
xlabel('$z$')
ylabel('NI slope')
xlim([-10,10])

znbins = 1000;
zs = (p2-p1)./p6;
[zcounts, zcenters] = hist(zs(p5==1),zcenters);
figure(28);clf;
subplot(1,3,1)
%hist(zs,znbins)
bar(zcenters,zcounts/sum(zcounts))
%plot(zcenters,zcounts/sum(zcounts),'.','markersize',15)
xlim([-10,10])
hold on
a = area([-2,2],[0.45,0.45],'facealpha',0.2)
a(1).FaceColor = [0 0.4470 0.7410];
a(1).EdgeColor = [0 0.4470 0.7410];
% 95% confidence interval calculation
frac95 = (sum(zcounts(952:960)) + zcounts(961)/2)/sum(zcounts)
frac99p7 = (sum(zcounts(950:962)) + zcounts(963)/2)/sum(zcounts)
txt = 'depth $250-500$ m';
text(-7,0.19,txt,'interpreter','latex','Color', 'k')
txt = '$\sim 56\%$ of histogram area';
text(-7,0.18,txt,'interpreter','latex','Color', 'k')
txt = 'within 95\% confidence interval';
text(-8.5,0.17,txt,'interpreter','latex','Color', 'k')
ylim([0,0.2])
xlabel('$z = \frac{mean(\epsilon^{strain}_i)-mean(\epsilon^{mooring}_i)}{std(\epsilon^{mooring}_i)}$')

[zcounts, zcenters] = hist(zs(p5==2),zcenters);
subplot(1,3,2)
%hist(zs,znbins)
bar(zcenters,zcounts/sum(zcounts))
%plot(zcenters,zcounts/sum(zcounts),'.','markersize',15)
xlim([-10,10])
hold on
a = area([-2,2],[0.45,0.45],'facealpha',0.2)
a(1).FaceColor = [0 0.4470 0.7410];
a(1).EdgeColor = [0 0.4470 0.7410];
% 95% confidence interval calculation
frac95 = (sum(zcounts(952:960)) + zcounts(961)/2)/sum(zcounts)
frac99p7 = (sum(zcounts(950:962)) + zcounts(963)/2)/sum(zcounts)
txt = 'depth $500-1000$ m';
text(-7,0.19,txt,'interpreter','latex','Color', 'k')
txt = '$\sim 74\%$ of histogram area';
text(-7,0.18,txt,'interpreter','latex','Color', 'k')
txt = 'within 95\% confidence interval';
text(-8.5,0.17,txt,'interpreter','latex','Color', 'k')
ylim([0,0.2])
xlabel('$z = \frac{mean(\epsilon^{strain}_i)-mean(\epsilon^{mooring}_i)}{std(\epsilon^{mooring}_i)}$')

[zcounts, zcenters] = hist(zs(p5==3),zcenters);
subplot(1,3,3)
%hist(zs,znbins)
bar(zcenters,zcounts/sum(zcounts))
%plot(zcenters,zcounts/sum(zcounts),'.','markersize',15)
xlim([-10,10])

hold on
a = area([-2,2],[0.45,0.45],'facealpha',0.2)
a(1).FaceColor = [0 0.4470 0.7410];
a(1).EdgeColor = [0 0.4470 0.7410];
% 95% confidence interval calculation
frac95 = (sum(zcounts(952:960)) + zcounts(961)/2)/sum(zcounts)
frac99p7 = (sum(zcounts(950:962)) + zcounts(963)/2)/sum(zcounts)
txt = 'depth $1000-2000$ m';
text(-7,0.19,txt,'interpreter','latex','Color', 'k')
txt = '$\sim 48\%$ of histogram area';
text(-7,0.18,txt,'interpreter','latex','Color', 'k')
txt = 'within 95\% confidence interval';
text(-8.5,0.17,txt,'interpreter','latex','Color', 'k')
xlabel('$z = \frac{mean(\epsilon^{strain}_i)-mean(\epsilon^{mooring}_i)}{std(\epsilon^{mooring}_i)}$')
ylim([0,0.2])


%Too few points to appear in a global heat map
% 
% figure(4);clf;
% subplot(1,3,1)
% surf(Lat,Lon,(mean_e0(:,:,1)),'edgecolor','none')
% view(90,-90)
% %zlim([-11,-6.8])
% xlabel('latitude')
% ylabel('longitude')
% txt = '$250-500$ m';
% title(txt)
% subplot(1,3,2)
% surf(Lat,Lon,(mean_e0(:,:,2)),'edgecolor','none')
% view(90,-90)
% %zlim([-11,-6.8])
% ylabel('longitude')
% txt = '$500-1000$ m';
% title(txt)
% subplot(1,3,3)
% surf(Lat,Lon,(mean_e0(:,:,3)),'edgecolor','none')
% view(90,-90)
% %zlim([-11,-6.8])
% ylabel('longitude')
% txt = '$1000-2000$ m';
% title(txt)