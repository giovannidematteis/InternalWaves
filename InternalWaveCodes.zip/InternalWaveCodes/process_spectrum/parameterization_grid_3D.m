% represent in 2D space of (y,s), where y = 2-nu (continuum slope),
% s=.5(1+mu-nu) (NI slope)

% These are the names of the data associated to the points, in the order
% used throughout the code:
% ['v5a','v5b','v5c','v5d','v7a','v4a','v4b','v2a','v4c','v7b','v1a','v1c',
%  'v0','v1b','v7c','v3','v3a','v2b','v3b','v7d','v6a','v6b','v6c','v6d','v7e']
% respectively:
nu = [0.9,0.9,0.9,0.9,0.9,0.6,0.6,0.6,0.6,0.6,0.31,0.31,0.31,0.31,0.31,0,0,0,0,0,-0.3,-0.3,-0.3,-0.3,-0.3];
mu = [0.9,1.9,2.8,3.6,4.3,0.6,1.6,2.5,3.3,4.0,0.31,1.31,2.21,3.01,3.71,0.,1,1.9,2.7,3.4,-0.3,0.7,1.6,2.4,3.1];
nu = repmat(nu,1,5);
mu = repmat(mu,1,5);
zs = [1.5*ones(1,25),1.8*ones(1,25),2.0*ones(1,25),2.2*ones(1,25),2.5*ones(1,25)];
a = 4 - nu;
%y = a - 2;
%s = 2*a - 7;
sing = .5*(1+mu-nu);

cutoff = 0.03; % based on observations in stretched coordinates

%numerical parameters
nm = 200;
nom = 1000;

% physical constants
params.g = 9.8;
params.f = sin(32.5*pi/180)*2*7.3*10^-5;
params.N = 0.00524; 
params.rho = 1000;
g = params.g;
rho = params.rho;
N = params.N;
N0 = N;
f = params.f;
params.alpha = params.g/params.rho/params.N;
alpha = params.alpha;
params.m_star = 4*pi/1300*g/rho/N^2;
params.m_min = 2*pi/2600*g/rho/N^2;
params.m_max = 2*pi/10*g/rho/N^2;%/5 or /10?
params.k_min = 2*pi/10^5;
params.k_max = 2*pi/5; %for test
% params.m_min = 0;
% params.m_max = 1000;
% params.k_min = 0;
% params.k_max = 1000;
m_star = params.m_star;
m_min = params.m_min;
m_max = params.m_max;
k_min = params.k_min;
k_max = params.k_max;

E = 6.3*10^-5; %GM energy level (non dimensional)
ell = 10;
c = 3;%1;%3
b = 1300;
m_starCart = 4*pi/b;
k_star = c*m_starCart*f/N;

% Parameters for spectrum
s = 2*a - 7;
y = 2-nu;
z = zs; %y*0+2; %m^-2 line
%z = (5+y)/3; %constant flux line
%z = y; %zero flux line
cutNorm = 1.5;
A = E*b^2*rho*f*m_starCart*N/pi^3/N./k_star.^((1-s)/2); %in WKE units
V0sq = N^2/32/g; %correct prefactor

% define domain grid
ms   = load('ms');
os   = load('os');
os_ex  = linspace(((1+cutoff)*f),(N0),nom);
[Os,Ms] = meshgrid(os,ms);
Os       = Os';
Ms       = Ms';
Rs       = sqrt(1./((Os/f).^2 - 1));

%% This loop calculates the kinetic energy on the grid points (with the
%  same prefactor used to compute the fluxes)
KE_th = [];
for ii = 1:125
    n = A(ii)*(f*Ms./Rs/alpha).^(-4+nu(ii)).*(1+Rs.^2).^((mu(ii)-3)/2).*(abs(Ms).^(y(ii)-z(ii)))./(1+(m_star./abs(Ms)).^z(ii));
    en = 4*pi*n.*(Ms.^2).*(Os.^2)/alpha^2*N0^2/g;
    En_h = trapz(ms,en,2);
    KE_th = [KE_th,trapz(os,En_h) + (os(1)-f)*En_h(1)];
end

%% Load, symmetrize and normalize (by KE^2) the flux matrices on the grid points
%m^-2 line
Fs1 = [load('F_v5a_m15');load('F_v5b_m15');load('F_v5c_m15');load('F_v5d_m15');load('F_v7a_m15');load('F_v4a_m15');load('F_v4b_m15');load('F_v2a_m15');load('F_v4c_m15');load('F_v7b_m15');load('F_v1a_m15');load('F_v1c_m15');load('F_v0_m15');load('F_v1b_m15');load('F_v7c_m15');load('F_v3_m15');load('F_v3a_m15');load('F_v2b_m15');load('F_v3b_m15');load('F_v7d_m15');load('F_v6a_m15');load('F_v6b_m15');load('F_v6c_m15');load('F_v6d_m15');load('F_v7e_m15')];
Fs2 = [load('F_v5a_m18');load('F_v5b_m18');load('F_v5c_m18');load('F_v5d_m18');load('F_v7a_m18');load('F_v4a_m18');load('F_v4b_m18');load('F_v2a_m18');load('F_v4c_m18');load('F_v7b_m18');load('F_v1a_m18');load('F_v1c_m18');load('F_v0_m18');load('F_v1b_m18');load('F_v7c_m18');load('F_v3_m18');load('F_v3a_m18');load('F_v2b_m18');load('F_v3b_m18');load('F_v7d_m18');load('F_v6a_m18');load('F_v6b_m18');load('F_v6c_m18');load('F_v6d_m18');load('F_v7e_m18')];
Fs3 = [load('F_v5a_m2');load('F_v5b_m2');load('F_v5c_m2');load('F_v5d_m2');load('F_v7a_m2');load('F_v4a_m2');load('F_v4b_m2');load('F_v2a_m2');load('F_v4c_m2');load('F_v7b_m2');load('F_v1a_m2');load('F_v1c_m2');load('F_v0_m2');load('F_v1b_m2');load('F_v7c_m2');load('F_v3_m2');load('F_v3a_m2');load('F_v2b_m2');load('F_v3b_m2');load('F_v7d_m2');load('F_v6a_m2');load('F_v6b_m2');load('F_v6c_m2');load('F_v6d_m2');load('F_v7e_m2')];
Fs4 = [load('F_v5a_m22');load('F_v5b_m22');load('F_v5c_m22');load('F_v5d_m22');load('F_v7a_m22');load('F_v4a_m22');load('F_v4b_m22');load('F_v2a_m22');load('F_v4c_m22');load('F_v7b_m22');load('F_v1a_m22');load('F_v1c_m22');load('F_v0_m22');load('F_v1b_m22');load('F_v7c_m22');load('F_v3_m22');load('F_v3a_m22');load('F_v2b_m22');load('F_v3b_m22');load('F_v7d_m22');load('F_v6a_m22');load('F_v6b_m22');load('F_v6c_m22');load('F_v6d_m22');load('F_v7e_m22')];
Fs5 = [load('F_v5a_m25');load('F_v5b_m25');load('F_v5c_m25');load('F_v5d_m25');load('F_v7a_m25');load('F_v4a_m25');load('F_v4b_m25');load('F_v2a_m25');load('F_v4c_m25');load('F_v7b_m25');load('F_v1a_m25');load('F_v1c_m25');load('F_v0_m25');load('F_v1b_m25');load('F_v7c_m25');load('F_v3_m25');load('F_v3a_m25');load('F_v2b_m25');load('F_v3b_m25');load('F_v7d_m25');load('F_v6a_m25');load('F_v6b_m25');load('F_v6c_m25');load('F_v6d_m25');load('F_v7e_m25')];
Fs  = [Fs1;Fs2;Fs3;Fs4;Fs5];

% %constant flux line
% Fs = [load('F_v5a_cf');load('F_v5b_cf');load('F_v5c_cf');load('F_v5d_cf');load('F_v7a_cf');load('F_v4a_cf');load('F_v4b_cf');load('F_v2a_cf');load('F_v4c_cf');load('F_v7b_cf');load('F_v1a_cf');load('F_v1c_cf');load('F_v0_cf');load('F_v1b_cf');load('F_v7c_cf');load('F_v3_cf');load('F_v3a_cf');load('F_v2b_cf');load('F_v3b_cf');load('F_v7d_cf');load('F_v6a_cf');load('F_v6b_cf');load('F_v6c_cf');load('F_v6d_cf');load('F_v7e_cf')];
% %zero flux line
% Fs = [load('F_v5a');load('F_v5b');load('F_v5c');load('F_v5d');load('F_v7a');load('F_v4a');load('F_v4b');load('F_v2a');load('F_v4c');load('F_v7b');load('F_v1a');load('F_v1c');load('F_v0');load('F_v1b');load('F_v7c');load('F_v3');load('F_v3a');load('F_v2b');load('F_v3b');load('F_v7d');load('F_v6a');load('F_v6b');load('F_v6c');load('F_v6d');load('F_v7e')];

DissipatedPowers = [];
for ii=1:125
    mat = Fs(((ii-1)*9+1):(ii*9),:);
    mat = (mat - mat')/2;
    %mat
    budget = sum(mat,1);
    DissipatedPower1 =  budget(3) + budget(6) + budget(9);% + budget(8);
    DissipatedPower2 = mat(2,3)*(mat(2,3)>0)+mat(5,6)*(mat(5,6)>0)...
        +mat(8,9)*(mat(8,9)>0)+mat(2,6)*(mat(2,6)>0)+mat(8,6)*(mat(8,6)>0)...
        +mat(5,3)*(mat(5,3)>0)+mat(5,9)*(mat(5,9)>0)+mat(1,3)*(mat(1,3)>0);
    DissipatedPower3 = mat(2,3)*(mat(2,3)>0) + mat(5,6)+mat(8,9)+mat(2,6)+mat(8,6)*(mat(8,6)>0)+mat(5,9)+mat(1,3);
    DissipatedPower4 = mat(1,3) + mat(2,3)*(mat(2,3)>0) + mat(2,6) ...
        + mat(5,3)*(mat(5,3)>0) + mat(5,6) + mat(5,9) + mat(5,8)...
        + mat(5,7)*(mat(5,7)>0) + mat(4,7) + mat(4,8);
    %ii
    %checkPowers = [DissipatedPower1,DissipatedPower2,DissipatedPower3]
    % the above analysis shows that the only flux component that fleeps and strongly
    % goes upscale for large y is mat(2,3), which is inhibited by physical
    % reasons (absence of energy source in box 3, in the dissipation region
    % of shear instability. Thus, DissipatedPower3 appears to be the most appropriate definition)
    DissipatedPowers = [DissipatedPowers,DissipatedPower4];
    Fs(((ii-1)*9+1):(ii*9),:) = mat/KE_th(ii)^2;
    %pause
end
Efficiencies = DissipatedPowers./KE_th;
timescales = 1./Efficiencies/86400 %(days);
E_GM    = 0.003; %J/kg
GM_norm_efficiencies = DissipatedPowers./E_GM;
GM_norm_timescales   = 1./GM_norm_efficiencies/86400 %(days);