function m_solve2 = m_solve2(m1,k1,k2,k,m,f,alpha)
% solves numerically the resonance condition expressing m_1 and m_2 as a
% function of k,k_1,k_2
% k = ;
% m = params.m;
% f = params.f;
m_solve2 = - sqrt(f^2 + alpha^2*k^2/m^2) + sqrt(f^2 + alpha^2*k1^2/m1^2) - sqrt(f^2 + alpha^2*k2^2/(m1-m)^2);
end

