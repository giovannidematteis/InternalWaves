%load flux matrix
Fs = FsR;%load('F')/2*1.5;
F=3*sqrt(abs(Fs)/N^2*g)*200; %for plotting purpose

% spectral parameters
params.nu = 0.31;
params.mu = 2.2;
params.a = 4-params.nu;
a = params.a;
nu = params.nu;
mu = params.mu;

% physical constants
params.g = 9.8;
params.f = sin(32.5*pi/180)*2*7.3*10^-5;
%params.N = 0.00524; 
params.rho = 1000;
g = params.g;
rho = params.rho;
N = params.N;
N0 = N;
f = params.f;
params.alpha = params.g/params.rho/params.N;
alpha = params.alpha;
params.m_star = 4*pi/1300*g/rho/N^2;
params.m_min = 2*pi/2600*g/rho/N^2;
params.m_max = 2*pi/10*g/rho/N^2;%/5 or /10?
params.k_min = 2*pi/10^5;
params.k_max = 2*pi/5; %for test
% params.m_min = 0;
% params.m_max = 1000;
% params.k_min = 0;
% params.k_max = 1000;
m_star = params.m_star;
m_min = params.m_min;
m_max = params.m_max;
k_min = params.k_min;
k_max = params.k_max;

E = 6.3*10^-5; %GM energy level (non dimensional)
ell = 10;
c = 3;
b = 1300;
m_starCart = 4*pi/b;
k_star = c*m_starCart*f/N;

% Parameters for spectrum
s = 2*a - 7;
A = E*b^2*rho*f*m_starCart*N/pi^3/N/k_star^((1-s)/2);
V0sq = N^2/32/g;

%dimensionally correct fluxes:
%Fs = Fs*N0^2/g;


%% Plot Fourier space divided in 9 regions
figure(5);%clf;
% 
%subplot(1,2,2)

set(gca,'TickLabelInterpreter','latex')
set(groot,'defaulttextinterpreter','latex');
set(groot,'defaultLegendInterpreter','latex');

budget = sum(Fs,1);
flux = sum(abs(Fs),1)/2;
Nbudget=budget/(sum(abs(budget))/2)*100;
Nflux=flux/(sum(abs(budget))/2)*100;
DissipatedPower0 = budget(3) + budget(6) + budget(9) + budget(8) + budget(7)
DissipatedPower1 = sum(abs(budget))/2
DissipatedPower2 = Fs(2,3)*(Fs(2,3)>0)+Fs(5,6)+Fs(8,9)+Fs(2,6)+Fs(8,6)*(Fs(5,3)>0)+Fs(5,9)+Fs(1,3)
DissipatedPower3 = Fs(2,3)*(Fs(2,3)>0)+Fs(5,6)+Fs(2,6)+Fs(1,3) %only vertical

pause



%areas
X = log([1 260 260.001 2600]);
Y = log([20 0 3.35; 20 0 3.35; 0 0 67; 0 0 67]);
ylim(log([1, 67]));
aa = area(X,Y,'FaceAlpha', 0.3);
newcolors = [1 1 1; 0.8500 0.3250 0.0980; 0 0.4470 0.7410];
colororder(newcolors)
hold on
set(gca,'TickLabelInterpreter','latex')
set(groot,'defaulttextinterpreter','latex');
set(groot,'defaultLegendInterpreter','latex');
plot([log(1),log(10*m_max/m_min)],log([1,1]),'k', 'linewidth',1.5)
hold on
loglog(log([1,10*m_max/m_min]),log([N/f,N/f]),'k', 'linewidth',1.5)
loglog(log([1,1]),log([1,N/f]),'k', 'linewidth',1.5)
loglog(log([10*m_max/m_min,10*m_max/m_min]),log([1,N/f]),'k', 'linewidth',1.5)
loglog(log([m_max/m_min,m_max/m_min]),log([1,N/f]),'k', 'linewidth',1.5)
loglog(log([20,20]),log([1,N/f]),'k', 'linewidth',1.5)
loglog(log([1,10*m_max/m_min]),log([5,5]),'k', 'linewidth',1.5)
loglog(log([1,10*m_max/m_min]),log([20,20]),'k', 'linewidth',1.5)
xlim(log([1,10*m_max/m_min]))
ylim(log([1,N/f]))
xticks(log([1 20 260 2600]))
xticklabels({'$1$','$20$','$260$','$2600$'})
yticks(log([1 5 20 67]))
yticklabels({'$f$','$5f$','$20f$','$N$'})
xlabel('$m$ (units of mode $1$)')
ylabel('$\omega$','Interpreter','latex')
ph = 1.3;
pv = 1.17;
plot(log([1,260]),log([20,20]),'color',[0.6350 0.0780 0.1840],'linewidth',3)
plot(log([260,260]),log([1,20]),'color',[0.6350 0.0780 0.1840],'linewidth',3)


%draw arrows: 

drawArrow = @(x,y,varargin) quiver( x(1),x(2),y(1)-x(1),y(2)-x(2),0, varargin{:} )  ;
P1h = log([11.5,2.3]);
P2h = log([36,2.3]);
P1v = log([4.5,3.5]);
P2v = log([4.5,7]);
%12
w=F(1,2);
p1 = P1h;
p2 = P2h;
% drawArrow(p1,p2,'MaxHeadSize',.5,'linewidth',w,'color',[0.8500, 0.3250, 0.0980])
X = [p1(1)/log(2600)   p2(1)/log(2600)]/1.3+0.13;
Y = [p1(2)/log(67)     p2(2)/log(67)]/1.20+0.10;
annotation('arrow',X,Y,'linestyle','-','color',[0.8500, 0.3250, 0.0980],'linewidth',w,'headlength',15,'headwidth',w*4,'units','normalized')

%12
w=F(1,3);
p1 = P1h+log([1,0.7]);
p2 = P2h+log([260/18,0.7]);
% drawArrow(p1,p2,'MaxHeadSize',.5,'linewidth',w,'color',[0.8500, 0.3250, 0.0980])
X = [p1(1)/log(2600)   p2(1)/log(2600)]/1.3+0.13;
Y = [p1(2)/log(67)     p2(2)/log(67)]/1.20+0.10;
annotation('arrow',X,Y,'linestyle','-','color',[0.8500, 0.3250, 0.0980],'linewidth',w,'headlength',15,'headwidth',w*4,'units','normalized')

%14
w=F(1,4);
p1 = P1v;
p2 = P2v;
% drawArrow(p1,p2,'MaxHeadSize',.5,'linewidth',w,'color',[0.8500, 0.3250, 0.0980])
X = [p1(1)/log(2600)   p2(1)/log(2600)]/1.3+0.13;
Y = [p1(2)/log(67)     p2(2)/log(67)]/1.20+0.10;
annotation('arrow',X,Y,'linestyle','-','color',[0.8500, 0.3250, 0.0980],'linewidth',w,'headlength',15,'headwidth',w*4,'units','normalized')

%15
w=F(1,5);
p1 = P1v+log([3.3,1.1]);
p2 = P2v+log([6.4,1]);
% drawArrow(p1,p2,'MaxHeadSize',.5,'linewidth',w,'color',[0.8500, 0.3250, 0.0980])
X = [p1(1)/log(2600)   p2(1)/log(2600)]/1.3+0.13;
Y = [p1(2)/log(67)     p2(2)/log(67)]/1.20+0.10;
annotation('arrow',X,Y,'linestyle','-','color',[0.8500, 0.3250, 0.0980],'linewidth',w,'headlength',15,'headwidth',w*4,'units','normalized')

%23
w=F(2,3);
p1 = P1h+log([260/20,1]);
p2 = P2h+log([260/20,1]);
% drawArrow(p1,p2,'MaxHeadSize',.5,'linewidth',w,'color',[0.8500, 0.3250, 0.0980])
X = [p1(1)/log(2600)   p2(1)/log(2600)]/1.3+0.13;
Y = [p1(2)/log(67)     p2(2)/log(67)]/1.20+0.10;
annotation('arrow',X,Y,'linestyle','-','color',[0.8500, 0.3250, 0.0980],'linewidth',w,'headlength',15,'headwidth',w*4,'units','normalized')

%24
w=F(2,4);
p1 = P1v+log([6.4*12/260*20,1.1]);
p2 = P2v+log([3.3*12/260*20,1]);
% drawArrow(p1,p2,'MaxHeadSize',.5,'linewidth',w,'color',[0.8500, 0.3250, 0.0980])
X = [p1(1)/log(2600)   p2(1)/log(2600)]/1.3+0.13;
Y = [p1(2)/log(67)     p2(2)/log(67)]/1.20+0.10;
annotation('arrow',X,Y,'linestyle','-','color',[0.8500, 0.3250, 0.0980],'linewidth',w,'headlength',15,'headwidth',w*4,'units','normalized')

%25
w=F(2,5);
p1 = P1v+log([260/17,1]);
p2 = P2v+log([260/17,1]);
% drawArrow(p1,p2,'MaxHeadSize',.5,'linewidth',w,'color',[0.8500, 0.3250, 0.0980])
X = [p1(1)/log(2600)   p2(1)/log(2600)]/1.3+0.13;
Y = [p1(2)/log(67)     p2(2)/log(67)]/1.20+0.10;
annotation('arrow',X,Y,'linestyle','-','color',[0.8500, 0.3250, 0.0980],'linewidth',w,'headlength',15,'headwidth',w*4,'units','normalized')

%26
w=F(2,6);
p1 = P1v+log([3.3*260/20,1.1]);
p2 = P2v+log([6.4*260/20,1]);
% drawArrow(p1,p2,'MaxHeadSize',.5,'linewidth',w,'color',[0.8500, 0.3250, 0.0980])
X = [p1(1)/log(2600)   p2(1)/log(2600)]/1.3+0.13;
Y = [p1(2)/log(67)     p2(2)/log(67)]/1.20+0.10;
annotation('arrow',X,Y,'linestyle','-','color',[0.8500, 0.3250, 0.0980],'linewidth',w,'headlength',15,'headwidth',w*4,'units','normalized')

%35
w=F(3,5);
p1 = P1v+log([6.4*12,1.1]);
p2 = P2v+log([3.3*12,1]);
% drawArrow(p1,p2,'MaxHeadSize',.5,'linewidth',w,'color',[0.8500, 0.3250, 0.0980])
X = [p1(1)/log(2600)   p2(1)/log(2600)]/1.3+0.13;
Y = [p1(2)/log(67)     p2(2)/log(67)]/1.20+0.10;
annotation('arrow',X,Y,'linestyle','-','color',[0.8500, 0.3250, 0.0980],'linewidth',w,'headlength',15,'headwidth',w*4,'units','normalized')

%36
w=F(3,6);
p1 = P1v+log([175,1]);
p2 = P2v+log([175,1]);
% drawArrow(p1,p2,'MaxHeadSize',.5,'linewidth',w,'color',[0.8500, 0.3250, 0.0980])
X = [p1(1)/log(2600)   p2(1)/log(2600)]/1.3+0.13;
Y = [p1(2)/log(67)     p2(2)/log(67)]/1.20+0.10;
%annotation('arrow',X,Y,'linestyle','-','color',[0.7, 0.7, 0.7],'linewidth',w,'headlength',w*4,'headwidth',w*4,'units','normalized')

%45
w=F(4,5);
p1 = P1h+log([1,25/5]);
p2 = P2h+log([1,25/5]);
% drawArrow(p1,p2,'MaxHeadSize',.5,'linewidth',w,'color',[0.8500, 0.3250, 0.0980])
X = [p1(1)/log(2600)   p2(1)/log(2600)]/1.3+0.13;
Y = [p1(2)/log(67)     p2(2)/log(67)]/1.20+0.10;
annotation('arrow',X,Y,'linestyle','-','color',[0.8500, 0.3250, 0.0980],'linewidth',w,'headlength',15,'headwidth',w*4,'units','normalized')

%47
w=F(4,7);
p1 = P1v+log([1,20/5]);
p2 = P2v+log([1,20/5]);
% drawArrow(p1,p2,'MaxHeadSize',.5,'linewidth',w,'color',[0.8500, 0.3250, 0.0980])
X = [p1(1)/log(2600)   p2(1)/log(2600)]/1.3+0.13;
Y = [p1(2)/log(67)     p2(2)/log(67)]/1.20+0.10;
annotation('arrow',X,Y,'linestyle','-','color',[0.8500, 0.3250, 0.0980],'linewidth',w,'headlength',15,'headwidth',w*4,'units','normalized')

%48
w=F(4,8);
p1 = P1v+log([3.3,1.1*20/5]);
p2 = P2v+log([6.4,20/5]);
% drawArrow(p1,p2,'MaxHeadSize',.5,'linewidth',w,'color',[0.8500, 0.3250, 0.0980])
X = [p1(1)/log(2600)   p2(1)/log(2600)]/1.3+0.13;
Y = [p1(2)/log(67)     p2(2)/log(67)]/1.20+0.10;
annotation('arrow',X,Y,'linestyle','-','color',[0.8500, 0.3250, 0.0980],'linewidth',w,'headlength',15,'headwidth',w*4,'units','normalized')

%56
w=F(5,6);
p1 = P1h+log([260/20,25/5]);
p2 = P2h+log([260/20,25/5]);
% drawArrow(p1,p2,'MaxHeadSize',.5,'linewidth',w,'color',[0.8500, 0.3250, 0.0980])
X = [p1(1)/log(2600)   p2(1)/log(2600)]/1.3+0.13;
Y = [p1(2)/log(67)     p2(2)/log(67)]/1.20+0.10;
annotation('arrow',X,Y,'linestyle','-','color',[0.8500, 0.3250, 0.0980],'linewidth',w,'headlength',15,'headwidth',w*4,'units','normalized')

%57
w=F(5,7);
p1 = P1v+log([6.4*12/260*20,1.1*20/5]);
p2 = P2v+log([3.3*12/260*20,20/5]);
% drawArrow(p1,p2,'MaxHeadSize',.5,'linewidth',w,'color',[0.8500, 0.3250, 0.0980])
X = [p1(1)/log(2600)   p2(1)/log(2600)]/1.3+0.13;
Y = [p1(2)/log(67)     p2(2)/log(67)]/1.20+0.10;
annotation('arrow',X,Y,'linestyle','-','color',[0.8500, 0.3250, 0.0980],'linewidth',w,'headlength',15,'headwidth',w*4,'units','normalized')

%58
w=F(5,8);
p1 = P1v+log([260/17,20/5]);
p2 = P2v+log([260/17,20/5]);
% drawArrow(p1,p2,'MaxHeadSize',.5,'linewidth',w,'color',[0.8500, 0.3250, 0.0980])
X = [p1(1)/log(2600)   p2(1)/log(2600)]/1.3+0.13;
Y = [p1(2)/log(67)     p2(2)/log(67)]/1.20+0.10;
annotation('arrow',X,Y,'linestyle','-','color',[0.8500, 0.3250, 0.0980],'linewidth',w,'headlength',15,'headwidth',w*4,'units','normalized')

%59
w=F(5,9);
p1 = P1v+log([3.3*260/20,1.1*20/5]);
p2 = P2v+log([6.4*260/20,20/5]);
% drawArrow(p1,p2,'MaxHeadSize',.5,'linewidth',w,'color',[0.8500, 0.3250, 0.0980])
X = [p1(1)/log(2600)   p2(1)/log(2600)]/1.3+0.13;
Y = [p1(2)/log(67)     p2(2)/log(67)]/1.20+0.10;
annotation('arrow',X,Y,'linestyle','-','color',[0.8500, 0.3250, 0.0980],'linewidth',w,'headlength',15,'headwidth',w*4,'units','normalized')

%68
w=F(6,8);
p1 = P1v+log([6.4*12,1.1*20/5]);
p2 = P2v+log([3.3*12,1*20/5]);
% drawArrow(p1,p2,'MaxHeadSize',.5,'linewidth',w,'color',[0.8500, 0.3250, 0.0980])
X = [p1(1)/log(2600)   p2(1)/log(2600)]/1.3+0.13;
Y = [p1(2)/log(67)     p2(2)/log(67)]/1.20+0.10;
annotation('arrow',X,Y,'linestyle','-','color',[0.8500, 0.3250, 0.0980],'linewidth',w,'headlength',15,'headwidth',w*4,'units','normalized')

%69
w=F(6,9);
p1 = P1v+log([175,20/5]);
p2 = P2v+log([175,20/5]);
%drawArrow(p1,p2,'MaxHeadSize',.5,'linewidth',w,'color',[0.8500, 0.3250, 0.0980])
X = [p1(1)/log(2600)   p2(1)/log(2600)]/1.3+0.13;
Y = [p1(2)/log(67)     p2(2)/log(67)]/1.20+0.10;
%annotation('arrow',X,Y,'linestyle','-','color',[0.7, 0.7, 0.7],'linewidth',w,'headlength',w*4,'headwidth',w*4,'units','normalized')

%78
w=F(7,8);
p1 = P1h+log([1,25/5*22/5]);
p2 = P2h+log([1,25/5*22/5]);
%drawArrow(p1,p2,'MaxHeadSize',.5,'linewidth',w,'color',[0.8500, 0.3250, 0.0980])
X = [p1(1)/log(2600)   p2(1)/log(2600)]/1.3+0.13;
Y = [p1(2)/log(67)     p2(2)/log(67)]/1.20+0.10;
annotation('arrow',X,Y,'linestyle','-','color',[0.8500, 0.3250, 0.0980],'linewidth',w,'headlength',15,'headwidth',w*4,'units','normalized')

%89
w=F(8,9);
p1 = P1h+log([1*260/20,25/5*22/5]);
p2 = P2h+log([1*260/20,25/5*22/5]);
%drawArrow(p1,p2,'MaxHeadSize',.5,'linewidth',w,'color',[0.8500, 0.3250, 0.0980])
X = [p1(1)/log(2600)   p2(1)/log(2600)]/1.3+0.13;
Y = [p1(2)/log(67)     p2(2)/log(67)]/1.20+0.10;
annotation('arrow',X,Y,'linestyle','-','color',[0.8500, 0.3250, 0.0980],'linewidth',w,'headlength',15,'headwidth',w*4,'units','normalized')


% txt = ['(I) $b=$', num2str(round(Nbudget(1))),'$\%$, f=', num2str(round(Nflux(1))),'$\%$'];
% %txt = '(I) b=';
% text(log(ph),log(pv),txt)
% txt = ['(IV) $b=$', num2str(round(Nbudget(4))),'$\%$, f=', num2str(round(Nflux(4))),'$\%$'];
% text(log(ph),log(pv*5),txt)
% txt = ['(VII) $b=$', num2str(round(Nbudget(7))),'$\%$, f=', num2str(round(Nflux(7))),'$\%$'];
% text(log(ph),log(pv*20),txt)
% txt = ['(II) $b=$', num2str(round(Nbudget(2))),'$\%$, f=', num2str(round(Nflux(2))),'$\%$'];
% text(log(ph*20),log(pv),txt)
% txt = ['(III) $b=$', num2str(round(Nbudget(3))),'$\%$, f=', num2str(round(Nflux(3))),'$\%$'];
% text(log(ph*260),log(pv),txt)
% txt = ['(V) $b=$', num2str(round(Nbudget(5))),'$\%$, f=', num2str(round(Nflux(5))),'$\%$'];
% text(log(ph*20),log(pv*5),txt)
% txt = ['(VI) $b=$', num2str(round(Nbudget(6))),'$\%$, f=', num2str(round(Nflux(6))),'$\%$'];
% text(log(ph*260),log(pv*5),txt)
% txt = ['(VIII) $b=$', num2str(round(Nbudget(8))),'$\%$, f=', num2str(round(Nflux(8))),'$\%$'];
% text(log(ph*20),log(pv*20),txt)
% txt = ['(IX) $b=$', num2str(round(Nbudget(9))),'$\%$, f=', num2str(round(Nflux(9))),'$\%$'];
% text(log(ph*260),log(pv*20),txt)


txt = ['(1)'];
%txt = '(I) b=';
text(log(ph),log(pv),txt)
txt = ['(4)'];
text(log(ph),log(pv*5),txt)
txt = ['(7)'];
text(log(ph),log(pv*20),txt)
txt = ['(2)'];
text(log(ph*20),log(pv),txt)
txt = ['(3)'];
text(log(ph*260),log(pv),txt)
txt = ['(5)'];
text(log(ph*20),log(pv*5),txt)
txt = ['(6)'];
text(log(ph*260),log(pv*5),txt)
txt = ['(8)'];
text(log(ph*20),log(pv*20),txt)
txt = ['(9)'];
text(log(ph*260),log(pv*20),txt)

axis tight


% function [ h ] = drawArrow( x,y )
% 
% h = annotation('arrow');
% set(h,'parent', gca, ...
%     'position', [x(1),x(2),y(1)-x(1),y(2)-x(2)], ...
%     'HeadLength', 10, 'HeadWidth', 10, 'HeadStyle', 'cback1');
% 
% end 





% %areas
% X = log([1 260 260.001 2600]);
% Y = log([20 0 3.35; 20 0 3.35; 0 0 67; 0 0 67]);
% ylim(log([1, 67]));
% aa = area(X,Y,'FaceAlpha', 0.3);
% newcolors = [1 1 1; 0.8500 0.3250 0.0980; 0 0.4470 0.7410];
% colororder(newcolors)
% hold on
% set(gca,'TickLabelInterpreter','latex')
% set(groot,'defaulttextinterpreter','latex');
% set(groot,'defaultLegendInterpreter','latex');
% plot([log(1),log(10*m_max/m_min)],log([1,1]),'k', 'linewidth',1.5)
% hold on
% loglog(log([1,10*m_max/m_min]),log([N/f,N/f]),'k', 'linewidth',1.5)
% loglog(log([1,1]),log([1,N/f]),'k', 'linewidth',1.5)
% loglog(log([10*m_max/m_min,10*m_max/m_min]),log([1,N/f]),'k', 'linewidth',1.5)
% loglog(log([m_max/m_min,m_max/m_min]),log([1,N/f]),'k', 'linewidth',1.5)
% loglog(log([20,20]),log([1,N/f]),'k', 'linewidth',1.5)
% loglog(log([1,10*m_max/m_min]),log([5,5]),'k', 'linewidth',1.5)
% loglog(log([1,10*m_max/m_min]),log([20,20]),'k', 'linewidth',1.5)
% xlim(log([1,10*m_max/m_min]))
% ylim(log([1,N/f]))
% xticks(log([1 20 260 2600]))
% xticklabels({'$1$','$20$','$260$','$2600$'})
% yticks(log([1 5 20 67]))
% yticklabels({'$f$','$5f$','$20f$','$N$'})
% xlabel('$m$ (units of mode $1$)')
% ylabel('$\omega$','Interpreter','latex')
% ph = 1.3;
% pv = 1.17;
% plot(log([1,260]),log([20,20]),'m','linewidth',3)
% plot(log([260,260]),log([1,20]),'m','linewidth',3)
% 
% 
% %draw arrows: 
% 
% drawArrow = @(x,y,varargin) quiver( x(1),x(2),y(1)-x(1),y(2)-x(2),0, varargin{:} )  ;
% P1h = log([11.5,2.3]);
% P2h = log([36,2.3]);
% P1v = log([4.5,3.5]);
% P2v = log([4.5,7]);
% %12
% w=F(1,2);
% p1 = P1h;
% p2 = P2h;
% drawArrow(p1,p2,'MaxHeadSize',.5,'linewidth',w,'color',[0.8500, 0.3250, 0.0980])
% %12
% w=F(1,3);
% p1 = P1h+log([1,0.7]);
% p2 = P2h+log([260/18,0.7]);
% drawArrow(p1,p2,'MaxHeadSize',.5,'linewidth',w,'color',[0.8500, 0.3250, 0.0980])
% %14
% w=F(1,4);
% p1 = P1v;
% p2 = P2v;
% drawArrow(p1,p2,'MaxHeadSize',.5,'linewidth',w,'color',[0.8500, 0.3250, 0.0980])
% %15
% w=F(1,5);
% p1 = P1v+log([3.3,1.1]);
% p2 = P2v+log([6.4,1]);
% drawArrow(p1,p2,'MaxHeadSize',.5,'linewidth',w,'color',[0.8500, 0.3250, 0.0980])
% %23
% w=F(2,3);
% p1 = P1h+log([260/20,1]);
% p2 = P2h+log([260/20,1]);
% drawArrow(p1,p2,'MaxHeadSize',.5,'linewidth',w,'color',[0.8500, 0.3250, 0.0980])
% %24
% w=F(2,4);
% p1 = P1v+log([6.4*12/260*20,1.1]);
% p2 = P2v+log([3.3*12/260*20,1]);
% drawArrow(p1,p2,'MaxHeadSize',.5,'linewidth',w,'color',[0.8500, 0.3250, 0.0980])
% %25
% w=F(2,5);
% p1 = P1v+log([260/17,1]);
% p2 = P2v+log([260/17,1]);
% drawArrow(p1,p2,'MaxHeadSize',.5,'linewidth',w,'color',[0.8500, 0.3250, 0.0980])
% %26
% w=F(2,6);
% p1 = P1v+log([3.3*260/20,1.1]);
% p2 = P2v+log([6.4*260/20,1]);
% drawArrow(p1,p2,'MaxHeadSize',.5,'linewidth',w,'color',[0.8500, 0.3250, 0.0980])
% %35
% w=F(3,5);
% p1 = P1v+log([6.4*12,1.1]);
% p2 = P2v+log([3.3*12,1]);
% drawArrow(p1,p2,'MaxHeadSize',.5,'linewidth',w,'color',[0.8500, 0.3250, 0.0980])
% %36
% w=F(3,6);
% p1 = P1v+log([175,1]);
% p2 = P2v+log([175,1]);
% drawArrow(p1,p2,'MaxHeadSize',.5,'linewidth',w,'color',[0.8500, 0.3250, 0.0980])
% %45
% w=F(4,5);
% p1 = P1h+log([1,25/5]);
% p2 = P2h+log([1,25/5]);
% drawArrow(p1,p2,'MaxHeadSize',.5,'linewidth',w,'color',[0.8500, 0.3250, 0.0980])
% %47
% w=F(4,7);
% p1 = P1v+log([1,20/5]);
% p2 = P2v+log([1,20/5]);
% drawArrow(p1,p2,'MaxHeadSize',.5,'linewidth',w,'color',[0.8500, 0.3250, 0.0980])
% %48
% w=F(4,8);
% p1 = P1v+log([3.3,1.1*20/5]);
% p2 = P2v+log([6.4,20/5]);
% drawArrow(p1,p2,'MaxHeadSize',.5,'linewidth',w,'color',[0.8500, 0.3250, 0.0980])
% %56
% w=F(5,6);
% p1 = P1h+log([260/20,25/5]);
% p2 = P2h+log([260/20,25/5]);
% drawArrow(p1,p2,'MaxHeadSize',.5,'linewidth',w,'color',[0.8500, 0.3250, 0.0980])
% %57
% w=F(5,7);
% p1 = P1v+log([6.4*12/260*20,1.1*20/5]);
% p2 = P2v+log([3.3*12/260*20,20/5]);
% drawArrow(p1,p2,'MaxHeadSize',.5,'linewidth',w,'color',[0.8500, 0.3250, 0.0980])
% %58
% w=F(5,8);
% p1 = P1v+log([260/17,20/5]);
% p2 = P2v+log([260/17,20/5]);
% drawArrow(p1,p2,'MaxHeadSize',.5,'linewidth',w,'color',[0.8500, 0.3250, 0.0980])
% %59
% w=F(5,9);
% p1 = P1v+log([3.3*260/20,1.1*20/5]);
% p2 = P2v+log([6.4*260/20,20/5]);
% drawArrow(p1,p2,'MaxHeadSize',.5,'linewidth',w,'color',[0.8500, 0.3250, 0.0980])
% %68
% w=F(6,8);
% p1 = P1v+log([6.4*12,1.1*20/5]);
% p2 = P2v+log([3.3*12,1*20/5]);
% drawArrow(p1,p2,'MaxHeadSize',.5,'linewidth',w,'color',[0.8500, 0.3250, 0.0980])
% %69
% w=F(6,9);
% p1 = P1v+log([175,20/5]);
% p2 = P2v+log([175,20/5]);
% drawArrow(p1,p2,'MaxHeadSize',.5,'linewidth',w,'color',[0.8500, 0.3250, 0.0980])
% %78
% w=F(7,8);
% p1 = P1h+log([1,25/5*22/5]);
% p2 = P2h+log([1,25/5*22/5]);
% drawArrow(p1,p2,'MaxHeadSize',.5,'linewidth',w,'color',[0.8500, 0.3250, 0.0980])
% %89
% w=F(8,9);
% p1 = P1h+log([1*260/20,25/5*22/5]);
% p2 = P2h+log([1*260/20,25/5*22/5]);
% drawArrow(p1,p2,'MaxHeadSize',.5,'linewidth',w,'color',[0.8500, 0.3250, 0.0980])
% 
% % txt = ['(I) $b=$', num2str(round(Nbudget(1))),'$\%$, f=', num2str(round(Nflux(1))),'$\%$'];
% % %txt = '(I) b=';
% % text(log(ph),log(pv),txt)
% % txt = ['(IV) $b=$', num2str(round(Nbudget(4))),'$\%$, f=', num2str(round(Nflux(4))),'$\%$'];
% % text(log(ph),log(pv*5),txt)
% % txt = ['(VII) $b=$', num2str(round(Nbudget(7))),'$\%$, f=', num2str(round(Nflux(7))),'$\%$'];
% % text(log(ph),log(pv*20),txt)
% % txt = ['(II) $b=$', num2str(round(Nbudget(2))),'$\%$, f=', num2str(round(Nflux(2))),'$\%$'];
% % text(log(ph*20),log(pv),txt)
% % txt = ['(III) $b=$', num2str(round(Nbudget(3))),'$\%$, f=', num2str(round(Nflux(3))),'$\%$'];
% % text(log(ph*260),log(pv),txt)
% % txt = ['(V) $b=$', num2str(round(Nbudget(5))),'$\%$, f=', num2str(round(Nflux(5))),'$\%$'];
% % text(log(ph*20),log(pv*5),txt)
% % txt = ['(VI) $b=$', num2str(round(Nbudget(6))),'$\%$, f=', num2str(round(Nflux(6))),'$\%$'];
% % text(log(ph*260),log(pv*5),txt)
% % txt = ['(VIII) $b=$', num2str(round(Nbudget(8))),'$\%$, f=', num2str(round(Nflux(8))),'$\%$'];
% % text(log(ph*20),log(pv*20),txt)
% % txt = ['(IX) $b=$', num2str(round(Nbudget(9))),'$\%$, f=', num2str(round(Nflux(9))),'$\%$'];
% % text(log(ph*260),log(pv*20),txt)
% 
% 
% txt = ['(1)'];
% %txt = '(I) b=';
% text(log(ph),log(pv),txt)
% txt = ['(4)'];
% text(log(ph),log(pv*5),txt)
% txt = ['(7)'];
% text(log(ph),log(pv*20),txt)
% txt = ['(2)'];
% text(log(ph*20),log(pv),txt)
% txt = ['(3)'];
% text(log(ph*260),log(pv),txt)
% txt = ['(5)'];
% text(log(ph*20),log(pv*5),txt)
% txt = ['(6)'];
% text(log(ph*260),log(pv*5),txt)
% txt = ['(8)'];
% text(log(ph*20),log(pv*20),txt)
% txt = ['(9)'];
% text(log(ph*260),log(pv*20),txt)
% 
% axis tight
% 
% 
% % function [ h ] = drawArrow( x,y )
% % 
% % h = annotation('arrow');
% % set(h,'parent', gca, ...
% %     'position', [x(1),x(2),y(1)-x(1),y(2)-x(2)], ...
% %     'HeadLength', 10, 'HeadWidth', 10, 'HeadStyle', 'cback1');
% % 
% % end 