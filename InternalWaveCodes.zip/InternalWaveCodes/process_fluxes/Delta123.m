function Delta123 = Delta123(k1,k2,k3) % computes the matrix element
    Delta123 = 1/2*sqrt(2*((k1*k2)^2 + (k1*k3)^2 + (k2*k3)^2) - k1^4 - k2^4 - k3^4);
end