function Vsq123 = Vsq123(k1,k2,k3,om1,om2,om3,f) % computes the matrix element
%f=0;
    Vsq123 = (.5*(k1^2 + k2^2 - k3^2)*k3/k1/k2*(om1*om2 + f^2)/sqrt(om1*om2*om3) + .5*(k1^2 + k3^2 - k2^2)*k2/k1/k3*(om1*om3 + f^2)/sqrt(om1*om2*om3) + .5*(k1^2 - k2^2 - k3^2)*k1/k2/k3*(om2*om3 - f^2)/sqrt(om1*om2*om3))^2 + f^2*(k2^2*k3^2 - (-k1^2 + k2^2 + k3^2)^2/4)/((k1*k2*k3)^2*om1*om2*om3)*(om1*(k2^2-k3^2) + om2*(k1^2-k3^2) + om3*(k2^2-k1^2))^2;
end