function [m2,m3] = m3b(k,k2,k3,m,params)
    m2 = -m/2/k*(k - k2 + k3 + sqrt((k - k2 + k3)^2 + 4*k*k2));
    m3 = m + m2;
end