function V312 = V312(k1,k2,k3,m1,m2,m3) % computes the matrix element
    V312 = sqrt(k1*k2*k3)*((k3^2 - k1^2 - k2^2)/(2*k1*k2)*sqrt(abs(m3/m1/m2)) + (k1^2 + k3^2 - k2^2)/(2*k1*k3)*sqrt(abs(m2/m1/m3)) + (k2^2 + k3^2 - k1^2)/(2*k2*k3)*sqrt(abs(m1/m2/m3)));
end