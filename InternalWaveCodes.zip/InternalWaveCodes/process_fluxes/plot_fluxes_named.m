%% Run script after 'process_signed_named.m'

%load flux matrix
%Fs = FsR;%load('F')/2*1.5;
%F=3*sqrt(abs(Fs)/N^2*g)*200; %for plotting purpose

% spectral parameters
params.nu = 0.;%0.;%
params.mu = 1.9;%0;%
params.a = 4-params.nu;
params.z = 2-params.nu;
a = params.a;
z = 2
nu = params.nu;
mu = params.mu;
s = 0.5*(1+mu-nu)
y = 2-nu
pause

% physical constants
params.g = 9.8;
params.f = sin(32.5*pi/180)*2*7.3*10^-5;
params.N = 0.00524; 
params.rho = 1000;
g = params.g;
rho = params.rho;
N = params.N;
N0 = N;
f = params.f;
f0 = f;
params.alpha = params.g/params.rho/params.N;
alpha = params.alpha;
params.m_star = 4*pi/1300*g/rho/N^2;
params.m_min = 2*pi/2600*g/rho/N^2;
params.m_max = 2*pi/10*g/rho/N^2;%/5 or /10?
params.k_min = 2*pi/10^5;
params.k_max = 2*pi/5; %for test
% params.m_min = 0;
% params.m_max = 1000;
% params.k_min = 0;
% params.k_max = 1000;
m_star = params.m_star;
m_min = params.m_min;
m_max = params.m_max;
k_min = params.k_min;
k_max = params.k_max;

E = 6.3*10^-5; %GM energy level (non dimensional)
ell = 10;
c = 3;
b = 1300;
m_starCart = 4*pi/b;
k_star = c*m_starCart*f/N;

% Parameters for spectrum
ss = 2*a - 7;
A = E*b^2*rho*f*m_starCart*N/pi^3/N/k_star^((1-ss)/2);
V0sq = N^2/32/g;

% define domain grid
cutoff = 0.03;
ms   = load('ms');
%ms = ms(1:100);
os   = load('os');
%os_ex  = linspace(((1+cutoff)*f),(N0),nom);
[Os,Ms] = meshgrid(os,ms);
Os       = Os';
Ms       = Ms';
Rs       = sqrt(1./((Os/f).^2 - 1));


%% calculate Kin Energy
ns = A*(f*Ms./Rs/alpha).^(-4+nu).*(1+Rs.^2).^((mu-3)/2).*(abs(Ms).^(y-z))./(1+(m_star./abs(Ms)).^z);
en    = 4*pi*ns.*(Ms.^2).*(Os.^2)/alpha^2*N0^2/g;
En_h  = trapz(ms,en,2); % integrate in vertical wavenumber
En_m  = trapz(os,en,1); % integrate in frequency
E_tot = trapz(os,En_h) + (os(1)-f0)*En_h(1) % total energy not normalized
E_tot_n = E_tot;
save('En_o_NI','En_h','-ascii')
save('En_m_NI','En_m','-ascii')
pause


%% use the following 4 lines if want to impose a given total energy
KinEn = 0.0023; %For instance, this imposes the standard GM total energy
norm_factor = KinEn/E_tot;
E_tot = KinEn;
en    = en*norm_factor; % normalized 2D energy density
ns    = ns*norm_factor; % normalized 2D energy density
A     = A*norm_factor; % normalized 2D energy density


%% Plot Fourier space divided in 9 regions
figure(7);clf;
% 
%subplot(1,2,2)

set(gca,'TickLabelInterpreter','latex')
set(groot,'defaulttextinterpreter','latex');
set(groot,'defaultLegendInterpreter','latex');

Fi = Fs_GM/E_tot_n^2;%0.0023^2; %Energy squared normalized fluxes like in parameterization 
%Fi = interpolant3D(y,s,z,Fs,params); %calculate fluxes from interpolation on 2D parameterization grid

DissipatedPowerGood = +Fi(1,3) + Fi(2,3)*(Fi(2,3)>0)+Fi(2,6)+Fi(5,6)+Fi(5,9)+Fi(4,7)+Fi(5,8)+Fi(4,8)+Fi(5,7);
DissipatedPowerGood = DissipatedPowerGood*(E_tot^2)*(f/f0)
F=-3*3*sqrt(abs(Fi))*200*(E_tot)/0.003; %for plotting purpose
%F_ID_p = 
pause


% Fs = (Fs - Fs')/2;
% budget = sum(Fs,1);
% flux = sum(abs(Fs),1)/2;
% Nbudget=budget/(sum(abs(budget))/2)*100;
% Nflux=flux/(sum(abs(budget))/2)*100;
% DissipatedPower0 = budget(3) + budget(6) + budget(9) + budget(8) + budget(7)
% DissipatedPower1 = sum(abs(budget))/2
% DissipatedPower2 = Fs(2,3)*(Fs(2,3)>0)+Fs(5,6)+Fs(8,9)+Fs(2,6)+Fs(8,6)*(Fs(5,3)>0)+Fs(5,9)+Fs(1,3)
% DissipatedPower3 = Fs(2,3)*(Fs(2,3)>0)+Fs(5,6)+Fs(2,6)+Fs(1,3) %only vertical
% DissipatedPowerGood = +Fs(1,3) + Fs(2,3)*(Fs(2,3)>0)+Fs(2,6)+Fs(5,6)+Fs(5,9)+Fs(4,7)+Fs(5,8)+Fs(4,8)+Fs(5,7)
epsilon = DissipatedPowerGood*.83

residence_time = E_tot/DissipatedPowerGood/3600/24

% Calculate partial powers
P2budget = (Fi(1,2) + Fi(3,2) + Fi(4,2) + Fi(5,2) + Fi(6,2) + Fi(7,2) + Fi(8,2) + Fi(9,2))*(E_tot^2)*(f/f0);
P4budget = (Fi(1,4) + Fi(2,4) + Fi(3,4) + Fi(5,4) + Fi(6,4) + Fi(7,4) + Fi(8,4) + Fi(9,4))*(E_tot^2)*(f/f0);
P5budget = (Fi(1,5) + Fi(2,5) + Fi(3,5) + Fi(4,5) + Fi(6,5) + Fi(7,5) + Fi(8,5) + Fi(9,5))*(E_tot^2)*(f/f0);

% Compute the 4 partial energies
        % Define matrices with boundaries
        mss = [m_min,20*m_min,m_max,20*m_max];
        oss = [1.03*f0,5*f0,20*f0,N0];
        n_mss = [1,17,100]; % boundary indeces: [1,17,200] normal, [1,17,100] meth
        n_oss = [1,61,290]; % boundary indeces
        % NI-LW
        En_h = trapz(ms(n_mss(1):n_mss(2)),en(:,n_mss(1):n_mss(2)),2);
        E_tot_NILW = trapz(os(n_oss(1):n_oss(2)),En_h(n_oss(1):n_oss(2))) + (os(1)-f0)*En_h(1);
        % NI-HW
        En_h = trapz(ms(n_mss(2):n_mss(3)),en(:,n_mss(2):n_mss(3)),2);
        E_tot_NIHW = trapz(os(n_oss(1):n_oss(2)),En_h(n_oss(1):n_oss(2))) + (os(1)-f0)*En_h(1);
        % HF-LW
        En_h = trapz(ms(n_mss(1):n_mss(2)),en(:,n_mss(1):n_mss(2)),2);
        E_tot_HFLW = trapz(os(n_oss(2):n_oss(3)),En_h(n_oss(2):n_oss(3)));
        % HF-HW
        En_h = trapz(ms(n_mss(2):n_mss(3)),en(:,n_mss(2):n_mss(3)),2);
        E_tot_HFHW = trapz(os(n_oss(2):n_oss(3)),En_h(n_oss(2):n_oss(3)));
        
        
        % Compute the powers going out of the 4 boxes
        Po_NILW = (Fi(2,1)*(Fi(2,1)<0) + Fi(3,1)*(Fi(3,1)<0) + Fi(4,1)*(Fi(4,1)<0) + Fi(5,1)*(Fi(5,1)<0) + Fi(7,1)*(Fi(7,1)<0))*(E_tot^2)*(f/f0);
        Po_NIHW = (Fi(1,2)*(Fi(1,2)<0) + Fi(3,2)*(Fi(3,2)<0) + Fi(4,2)*(Fi(4,2)<0) + Fi(5,2)*(Fi(5,2)<0) + Fi(6,2)*(Fi(6,2)<0) + Fi(7,2)*(Fi(7,2)<0) + Fi(8,2)*(Fi(8,2)<0) + Fi(9,2)*(Fi(9,2)<0))*(E_tot^2)*(f/f0);
        Po_HFLW = (Fi(1,4)*(Fi(1,4)<0) + Fi(2,4)*(Fi(2,4)<0) + Fi(3,4)*(Fi(3,4)<0) + Fi(5,4)*(Fi(5,4)<0) + Fi(6,4)*(Fi(6,4)<0) + Fi(7,4)*(Fi(7,4)<0) + Fi(8,4)*(Fi(8,4)<0) + Fi(9,4)*(Fi(9,4)<0))*(E_tot^2)*(f/f0);
        Po_HFHW = (Fi(1,5)*(Fi(1,5)<0) + Fi(2,5)*(Fi(2,5)<0) + Fi(3,5)*(Fi(3,5)<0) + Fi(4,5)*(Fi(4,5)<0) + Fi(6,5)*(Fi(6,5)<0) + Fi(7,5)*(Fi(7,5)<0) + Fi(8,5)*(Fi(8,5)<0) + Fi(9,5)*(Fi(9,5)<0))*(E_tot^2)*(f/f0);

        % Compute the evolution timescales (in hours)
        Tev_NIHW = E_tot_NIHW/P2budget/(-3600)/24
        Tev_HFLW = E_tot_HFLW/P4budget/(-3600)/24
        Tev_HFHW = E_tot_HFHW/P5budget/(-3600)/24
        
        % Compute the 4 residence timescales and the total res ts (in hours)
        Tres_NILW = E_tot_NILW/Po_NILW/(-3600)/24
        Tres_NIHW = E_tot_NIHW/Po_NIHW/(-3600)/24
        Tres_HFLW = E_tot_HFLW/Po_HFLW/(-3600)/24
        Tres_HFHW = E_tot_HFHW/Po_HFHW/(-3600)/24
        
        r_NILW = 2*pi/(2.5*f)/3600/24/Tres_NILW
        r_NIHW = 2*pi/(2.5*f)/3600/24/Tres_NIHW
        r_HFLW = 2*pi/(11*f)/3600/24/Tres_HFLW
        r_HFHW = 2*pi/(11*f)/3600/24/Tres_HFHW

pause


%areas
X = log([1 260 260.001 2600]);%X = log([1 260 260.001 2600]);
Y = log([20 0 3.35; 20 0 3.35; 0 0 67; 0 0 67]);
ylim(log([1, 67]));
aa = area(X,Y,'FaceAlpha', 0.3);
newcolors = [1 1 1; 0.8500 0.3250 0.0980; 0 0.4470 0.7410];
colororder(newcolors)
hold on
set(gca,'TickLabelInterpreter','latex')
set(groot,'defaulttextinterpreter','latex');
set(groot,'defaultLegendInterpreter','latex');
plot([log(1),log(10*m_max/m_min)],log([1,1]),'k', 'linewidth',1.5)
hold on
loglog(log([1,10*m_max/m_min]),log([N/f,N/f]),'k', 'linewidth',1.5)
loglog(log([1,1]),log([1,N/f]),'k', 'linewidth',1.5)
loglog(log([10*m_max/m_min,10*m_max/m_min]),log([1,N/f]),'k', 'linewidth',1.5)
loglog(log([m_max/m_min,m_max/m_min]),log([1,N/f]),'k', 'linewidth',1.5)
loglog(log([20,20]),log([1,N/f]),'k', 'linewidth',1.5)
loglog(log([1,10*m_max/m_min]),log([5,5]),'k', 'linewidth',1.5)
loglog(log([1,10*m_max/m_min]),log([20,20]),'k', 'linewidth',1.5)
xlim(log([1,10*m_max/m_min]))
ylim(log([1,N/f]))
xticks(log([1 20 260 2600]))%xticks(log([1 20 130 1300]))%xticks(log([1 20 260 2600]))%
xticklabels({'$1$','$20$','$260$','$2600$'})%xticklabels({'$1$','$20$','$130$','$1300$'})%
yticks(log([1 5 20 67]))
yticklabels({'$f$','$5f$','$20f$','$N$'})
xlabel('$m$ (units of mode $1$)')
ylabel('$\omega$','Interpreter','latex')
ph = 2.3;
pv = 2.50;
plot(log([1,260]),log([20,20]),'color',[0.6350 0.0780 0.1840],'linewidth',3)
plot(log([260,260]),log([1,20]),'color',[0.6350 0.0780 0.1840],'linewidth',3)
% plot(log([1,130]),log([20,20]),'color',[0.6350 0.0780 0.1840],'linewidth',3)
% plot(log([130,130]),log([1,20]),'color',[0.6350 0.0780 0.1840],'linewidth',3)

pause
%draw arrows: 
Fi = (Fs_ID_p + Fs_ID_m)/E_tot_n^2;%/0.0023^2;
F  = 3*3*sign(Fi).*sqrt(abs(Fi))*200*(E_tot)/0.003; %for plotting purpose

DissipatedPowerID = +Fi(1,3) + Fi(2,3)*(Fi(2,3)>0)+Fi(2,6)+Fi(5,6)+Fi(5,9)+Fi(4,7)+Fi(5,8)+Fi(4,8);
DissipatedPowerID = DissipatedPowerID*(E_tot^2)*(f/f0)

drawArrow = @(x,y,varargin) quiver( x(1),x(2),y(1)-x(1),y(2)-x(2),0, varargin{:} )  ;
P1h = log([11.5,2.3]);
P2h = log([36,2.3]);
P1v = log([4.5,3.5]);
P2v = log([4.5,7]);
d = .15;
d1 = 0;%.1;
%12
w=abs(F(1,2));
ws = sign(F(1,2)); % sign of flux
if w~=0
if ws == +1
    p1 = P1h+[0,d]*1.5;
    p2 = P2h+[0,d]*1.5;
end
if ws == -1
    p1 = P2h+[0,d]*1.5;
    p2 = P1h+[0,d]*1.5;
end
% drawArrow(p1,p2,'MaxHeadSize',.5,'linewidth',w,'color',[0.8500, 0.3250, 0.0980])
X = [p1(1)/log(2600)   p2(1)/log(2600)]/1.3+0.13;
Y = [p1(2)/log(67)     p2(2)/log(67)]/1.20+0.10;
annotation('arrow',X,Y,'linestyle','-','color',[0.8500, 0.3250, 0.0980],'linewidth',w,'headlength',15,'headwidth',w*4,'units','normalized')
end


%13
w=abs(F(1,3));
ws = sign(F(1,3)); % sign of flux
if w~=0
if ws == +1
    p1 = P1h+log([1,0.7])+[0,d];
    p2 = P2h+log([260/18,0.7])+[0,d];
end
if ws == -1
    p1 = P2h+log([260/18,0.7])+[0,d];
    p2 = P1h+log([1,0.7])+[0,d];
end
% drawArrow(p1,p2,'MaxHeadSize',.5,'linewidth',w,'color',[0.8500, 0.3250, 0.0980])
X = [p1(1)/log(2600)   p2(1)/log(2600)]/1.3+0.13;
Y = [p1(2)/log(67)     p2(2)/log(67)]/1.20+0.10;
annotation('arrow',X,Y,'linestyle','-','color',[0.8500, 0.3250, 0.0980],'linewidth',w,'headlength',15,'headwidth',w*4,'units','normalized')
end

%14
w=abs(F(1,4));
ws = sign(F(1,4)); % sign of flux
if w~=0
if ws == +1
    p1 = P1v;
    p2 = P2v;
end
if ws == -1
    p1 = P2v;
    p2 = P1v;
end
% drawArrow(p1,p2,'MaxHeadSize',.5,'linewidth',w,'color',[0.8500, 0.3250, 0.0980])
X = [p1(1)/log(2600)   p2(1)/log(2600)]/1.3+0.13;
Y = [p1(2)/log(67)     p2(2)/log(67)]/1.20+0.10;
annotation('arrow',X,Y,'linestyle','-','color',[0.8500, 0.3250, 0.0980],'linewidth',w,'headlength',15,'headwidth',w*4,'units','normalized')
end

%15
w=abs(F(1,5));
ws = sign(F(1,5)); % sign of flux
if w~=0
if ws == +1
    p1 = P1v+log([3.3,1.1])+[-d1,d1];
    p2 = P2v+log([6.4,1])+[-d1,d1];
end
if ws == -1
    p1 = P2v+log([6.4,1])+[-d1,d1];
    p2 = P1v+log([3.3,1.1])+[-d1,d1];
end
% drawArrow(p1,p2,'MaxHeadSize',.5,'linewidth',w,'color',[0.8500, 0.3250, 0.0980])
X = [p1(1)/log(2600)   p2(1)/log(2600)]/1.3+0.13;
Y = [p1(2)/log(67)     p2(2)/log(67)]/1.20+0.10;
annotation('arrow',X,Y,'linestyle','-','color',[0.8500, 0.3250, 0.0980],'linewidth',w,'headlength',15,'headwidth',w*4,'units','normalized')
end

%23
w=abs(F(2,3));
ws = sign(F(2,3)); % sign of flux
if w~=0
if ws == +1
    p1 = P1h+log([260/20,1])+[0,d]*1.5;
    p2 = P2h+log([260/20,1])+[0,d]*1.5;
end
if ws == -1
    p1 = P2h+log([260/20,1])+[0,d]*1.5;
    p2 = P1h+log([260/20,1])+[0,d]*1.5;
end
% drawArrow(p1,p2,'MaxHeadSize',.5,'linewidth',w,'color',[0.8500, 0.3250, 0.0980])
X = [p1(1)/log(2600)   p2(1)/log(2600)]/1.3+0.13;
Y = [p1(2)/log(67)     p2(2)/log(67)]/1.20+0.10;
annotation('arrow',X,Y,'linestyle','-','color',[0.8500, 0.3250, 0.0980],'linewidth',w,'headlength',15,'headwidth',w*4,'units','normalized')
end

%24
w=abs(F(2,4));
ws = sign(F(2,4)); % sign of flux
if w~=0
if ws == +1
    p1 = P1v+log([6.4*12/260*20,1.1]);
    p2 = P2v+log([3.3*12/260*20,1]);
end
if ws == -1
    p1 = P2v+log([3.3*12/260*20,1]);
    p2 = P1v+log([6.4*12/260*20,1.1]);
end
% drawArrow(p1,p2,'MaxHeadSize',.5,'linewidth',w,'color',[0.8500, 0.3250, 0.0980])
X = [p1(1)/log(2600)   p2(1)/log(2600)]/1.3+0.13;
Y = [p1(2)/log(67)     p2(2)/log(67)]/1.20+0.10;
annotation('arrow',X,Y,'linestyle','-','color',[0.8500, 0.3250, 0.0980],'linewidth',w,'headlength',15,'headwidth',w*4,'units','normalized')
end

%25
w=abs(F(2,5));
ws = sign(F(2,5)); % sign of flux
if w~=0
if ws == +1
    p1 = P1v+log([260/17,1]);
    p2 = P2v+log([260/17,1]);
end
if ws == -1
    p1 = P2v+log([260/17,1]);
    p2 = P1v+log([260/17,1]);
end
% drawArrow(p1,p2,'MaxHeadSize',.5,'linewidth',w,'color',[0.8500, 0.3250, 0.0980])
X = [p1(1)/log(2600)   p2(1)/log(2600)]/1.3+0.13;
Y = [p1(2)/log(67)     p2(2)/log(67)]/1.20+0.10;
annotation('arrow',X,Y,'linestyle','-','color',[0.8500, 0.3250, 0.0980],'linewidth',w,'headlength',15,'headwidth',w*4,'units','normalized')
end

%26
w=abs(F(2,6));
ws = sign(F(2,6)); % sign of flux
if w~=0
if ws == +1
    p1 = P1v+log([3.3*260/20,1.1])+[-d1,d1];
    p2 = P2v+log([6.4*260/20,1])+[-d1,d1];
end
if ws == -1
    p1 = P2v+log([6.4*260/20,1])+[-d1,d1];
    p2 = P1v+log([3.3*260/20,1.1])+[-d1,d1];
end
% drawArrow(p1,p2,'MaxHeadSize',.5,'linewidth',w,'color',[0.8500, 0.3250, 0.0980])
X = [p1(1)/log(2600)   p2(1)/log(2600)]/1.3+0.13;
Y = [p1(2)/log(67)     p2(2)/log(67)]/1.20+0.10;
annotation('arrow',X,Y,'linestyle','-','color',[0.8500, 0.3250, 0.0980],'linewidth',w,'headlength',15,'headwidth',w*4,'units','normalized')
end

%35
w=abs(F(3,5));
ws = sign(F(3,5)); % sign of flux
if w~=0
if ws == +1
    p1 = P1v+log([6.4*12,1.1]);
    p2 = P2v+log([3.3*12,1]);
end
if ws == -1
    p1 = P2v+log([3.3*12,1]);
    p2 = P1v+log([6.4*12,1.1]);
end
% drawArrow(p1,p2,'MaxHeadSize',.5,'linewidth',w,'color',[0.8500, 0.3250, 0.0980])
X = [p1(1)/log(2600)   p2(1)/log(2600)]/1.3+0.13;
Y = [p1(2)/log(67)     p2(2)/log(67)]/1.20+0.10;
annotation('arrow',X,Y,'linestyle','-','color',[0.8500, 0.3250, 0.0980],'linewidth',w,'headlength',15,'headwidth',w*4,'units','normalized')
end

%36
w=abs(F(3,6));
ws = sign(F(3,6)); % sign of flux
if w~=0
if ws == +1
    p1 = P1v+log([175,1]);
    p2 = P2v+log([175,1]);
end
if ws == -1
    p1 = P2v+log([175,1]);
    p2 = P1v+log([175,1]);
end
% drawArrow(p1,p2,'MaxHeadSize',.5,'linewidth',w,'color',[0.8500, 0.3250, 0.0980])
X = [p1(1)/log(2600)   p2(1)/log(2600)]/1.3+0.13;
Y = [p1(2)/log(67)     p2(2)/log(67)]/1.20+0.10;
%annotation('arrow',X,Y,'linestyle','-','color',[0.7, 0.7, 0.7],'linewidth',w,'headlength',w*4,'headwidth',w*4,'units','normalized')
end

%45
w=abs(F(4,5));
ws = sign(F(4,5)); % sign of flux
if w~=0
if ws == +1
    p1 = P1h+log([1,25/5])+[0,d];
    p2 = P2h+log([1,25/5])+[0,d];
end
if ws == -1
    p1 = P2h+log([1,25/5])+[0,d];
    p2 = P1h+log([1,25/5])+[0,d];
end
% drawArrow(p1,p2,'MaxHeadSize',.5,'linewidth',w,'color',[0.8500, 0.3250, 0.0980])
X = [p1(1)/log(2600)   p2(1)/log(2600)]/1.3+0.13;
Y = [p1(2)/log(67)     p2(2)/log(67)]/1.20+0.10;
annotation('arrow',X,Y,'linestyle','-','color',[0.8500, 0.3250, 0.0980],'linewidth',w,'headlength',15,'headwidth',w*4,'units','normalized')
end

%47
w=abs(F(4,7));
ws = sign(F(4,7)); % sign of flux
if w~=0
if ws == +1
    p1 = P1v+log([1,20/5]);
    p2 = P2v+log([1,20/5]);
end
if ws == -1
    p1 = P2v+log([1,20/5]);
    p2 = P1v+log([1,20/5]);
end
% drawArrow(p1,p2,'MaxHeadSize',.5,'linewidth',w,'color',[0.8500, 0.3250, 0.0980])
X = [p1(1)/log(2600)   p2(1)/log(2600)]/1.3+0.13;
Y = [p1(2)/log(67)     p2(2)/log(67)]/1.20+0.10;
annotation('arrow',X,Y,'linestyle','-','color',[0.8500, 0.3250, 0.0980],'linewidth',w,'headlength',15,'headwidth',w*4,'units','normalized')
end

%48
w=abs(F(4,8));
ws = sign(F(4,8)); % sign of flux
if w~=0
if ws == +1
    p1 = P1v+log([3.3,1.1*20/5])+[-d1,d1];
    p2 = P2v+log([6.4,20/5])+[-d1,d1];
end
if ws == -1
    p1 = P2v+log([6.4,20/5])+[-d1,d1];
    p2 = P1v+log([3.3,1.1*20/5])+[-d1,d1];
end
% drawArrow(p1,p2,'MaxHeadSize',.5,'linewidth',w,'color',[0.8500, 0.3250, 0.0980])
X = [p1(1)/log(2600)   p2(1)/log(2600)]/1.3+0.13;
Y = [p1(2)/log(67)     p2(2)/log(67)]/1.20+0.10;
annotation('arrow',X,Y,'linestyle','-','color',[0.8500, 0.3250, 0.0980],'linewidth',w,'headlength',15,'headwidth',w*4,'units','normalized')
end

%56
w=abs(F(5,6));
ws = sign(F(5,6)); % sign of flux
if w~=0
if ws == +1
    p1 = P1h+log([260/20,25/5])+[0,d];
    p2 = P2h+log([260/20,25/5])+[0,d];
end
if ws == -1
    p1 = P2h+log([260/20,25/5])+[0,d];
    p2 = P1h+log([260/20,25/5])+[0,d];
end
% drawArrow(p1,p2,'MaxHeadSize',.5,'linewidth',w,'color',[0.8500, 0.3250, 0.0980])
X = [p1(1)/log(2600)   p2(1)/log(2600)]/1.3+0.13;
Y = [p1(2)/log(67)     p2(2)/log(67)]/1.20+0.10;
annotation('arrow',X,Y,'linestyle','-','color',[0.8500, 0.3250, 0.0980],'linewidth',w,'headlength',15,'headwidth',w*4,'units','normalized')
end

%57
w=abs(F(5,7));
ws = sign(F(5,7)); % sign of flux
if w~=0
if ws == +1
    p1 = P1v+log([6.4*12/260*20,1.1*20/5]);
    p2 = P2v+log([3.3*12/260*20,20/5]);
end
if ws == -1
    p1 = P2v+log([3.3*12/260*20,20/5]);
    p2 = P1v+log([6.4*12/260*20,1.1*20/5]);
end
% drawArrow(p1,p2,'MaxHeadSize',.5,'linewidth',w,'color',[0.8500, 0.3250, 0.0980])
X = [p1(1)/log(2600)   p2(1)/log(2600)]/1.3+0.13;
Y = [p1(2)/log(67)     p2(2)/log(67)]/1.20+0.10;
annotation('arrow',X,Y,'linestyle','-','color',[0.8500, 0.3250, 0.0980],'linewidth',w,'headlength',15,'headwidth',w*4,'units','normalized')
end

%58
w=abs(F(5,8));
ws = sign(F(5,8)); % sign of flux
if w~=0
if ws == +1
    p1 = P1v+log([260/17,20/5]);
    p2 = P2v+log([260/17,20/5]);
end
if ws == -1
    p1 = P2v+log([260/17,20/5]);
    p2 = P1v+log([260/17,20/5]);
end
% drawArrow(p1,p2,'MaxHeadSize',.5,'linewidth',w,'color',[0.8500, 0.3250, 0.0980])
X = [p1(1)/log(2600)   p2(1)/log(2600)]/1.3+0.13;
Y = [p1(2)/log(67)     p2(2)/log(67)]/1.20+0.10;
annotation('arrow',X,Y,'linestyle','-','color',[0.8500, 0.3250, 0.0980],'linewidth',w,'headlength',15,'headwidth',w*4,'units','normalized')
end

%59
w=abs(F(5,9));
ws = sign(F(5,9)); % sign of flux
if w~=0
if ws == +1
    p1 = P1v+log([3.3*260/20,1.1*20/5])+[-d1,d1];
    p2 = P2v+log([6.4*260/20,20/5])+[-d1,d1];
end
if ws == -1
    p1 = P2v+log([6.4*260/20,20/5])+[-d1,d1];
    p2 = P1v+log([3.3*260/20,1.1*20/5])+[-d1,d1];
end
% drawArrow(p1,p2,'MaxHeadSize',.5,'linewidth',w,'color',[0.8500, 0.3250, 0.0980])
X = [p1(1)/log(2600)   p2(1)/log(2600)]/1.3+0.13;
Y = [p1(2)/log(67)     p2(2)/log(67)]/1.20+0.10;
annotation('arrow',X,Y,'linestyle','-','color',[0.8500, 0.3250, 0.0980],'linewidth',w,'headlength',15,'headwidth',w*4,'units','normalized')
end

%68
w=F(6,8);
p1 = P1v+log([6.4*12,1.1*20/5]);
p2 = P2v+log([3.3*12,1*20/5]);
% drawArrow(p1,p2,'MaxHeadSize',.5,'linewidth',w,'color',[0.8500, 0.3250, 0.0980])
X = [p1(1)/log(2600)   p2(1)/log(2600)]/1.3+0.13;
Y = [p1(2)/log(67)     p2(2)/log(67)]/1.20+0.10;
%annotation('arrow',X,Y,'linestyle','-','color',[0.8500, 0.3250, 0.0980],'linewidth',w,'headlength',15,'headwidth',w*4,'units','normalized')

%69
w=F(6,9);
p1 = P1v+log([175,20/5]);
p2 = P2v+log([175,20/5]);
%drawArrow(p1,p2,'MaxHeadSize',.5,'linewidth',w,'color',[0.8500, 0.3250, 0.0980])
X = [p1(1)/log(2600)   p2(1)/log(2600)]/1.3+0.13;
Y = [p1(2)/log(67)     p2(2)/log(67)]/1.20+0.10;
%annotation('arrow',X,Y,'linestyle','-','color',[0.7, 0.7, 0.7],'linewidth',w,'headlength',w*4,'headwidth',w*4,'units','normalized')

%78
w=F(7,8);
p1 = P1h+log([1,25/5*22/5]);
p2 = P2h+log([1,25/5*22/5]);
%drawArrow(p1,p2,'MaxHeadSize',.5,'linewidth',w,'color',[0.8500, 0.3250, 0.0980])
X = [p1(1)/log(2600)   p2(1)/log(2600)]/1.3+0.13;
Y = [p1(2)/log(67)     p2(2)/log(67)]/1.20+0.10;
%annotation('arrow',X,Y,'linestyle','-','color',[0.8500, 0.3250, 0.0980],'linewidth',w,'headlength',15,'headwidth',w*4,'units','normalized')

%89
w=F(8,9);
p1 = P1h+log([1*260/20,25/5*22/5]);
p2 = P2h+log([1*260/20,25/5*22/5]);
%drawArrow(p1,p2,'MaxHeadSize',.5,'linewidth',w,'color',[0.8500, 0.3250, 0.0980])
X = [p1(1)/log(2600)   p2(1)/log(2600)]/1.3+0.13;
Y = [p1(2)/log(67)     p2(2)/log(67)]/1.20+0.10;
%annotation('arrow',X,Y,'linestyle','-','color',[0.8500, 0.3250, 0.0980],'linewidth',w,'headlength',15,'headwidth',w*4,'units','normalized')


%% PSI arrows
pause
%draw arrows: 
Fi = (Fs_PSI_p + Fs_PSI_m)/E_tot_n^2;%/0.0023^2;
F  = 3*3*sign(Fi).*sqrt(abs(Fi))*200*(E_tot)/0.003; %for plotting purpose
Fi(5,3)
DissipatedPowerPSI = +Fi(1,3) + Fi(2,3)*(Fi(2,3)>0)+Fi(5,3)+Fi(5,6);
DissipatedPowerPSI = DissipatedPowerPSI*(E_tot^2)*(f/f0)

drawArrow = @(x,y,varargin) quiver( x(1),x(2),y(1)-x(1),y(2)-x(2),0, varargin{:} )  ;
P1h = log([11.5,2.3]);
P2h = log([36,2.3]);
P1v = log([4.5,3.5]);
P2v = log([4.5,7]);
%12
w=abs(F(1,2));
ws = sign(F(1,2)); % sign of flux
if w~=0
if ws == +1
    p1 = P1h;
    p2 = P2h;
end
if ws == -1
    p1 = P2h;
    p2 = P1h;
end
% drawArrow(p1,p2,'MaxHeadSize',.5,'linewidth',w,'color',[0.8500, 0.3250, 0.0980])
X = [p1(1)/log(2600)   p2(1)/log(2600)]/1.3+0.13;
Y = [p1(2)/log(67)     p2(2)/log(67)]/1.20+0.10;
annotation('arrow',X,Y,'linestyle','-','color',[0 0.4470 0.7410],'linewidth',w,'headlength',15,'headwidth',w*4,'units','normalized')
end

%13
w=abs(F(1,3));
ws = sign(F(1,3)); % sign of flux
if w~=0
if ws == +1
    p1 = P1h+log([1,0.7]);
    p2 = P2h+log([260/18,0.7]);
end
if ws == -1
    p1 = P2h+log([260/18,0.7]);
    p2 = P1h+log([1,0.7]);
end
% drawArrow(p1,p2,'MaxHeadSize',.5,'linewidth',w,'color',[0.8500, 0.3250, 0.0980])
X = [p1(1)/log(2600)   p2(1)/log(2600)]/1.3+0.13;
Y = [p1(2)/log(67)     p2(2)/log(67)]/1.20+0.10;
annotation('arrow',X,Y,'linestyle','-','color',[0 0.4470 0.7410],'linewidth',w,'headlength',15,'headwidth',w*4,'units','normalized')
end

%14
w=abs(F(1,4));
ws = sign(F(1,4)); % sign of flux
if w~=0
if ws == +1
    p1 = P1v;
    p2 = P2v;
end
if ws == -1
    p1 = P2v;
    p2 = P1v;
end
% drawArrow(p1,p2,'MaxHeadSize',.5,'linewidth',w,'color',[0.8500, 0.3250, 0.0980])
X = [p1(1)/log(2600)   p2(1)/log(2600)]/1.3+0.13;
Y = [p1(2)/log(67)     p2(2)/log(67)]/1.20+0.10;
annotation('arrow',X,Y,'linestyle','-','color',[0 0.4470 0.7410],'linewidth',w,'headlength',15,'headwidth',w*4,'units','normalized')
end

%15
w=abs(F(1,5));
ws = sign(F(1,5)); % sign of flux
if w~=0
if ws == +1
    p1 = P1v+log([3.3,1.1]);
    p2 = P2v+log([6.4,1]);
end
if ws == -1
    p1 = P2v+log([6.4,1]);
    p2 = P1v+log([3.3,1.1]);
end
% drawArrow(p1,p2,'MaxHeadSize',.5,'linewidth',w,'color',[0.8500, 0.3250, 0.0980])
X = [p1(1)/log(2600)   p2(1)/log(2600)]/1.3+0.13;
Y = [p1(2)/log(67)     p2(2)/log(67)]/1.20+0.10;
annotation('arrow',X,Y,'linestyle','-','color',[0 0.4470 0.7410],'linewidth',w,'headlength',15,'headwidth',w*4,'units','normalized')
end

%23
w=abs(F(2,3));
ws = sign(F(2,3)); % sign of flux
if w~=0
if ws == +1
    p1 = P1h+log([260/20,1]);
    p2 = P2h+log([260/20,1]);
end
if ws == -1
    p1 = P2h+log([260/20,1]);
    p2 = P1h+log([260/20,1]);
end
% drawArrow(p1,p2,'MaxHeadSize',.5,'linewidth',w,'color',[0.8500, 0.3250, 0.0980])
X = [p1(1)/log(2600)   p2(1)/log(2600)]/1.3+0.13;
Y = [p1(2)/log(67)     p2(2)/log(67)]/1.20+0.10;
annotation('arrow',X,Y,'linestyle','-','color',[0 0.4470 0.7410],'linewidth',w,'headlength',15,'headwidth',w*4,'units','normalized')
end

%24
w=abs(F(2,4));
ws = sign(F(2,4)); % sign of flux
if w~=0
if ws == +1
    p1 = P1v+log([6.4*12/260*20,1.1])-[d,d]/2;
    p2 = P2v+log([3.3*12/260*20,1])-[d,d]/2;
end
if ws == -1
    p1 = P2v+log([3.3*12/260*20,1])-[d,d]/2;
    p2 = P1v+log([6.4*12/260*20,1.1])-[d,d]/2;
end
% drawArrow(p1,p2,'MaxHeadSize',.5,'linewidth',w,'color',[0.8500, 0.3250, 0.0980])
X = [p1(1)/log(2600)   p2(1)/log(2600)]/1.3+0.13;
Y = [p1(2)/log(67)     p2(2)/log(67)]/1.20+0.10;
annotation('arrow',X,Y,'linestyle','-','color',[0 0.4470 0.7410],'linewidth',w,'headlength',15,'headwidth',w*4,'units','normalized')
end

%25
w=abs(F(2,5));
ws = sign(F(2,5)); % sign of flux
if w~=0
if ws == +1
    p1 = P1v+log([260/17,1]);
    p2 = P2v+log([260/17,1]);
end
if ws == -1
    p1 = P2v+log([260/17,1]);
    p2 = P1v+log([260/17,1]);
end
% drawArrow(p1,p2,'MaxHeadSize',.5,'linewidth',w,'color',[0.8500, 0.3250, 0.0980])
X = [p1(1)/log(2600)   p2(1)/log(2600)]/1.3+0.13;
Y = [p1(2)/log(67)     p2(2)/log(67)]/1.20+0.10;
annotation('arrow',X,Y,'linestyle','-','color',[0 0.4470 0.7410],'linewidth',w,'headlength',15,'headwidth',w*4,'units','normalized')
end

%26
w=abs(F(2,6));
ws = sign(F(2,6)); % sign of flux
if w~=0
if ws == +1
    p1 = P1v+log([3.3*260/20,1.1]);
    p2 = P2v+log([6.4*260/20,1]);
end
if ws == -1
    p1 = P2v+log([6.4*260/20,1]);
    p2 = P1v+log([3.3*260/20,1.1]);
end
% drawArrow(p1,p2,'MaxHeadSize',.5,'linewidth',w,'color',[0.8500, 0.3250, 0.0980])
X = [p1(1)/log(2600)   p2(1)/log(2600)]/1.3+0.13;
Y = [p1(2)/log(67)     p2(2)/log(67)]/1.20+0.10;
annotation('arrow',X,Y,'linestyle','-','color',[0 0.4470 0.7410],'linewidth',w,'headlength',15,'headwidth',w*4,'units','normalized')
end

%35
w=abs(F(3,5));
ws = sign(F(3,5)); % sign of flux
if w~=0
if ws == +1
    p1 = P1v+log([6.4*12,1.1]);
    p2 = P2v+log([3.3*12,1]);
end
if ws == -1
    p1 = P2v+log([3.3*12,1]);
    p2 = P1v+log([6.4*12,1.1]);
end
% drawArrow(p1,p2,'MaxHeadSize',.5,'linewidth',w,'color',[0.8500, 0.3250, 0.0980])
X = [p1(1)/log(2600)   p2(1)/log(2600)]/1.3+0.13;
Y = [p1(2)/log(67)     p2(2)/log(67)]/1.20+0.10;
annotation('arrow',X,Y,'linestyle','-','color',[0 0.4470 0.7410],'linewidth',w,'headlength',15,'headwidth',w*4,'units','normalized')
end

%36
w=abs(F(3,6));
ws = sign(F(3,6)); % sign of flux
if w~=0
if ws == +1
    p1 = P1v+log([175,1]);
    p2 = P2v+log([175,1]);
end
if ws == -1
    p1 = P2v+log([175,1]);
    p2 = P1v+log([175,1]);
end
% drawArrow(p1,p2,'MaxHeadSize',.5,'linewidth',w,'color',[0.8500, 0.3250, 0.0980])
X = [p1(1)/log(2600)   p2(1)/log(2600)]/1.3+0.13;
Y = [p1(2)/log(67)     p2(2)/log(67)]/1.20+0.10;
%annotation('arrow',X,Y,'linestyle','-','color',[0.7, 0.7, 0.7],'linewidth',w,'headlength',w*4,'headwidth',w*4,'units','normalized')
end

%45
w=abs(F(4,5));
ws = sign(F(4,5)); % sign of flux
if w~=0
if ws == +1
    p1 = P1h+log([1,25/5]);
    p2 = P2h+log([1,25/5]);
end
if ws == -1
    p1 = P2h+log([1,25/5]);
    p2 = P1h+log([1,25/5]);
end
% drawArrow(p1,p2,'MaxHeadSize',.5,'linewidth',w,'color',[0.8500, 0.3250, 0.0980])
X = [p1(1)/log(2600)   p2(1)/log(2600)]/1.3+0.13;
Y = [p1(2)/log(67)     p2(2)/log(67)]/1.20+0.10;
annotation('arrow',X,Y,'linestyle','-','color',[0 0.4470 0.7410],'linewidth',w,'headlength',15,'headwidth',w*4,'units','normalized')
end

%47
w=abs(F(4,7));
ws = sign(F(4,7)); % sign of flux
if w~=0
if ws == +1
    p1 = P1v+log([1,20/5]);
    p2 = P2v+log([1,20/5]);
end
if ws == -1
    p1 = P2v+log([1,20/5]);
    p2 = P1v+log([1,20/5]);
end
% drawArrow(p1,p2,'MaxHeadSize',.5,'linewidth',w,'color',[0.8500, 0.3250, 0.0980])
X = [p1(1)/log(2600)   p2(1)/log(2600)]/1.3+0.13;
Y = [p1(2)/log(67)     p2(2)/log(67)]/1.20+0.10;
annotation('arrow',X,Y,'linestyle','-','color',[0 0.4470 0.7410],'linewidth',w,'headlength',15,'headwidth',w*4,'units','normalized')
end

%48
w=abs(F(4,8));
ws = sign(F(4,8)); % sign of flux
if w~=0
if ws == +1
    p1 = P1v+log([3.3,1.1*20/5]);
    p2 = P2v+log([6.4,20/5]);
end
if ws == -1
    p1 = P2v+log([6.4,20/5]);
    p2 = P1v+log([3.3,1.1*20/5]);
end
% drawArrow(p1,p2,'MaxHeadSize',.5,'linewidth',w,'color',[0.8500, 0.3250, 0.0980])
X = [p1(1)/log(2600)   p2(1)/log(2600)]/1.3+0.13;
Y = [p1(2)/log(67)     p2(2)/log(67)]/1.20+0.10;
annotation('arrow',X,Y,'linestyle','-','color',[0 0.4470 0.7410],'linewidth',w,'headlength',15,'headwidth',w*4,'units','normalized')
end

%56
w=abs(F(5,6));
ws = sign(F(5,6)); % sign of flux
if w~=0
if ws == +1
    p1 = P1h+log([260/20,25/5]);
    p2 = P2h+log([260/20,25/5]);
end
if ws == -1
    p1 = P2h+log([260/20,25/5]);
    p2 = P1h+log([260/20,25/5]);
end
% drawArrow(p1,p2,'MaxHeadSize',.5,'linewidth',w,'color',[0.8500, 0.3250, 0.0980])
X = [p1(1)/log(2600)   p2(1)/log(2600)]/1.3+0.13;
Y = [p1(2)/log(67)     p2(2)/log(67)]/1.20+0.10;
annotation('arrow',X,Y,'linestyle','-','color',[0 0.4470 0.7410],'linewidth',w,'headlength',15,'headwidth',w*4,'units','normalized')
end

%57
w=abs(F(5,7));
ws = sign(F(5,7)); % sign of flux
if w~=0
if ws == +1
    p1 = P1v+log([6.4*12/260*20,1.1*20/5]);
    p2 = P2v+log([3.3*12/260*20,20/5]);
end
if ws == -1
    p1 = P2v+log([3.3*12/260*20,20/5]);
    p2 = P1v+log([6.4*12/260*20,1.1*20/5]);
end
% drawArrow(p1,p2,'MaxHeadSize',.5,'linewidth',w,'color',[0.8500, 0.3250, 0.0980])
X = [p1(1)/log(2600)   p2(1)/log(2600)]/1.3+0.13;
Y = [p1(2)/log(67)     p2(2)/log(67)]/1.20+0.10;
%annotation('arrow',X,Y,'linestyle','-','color',[0 0.4470 0.7410],'linewidth',w,'headlength',15,'headwidth',w*4,'units','normalized')
end

%58
w=abs(F(5,8));
ws = sign(F(5,8)); % sign of flux
if w~=0
if ws == +1
    p1 = P1v+log([260/17,20/5]);
    p2 = P2v+log([260/17,20/5]);
end
if ws == -1
    p1 = P2v+log([260/17,20/5]);
    p2 = P1v+log([260/17,20/5]);
end
% drawArrow(p1,p2,'MaxHeadSize',.5,'linewidth',w,'color',[0.8500, 0.3250, 0.0980])
X = [p1(1)/log(2600)   p2(1)/log(2600)]/1.3+0.13;
Y = [p1(2)/log(67)     p2(2)/log(67)]/1.20+0.10;
annotation('arrow',X,Y,'linestyle','-','color',[0 0.4470 0.7410],'linewidth',w,'headlength',15,'headwidth',w*4,'units','normalized')
end

%59
w=abs(F(5,9));
ws = sign(F(5,9)); % sign of flux
if w~=0
if ws == +1
    p1 = P1v+log([3.3*260/20,1.1*20/5]);
    p2 = P2v+log([6.4*260/20,20/5]);
end
if ws == -1
    p1 = P2v+log([6.4*260/20,20/5]);
    p2 = P1v+log([3.3*260/20,1.1*20/5]);
end
% drawArrow(p1,p2,'MaxHeadSize',.5,'linewidth',w,'color',[0.8500, 0.3250, 0.0980])
X = [p1(1)/log(2600)   p2(1)/log(2600)]/1.3+0.13;
Y = [p1(2)/log(67)     p2(2)/log(67)]/1.20+0.10;
annotation('arrow',X,Y,'linestyle','-','color',[0 0.4470 0.7410],'linewidth',w,'headlength',15,'headwidth',w*4,'units','normalized')
end

%68
w=F(6,8);
p1 = P1v+log([6.4*12,1.1*20/5]);
p2 = P2v+log([3.3*12,1*20/5]);
% drawArrow(p1,p2,'MaxHeadSize',.5,'linewidth',w,'color',[0.8500, 0.3250, 0.0980])
X = [p1(1)/log(2600)   p2(1)/log(2600)]/1.3+0.13;
Y = [p1(2)/log(67)     p2(2)/log(67)]/1.20+0.10;
%annotation('arrow',X,Y,'linestyle','-','color',[0.8500, 0.3250, 0.0980],'linewidth',w,'headlength',15,'headwidth',w*4,'units','normalized')

%69
w=F(6,9);
p1 = P1v+log([175,20/5]);
p2 = P2v+log([175,20/5]);
%drawArrow(p1,p2,'MaxHeadSize',.5,'linewidth',w,'color',[0.8500, 0.3250, 0.0980])
X = [p1(1)/log(2600)   p2(1)/log(2600)]/1.3+0.13;
Y = [p1(2)/log(67)     p2(2)/log(67)]/1.20+0.10;
%annotation('arrow',X,Y,'linestyle','-','color',[0.7, 0.7, 0.7],'linewidth',w,'headlength',w*4,'headwidth',w*4,'units','normalized')

%78
w=F(7,8);
p1 = P1h+log([1,25/5*22/5]);
p2 = P2h+log([1,25/5*22/5]);
%drawArrow(p1,p2,'MaxHeadSize',.5,'linewidth',w,'color',[0.8500, 0.3250, 0.0980])
X = [p1(1)/log(2600)   p2(1)/log(2600)]/1.3+0.13;
Y = [p1(2)/log(67)     p2(2)/log(67)]/1.20+0.10;
%annotation('arrow',X,Y,'linestyle','-','color',[0.8500, 0.3250, 0.0980],'linewidth',w,'headlength',15,'headwidth',w*4,'units','normalized')

%89
w=F(8,9);
p1 = P1h+log([1*260/20,25/5*22/5]);
p2 = P2h+log([1*260/20,25/5*22/5]);
%drawArrow(p1,p2,'MaxHeadSize',.5,'linewidth',w,'color',[0.8500, 0.3250, 0.0980])
X = [p1(1)/log(2600)   p2(1)/log(2600)]/1.3+0.13;
Y = [p1(2)/log(67)     p2(2)/log(67)]/1.20+0.10;
%annotation('arrow',X,Y,'linestyle','-','color',[0.8500, 0.3250, 0.0980],'linewidth',w,'headlength',15,'headwidth',w*4,'units','normalized')


%% ES arrows
pause
%draw arrows: 
Fi = (Fs_ES_p + Fs_ES_m)/E_tot_n^2;%/0.0023^2;
F  = 3*3*sign(Fi).*sqrt(abs(Fi))*200*(E_tot)/0.003; %for plotting purpose

DissipatedPowerES = +Fi(4,7) + Fi(5,8) + Fi(5,7);
DissipatedPowerES = DissipatedPowerES*(E_tot^2)*(f/f0)


drawArrow = @(x,y,varargin) quiver( x(1),x(2),y(1)-x(1),y(2)-x(2),0, varargin{:} )  ;
P1h = log([11.5,2.3]);
P2h = log([36,2.3]);
P1v = log([4.5,3.5]);
P2v = log([4.5,7]);
%12
w=abs(F(1,2));
ws = sign(F(1,2)); % sign of flux
if w~=0
if ws == +1
    p1 = P1h-[0,d]*1.5;
    p2 = P2h-[0,d]*1.5;
end
if ws == -1
    p1 = P2h-[0,d]*1.5;
    p2 = P1h-[0,d]*1.5;
end
% drawArrow(p1,p2,'MaxHeadSize',.5,'linewidth',w,'color',[0.8500, 0.3250, 0.0980])
X = [p1(1)/log(2600)   p2(1)/log(2600)]/1.3+0.13;
Y = [p1(2)/log(67)     p2(2)/log(67)]/1.20+0.10;
annotation('arrow',X,Y,'linestyle','-','color',[0.9290 0.6940 0.1250],'linewidth',w,'headlength',15,'headwidth',w*4,'units','normalized')
end

%13
w=abs(F(1,3));
ws = sign(F(1,3)); % sign of flux
if w~=0
if ws == +1
    p1 = P1h+log([1,0.7]);
    p2 = P2h+log([260/18,0.7]);
end
if ws == -1
    p1 = P2h+log([260/18,0.7]);
    p2 = P1h+log([1,0.7]);
end
% drawArrow(p1,p2,'MaxHeadSize',.5,'linewidth',w,'color',[0.8500, 0.3250, 0.0980])
X = [p1(1)/log(2600)   p2(1)/log(2600)]/1.3+0.13;
Y = [p1(2)/log(67)     p2(2)/log(67)]/1.20+0.10;
annotation('arrow',X,Y,'linestyle','-','color',[0.9290 0.6940 0.1250],'linewidth',w,'headlength',15,'headwidth',w*4,'units','normalized')
end

%14
w=abs(F(1,4));
ws = sign(F(1,4)); % sign of flux
if w~=0
if ws == +1
    p1 = P1v+[2*d,0];
    p2 = P2v+[2*d,0];
end
if ws == -1
    p1 = P2v+[2*d,0];
    p2 = P1v+[2*d,0];
end
% drawArrow(p1,p2,'MaxHeadSize',.5,'linewidth',w,'color',[0.8500, 0.3250, 0.0980])
X = [p1(1)/log(2600)   p2(1)/log(2600)]/1.3+0.13;
Y = [p1(2)/log(67)     p2(2)/log(67)]/1.20+0.10;
annotation('arrow',X,Y,'linestyle','-','color',[0.9290 0.6940 0.1250],'linewidth',w,'headlength',15,'headwidth',w*4,'units','normalized')
end

%15
w=abs(F(1,5));
ws = sign(F(1,5)); % sign of flux
if w~=0
if ws == +1
    p1 = P1v+log([3.3,1.1]);
    p2 = P2v+log([6.4,1]);
end
if ws == -1
    p1 = P2v+log([6.4,1]);
    p2 = P1v+log([3.3,1.1]);
end
% drawArrow(p1,p2,'MaxHeadSize',.5,'linewidth',w,'color',[0.8500, 0.3250, 0.0980])
X = [p1(1)/log(2600)   p2(1)/log(2600)]/1.3+0.13;
Y = [p1(2)/log(67)     p2(2)/log(67)]/1.20+0.10;
annotation('arrow',X,Y,'linestyle','-','color',[0.9290 0.6940 0.1250],'linewidth',w,'headlength',15,'headwidth',w*4,'units','normalized')
end

%23
w=abs(F(2,3));
ws = sign(F(2,3)); % sign of flux
if w~=0
if ws == +1
    p1 = P1h+log([260/20,1])-[0,d];
    p2 = P2h+log([260/20,1])-[0,d];
end
if ws == -1
    p1 = P2h+log([260/20,1])-[0,d];
    p2 = P1h+log([260/20,1])-[0,d];
end
% drawArrow(p1,p2,'MaxHeadSize',.5,'linewidth',w,'color',[0.8500, 0.3250, 0.0980])
X = [p1(1)/log(2600)   p2(1)/log(2600)]/1.3+0.13;
Y = [p1(2)/log(67)     p2(2)/log(67)]/1.20+0.10;
%annotation('arrow',X,Y,'linestyle','-','color',[0.9290 0.6940 0.1250],'linewidth',w,'headlength',15,'headwidth',w*4,'units','normalized')
end

%24
w=abs(F(2,4));
ws = sign(F(2,4)); % sign of flux
if w~=0
if ws == +1
    p1 = P1v+log([6.4*12/260*20,1.1])+[d,d]/2;
    p2 = P2v+log([3.3*12/260*20,1])+[d,d]/2;
end
if ws == -1
    p1 = P2v+log([3.3*12/260*20,1])+[d,d]/2;
    p2 = P1v+log([6.4*12/260*20,1.1])+[d,d]/2;
end
% drawArrow(p1,p2,'MaxHeadSize',.5,'linewidth',w,'color',[0.8500, 0.3250, 0.0980])
X = [p1(1)/log(2600)   p2(1)/log(2600)]/1.3+0.13;
Y = [p1(2)/log(67)     p2(2)/log(67)]/1.20+0.10;
annotation('arrow',X,Y,'linestyle','-','color',[0.9290 0.6940 0.1250],'linewidth',w,'headlength',15,'headwidth',w*4,'units','normalized')
end

%25
w=abs(F(2,5));
ws = sign(F(2,5)); % sign of flux
if w~=0
if ws == +1
    p1 = P1v+log([260/17,1])+[2*d,0];
    p2 = P2v+log([260/17,1])+[2*d,0];
end
if ws == -1
    p1 = P2v+log([260/17,1])+[2*d,0];
    p2 = P1v+log([260/17,1])+[2*d,0];
end
% drawArrow(p1,p2,'MaxHeadSize',.5,'linewidth',w,'color',[0.8500, 0.3250, 0.0980])
X = [p1(1)/log(2600)   p2(1)/log(2600)]/1.3+0.13;
Y = [p1(2)/log(67)     p2(2)/log(67)]/1.20+0.10;
annotation('arrow',X,Y,'linestyle','-','color',[0.9290 0.6940 0.1250],'linewidth',w,'headlength',15,'headwidth',w*4,'units','normalized')
end

%26
w=abs(F(2,6));
ws = sign(F(2,6)); % sign of flux
if w~=0
if ws == +1
    p1 = P1v+log([3.3*260/20,1.1]);
    p2 = P2v+log([6.4*260/20,1]);
end
if ws == -1
    p1 = P2v+log([6.4*260/20,1]);
    p2 = P1v+log([3.3*260/20,1.1]);
end
% drawArrow(p1,p2,'MaxHeadSize',.5,'linewidth',w,'color',[0.8500, 0.3250, 0.0980])
X = [p1(1)/log(2600)   p2(1)/log(2600)]/1.3+0.13;
Y = [p1(2)/log(67)     p2(2)/log(67)]/1.20+0.10;
annotation('arrow',X,Y,'linestyle','-','color',[0.9290 0.6940 0.1250],'linewidth',w,'headlength',15,'headwidth',w*4,'units','normalized')
end

%35
w=abs(F(3,5));
ws = sign(F(3,5)); % sign of flux
if w~=0
if ws == +1
    p1 = P1v+log([6.4*12,1.1]);
    p2 = P2v+log([3.3*12,1]);
end
if ws == -1
    p1 = P2v+log([3.3*12,1]);
    p2 = P1v+log([6.4*12,1.1]);
end
% drawArrow(p1,p2,'MaxHeadSize',.5,'linewidth',w,'color',[0.8500, 0.3250, 0.0980])
X = [p1(1)/log(2600)   p2(1)/log(2600)]/1.3+0.13;
Y = [p1(2)/log(67)     p2(2)/log(67)]/1.20+0.10;
%annotation('arrow',X,Y,'linestyle','-','color',[0.9290 0.6940 0.1250],'linewidth',w,'headlength',15,'headwidth',w*4,'units','normalized')
end

%36
w=abs(F(3,6));
ws = sign(F(3,6)); % sign of flux
if w~=0
if ws == +1
    p1 = P1v+log([175,1]);
    p2 = P2v+log([175,1]);
end
if ws == -1
    p1 = P2v+log([175,1]);
    p2 = P1v+log([175,1]);
end
% drawArrow(p1,p2,'MaxHeadSize',.5,'linewidth',w,'color',[0.8500, 0.3250, 0.0980])
X = [p1(1)/log(2600)   p2(1)/log(2600)]/1.3+0.13;
Y = [p1(2)/log(67)     p2(2)/log(67)]/1.20+0.10;
%annotation('arrow',X,Y,'linestyle','-','color',[0.7, 0.7, 0.7],'linewidth',w,'headlength',w*4,'headwidth',w*4,'units','normalized')
end

%45
w=abs(F(4,5));
ws = sign(F(4,5)); % sign of flux
if w~=0
if ws == +1
    p1 = P1h+log([1,25/5])-[0,d];
    p2 = P2h+log([1,25/5])-[0,d];
end
if ws == -1
    p1 = P2h+log([1,25/5])-[0,d];
    p2 = P1h+log([1,25/5])-[0,d];
end
% drawArrow(p1,p2,'MaxHeadSize',.5,'linewidth',w,'color',[0.8500, 0.3250, 0.0980])
X = [p1(1)/log(2600)   p2(1)/log(2600)]/1.3+0.13;
Y = [p1(2)/log(67)     p2(2)/log(67)]/1.20+0.10;
annotation('arrow',X,Y,'linestyle','-','color',[0.9290 0.6940 0.1250],'linewidth',w,'headlength',15,'headwidth',w*4,'units','normalized')
end

%47
w=abs(F(4,7));
ws = sign(F(4,7)); % sign of flux
if w~=0
if ws == +1
    p1 = P1v+log([1,20/5])+[2*d,0];
    p2 = P2v+log([1,20/5])+[2*d,0];
end
if ws == -1
    p1 = P2v+log([1,20/5])+[2*d,0];
    p2 = P1v+log([1,20/5])+[2*d,0];
end
% drawArrow(p1,p2,'MaxHeadSize',.5,'linewidth',w,'color',[0.8500, 0.3250, 0.0980])
X = [p1(1)/log(2600)   p2(1)/log(2600)]/1.3+0.13;
Y = [p1(2)/log(67)     p2(2)/log(67)]/1.20+0.10;
annotation('arrow',X,Y,'linestyle','-','color',[0.9290 0.6940 0.1250],'linewidth',w,'headlength',15,'headwidth',w*4,'units','normalized')
end

%48
w=abs(F(4,8));
ws = sign(F(4,8)); % sign of flux
if w~=0
if ws == +1
    p1 = P1v+log([3.3,1.1*20/5]);
    p2 = P2v+log([6.4,20/5]);
end
if ws == -1
    p1 = P2v+log([6.4,20/5]);
    p2 = P1v+log([3.3,1.1*20/5]);
end
% drawArrow(p1,p2,'MaxHeadSize',.5,'linewidth',w,'color',[0.8500, 0.3250, 0.0980])
X = [p1(1)/log(2600)   p2(1)/log(2600)]/1.3+0.13;
Y = [p1(2)/log(67)     p2(2)/log(67)]/1.20+0.10;
annotation('arrow',X,Y,'linestyle','-','color',[0.9290 0.6940 0.1250],'linewidth',w,'headlength',15,'headwidth',w*4,'units','normalized')
end

%56
w=abs(F(5,6));
ws = sign(F(5,6)); % sign of flux
if w~=0
if ws == +1
    p1 = P1h+log([260/20,25/5])-[0,d];
    p2 = P2h+log([260/20,25/5])-[0,d];
end
if ws == -1
    p1 = P2h+log([260/20,25/5])-[0,d];
    p2 = P1h+log([260/20,25/5])-[0,d];
end
% drawArrow(p1,p2,'MaxHeadSize',.5,'linewidth',w,'color',[0.8500, 0.3250, 0.0980])
X = [p1(1)/log(2600)   p2(1)/log(2600)]/1.3+0.13;
Y = [p1(2)/log(67)     p2(2)/log(67)]/1.20+0.10;
%annotation('arrow',X,Y,'linestyle','-','color',[0.9290 0.6940 0.1250],'linewidth',w,'headlength',15,'headwidth',w*4,'units','normalized')
end

%57
w=abs(F(5,7));
ws = sign(F(5,7)); % sign of flux
if w~=0
if ws == +1
    p1 = P1v+log([6.4*12/260*20,1.1*20/5]);
    p2 = P2v+log([3.3*12/260*20,20/5]);
end
if ws == -1
    p1 = P2v+log([3.3*12/260*20,20/5]);
    p2 = P1v+log([6.4*12/260*20,1.1*20/5]);
end
% drawArrow(p1,p2,'MaxHeadSize',.5,'linewidth',w,'color',[0.8500, 0.3250, 0.0980])
X = [p1(1)/log(2600)   p2(1)/log(2600)]/1.3+0.13;
Y = [p1(2)/log(67)     p2(2)/log(67)]/1.20+0.10;
annotation('arrow',X,Y,'linestyle','-','color',[0.9290 0.6940 0.1250],'linewidth',w,'headlength',15,'headwidth',w*4,'units','normalized')
end

%58
w=abs(F(5,8));
ws = sign(F(5,8)); % sign of flux
if w~=0
if ws == +1
    p1 = P1v+log([260/17,20/5])+[2*d,0];
    p2 = P2v+log([260/17,20/5])+[2*d,0];
end
if ws == -1
    p1 = P2v+log([260/17,20/5])+[2*d,0];
    p2 = P1v+log([260/17,20/5])+[2*d,0];
end
% drawArrow(p1,p2,'MaxHeadSize',.5,'linewidth',w,'color',[0.8500, 0.3250, 0.0980])
X = [p1(1)/log(2600)   p2(1)/log(2600)]/1.3+0.13;
Y = [p1(2)/log(67)     p2(2)/log(67)]/1.20+0.10;
annotation('arrow',X,Y,'linestyle','-','color',[0.9290 0.6940 0.1250],'linewidth',w,'headlength',15,'headwidth',w*4,'units','normalized')
end

%59
w=abs(F(5,9));
ws = sign(F(5,9)); % sign of flux
if w~=0
if ws == +1
    p1 = P1v+log([3.3*260/20,1.1*20/5]);
    p2 = P2v+log([6.4*260/20,20/5]);
end
if ws == -1
    p1 = P2v+log([6.4*260/20,20/5]);
    p2 = P1v+log([3.3*260/20,1.1*20/5]);
end
% drawArrow(p1,p2,'MaxHeadSize',.5,'linewidth',w,'color',[0.8500, 0.3250, 0.0980])
X = [p1(1)/log(2600)   p2(1)/log(2600)]/1.3+0.13;
Y = [p1(2)/log(67)     p2(2)/log(67)]/1.20+0.10;
annotation('arrow',X,Y,'linestyle','-','color',[0.9290 0.6940 0.1250],'linewidth',w,'headlength',15,'headwidth',w*4,'units','normalized')
end

%68
w=F(6,8);
p1 = P1v+log([6.4*12,1.1*20/5]);
p2 = P2v+log([3.3*12,1*20/5]);
% drawArrow(p1,p2,'MaxHeadSize',.5,'linewidth',w,'color',[0.8500, 0.3250, 0.0980])
X = [p1(1)/log(2600)   p2(1)/log(2600)]/1.3+0.13;
Y = [p1(2)/log(67)     p2(2)/log(67)]/1.20+0.10;
%annotation('arrow',X,Y,'linestyle','-','color',[0.8500, 0.3250, 0.0980],'linewidth',w,'headlength',15,'headwidth',w*4,'units','normalized')

%69
w=F(6,9);
p1 = P1v+log([175,20/5]);
p2 = P2v+log([175,20/5]);
%drawArrow(p1,p2,'MaxHeadSize',.5,'linewidth',w,'color',[0.8500, 0.3250, 0.0980])
X = [p1(1)/log(2600)   p2(1)/log(2600)]/1.3+0.13;
Y = [p1(2)/log(67)     p2(2)/log(67)]/1.20+0.10;
%annotation('arrow',X,Y,'linestyle','-','color',[0.7, 0.7, 0.7],'linewidth',w,'headlength',w*4,'headwidth',w*4,'units','normalized')

%78
w=F(7,8);
p1 = P1h+log([1,25/5*22/5]);
p2 = P2h+log([1,25/5*22/5]);
%drawArrow(p1,p2,'MaxHeadSize',.5,'linewidth',w,'color',[0.8500, 0.3250, 0.0980])
X = [p1(1)/log(2600)   p2(1)/log(2600)]/1.3+0.13;
Y = [p1(2)/log(67)     p2(2)/log(67)]/1.20+0.10;
%annotation('arrow',X,Y,'linestyle','-','color',[0.8500, 0.3250, 0.0980],'linewidth',w,'headlength',15,'headwidth',w*4,'units','normalized')

%89
w=F(8,9);
p1 = P1h+log([1*260/20,25/5*22/5]);
p2 = P2h+log([1*260/20,25/5*22/5]);
%drawArrow(p1,p2,'MaxHeadSize',.5,'linewidth',w,'color',[0.8500, 0.3250, 0.0980])
X = [p1(1)/log(2600)   p2(1)/log(2600)]/1.3+0.13;
Y = [p1(2)/log(67)     p2(2)/log(67)]/1.20+0.10;
%annotation('arrow',X,Y,'linestyle','-','color',[0.8500, 0.3250, 0.0980],'linewidth',w,'headlength',15,'headwidth',w*4,'units','normalized')




% txt = ['(I) $b=$', num2str(round(Nbudget(1))),'$\%$, f=', num2str(round(Nflux(1))),'$\%$'];
% %txt = '(I) b=';
% text(log(ph),log(pv),txt)
% txt = ['(IV) $b=$', num2str(round(Nbudget(4))),'$\%$, f=', num2str(round(Nflux(4))),'$\%$'];
% text(log(ph),log(pv*5),txt)
% txt = ['(VII) $b=$', num2str(round(Nbudget(7))),'$\%$, f=', num2str(round(Nflux(7))),'$\%$'];
% text(log(ph),log(pv*20),txt)
% txt = ['(II) $b=$', num2str(round(Nbudget(2))),'$\%$, f=', num2str(round(Nflux(2))),'$\%$'];
% text(log(ph*20),log(pv),txt)
% txt = ['(III) $b=$', num2str(round(Nbudget(3))),'$\%$, f=', num2str(round(Nflux(3))),'$\%$'];
% text(log(ph*260),log(pv),txt)
% txt = ['(V) $b=$', num2str(round(Nbudget(5))),'$\%$, f=', num2str(round(Nflux(5))),'$\%$'];
% text(log(ph*20),log(pv*5),txt)
% txt = ['(VI) $b=$', num2str(round(Nbudget(6))),'$\%$, f=', num2str(round(Nflux(6))),'$\%$'];
% text(log(ph*260),log(pv*5),txt)
% txt = ['(VIII) $b=$', num2str(round(Nbudget(8))),'$\%$, f=', num2str(round(Nflux(8))),'$\%$'];
% text(log(ph*20),log(pv*20),txt)
% txt = ['(IX) $b=$', num2str(round(Nbudget(9))),'$\%$, f=', num2str(round(Nflux(9))),'$\%$'];
% text(log(ph*260),log(pv*20),txt)


txt = ['LFLW'];
%txt = '(I) b=';
text(log(ph),log(pv),txt)
str=sprintf('%.1f',Tres_NILW);
txt = ['$\tau_{\rm res}=$ ',str,'d'];
text(log(ph),log(pv/1.2),txt)
str=sprintf('%.3f',r_NILW);
txt = ['$r_{\rm nl}=$ ',str];
text(log(ph),log(pv/1.4),txt)
txt = ['HFLW'];
text(log(ph),log(pv*5),txt)
str=sprintf('%.1f',Tres_HFLW);
txt = ['$\tau_{\rm res}=$ ',str,'d'];
text(log(ph),log(pv*5/1.2),txt)
str=sprintf('%.3f',r_HFLW);
txt = ['$r_{\rm nl}=$ ',str];
text(log(ph),log(pv*5/1.4),txt)
txt = ['(7)'];
%text(log(ph),log(pv*20),txt)
txt = ['LFHW'];
text(log(ph*20),log(pv),txt)
str=sprintf('%.1f',Tres_NIHW);
txt = ['$\tau_{\rm res}=$ ',str,'d'];
text(log(ph*20),log(pv/1.2),txt)
str=sprintf('%.3f',r_NIHW);
txt = ['$r_{\rm nl}=$ ',str];
text(log(ph*20),log(pv/1.4),txt)
txt = ['(3)'];
%text(log(ph*260),log(pv),txt)
txt = ['HFHW'];
text(log(ph*20),log(pv*5),txt)
str=sprintf('%.1f',Tres_HFHW);
txt = ['$\tau_{\rm res}=$ ',str,'d'];
text(log(ph*20),log(pv*5/1.2),txt)
str=sprintf('%.3f',r_HFHW);
txt = ['$r_{\rm nl}=$ ',str];
text(log(ph*20),log(pv*5/1.4),txt)
txt = ['(6)'];
%text(log(ph*260),log(pv*5),txt)
txt = ['(8)'];
%text(log(ph*20),log(pv*20),txt)
txt = ['(9)'];
%text(log(ph*260),log(pv*20),txt)
str1=sprintf('%.1d',E_tot);
DissipatedPowerGood1 = DissipatedPowerID + DissipatedPowerPSI + DissipatedPowerES;
str2=sprintf('%.1d',DissipatedPowerGood1);
str3=sprintf('%.1f',residence_time);
txt = ['$E=$ ',str1,'$\,$J$\,$kg$^{-1}$,\qquad $\mathcal P=$ ',str2,'$\,$W$\,$kg$^{-1}$,\qquad overall $ \tau_{\rm res}=$ ',str3,'d'];
text(log(ph*.7),log(pv*30),txt)

str1=sprintf('%.1d',DissipatedPowerID);
str2=sprintf('%.1d',DissipatedPowerPSI);
str3=sprintf('%.1d',DissipatedPowerES);
txt = ['$\mathcal P^{\rm (ID)}=$ ',str1,'$\,$W$\,$kg$^{-1}$'];
text(log(ph*0.7),log(pv*20),txt)
txt = ['$\mathcal P^{\rm (PSI)}=$ ',str2,'$\,$W$\,$kg$^{-1}$'];
text(log(ph*0.7),log(pv*17),txt)
txt = ['$\mathcal P^{\rm (ES)}=$ ',str3,'$\,$W$\,$kg$^{-1}$'];
text(log(ph*0.7),log(pv*14.5),txt)


axis tight


pause




figure(8);clf;
% 
%subplot(1,2,2)

set(gca,'TickLabelInterpreter','latex')
set(groot,'defaulttextinterpreter','latex');
set(groot,'defaultLegendInterpreter','latex');


%areas
X = log([1 260 260.001 2600]);%X = log([1 260 260.001 2600]);
Y = log([20 0 3.35; 20 0 3.35; 0 0 67; 0 0 67]);
ylim(log([1, 67]));
aa = area(X,Y,'FaceAlpha', 0.3);
newcolors = [1 1 1; 0.8500 0.3250 0.0980; 0 0.4470 0.7410];
colororder(newcolors)
hold on
set(gca,'TickLabelInterpreter','latex')
set(groot,'defaulttextinterpreter','latex');
set(groot,'defaultLegendInterpreter','latex');
plot([log(1),log(10*m_max/m_min)],log([1,1]),'k', 'linewidth',1.5)
hold on
loglog(log([1,2600]),log([N/f,N/f]),'k', 'linewidth',1.5)
loglog(log([1,1]),log([1,N/f]),'k', 'linewidth',1.5)
loglog(log([2600,2600]),log([1,N/f]),'k', 'linewidth',1.5)
loglog(log([m_max/m_min,m_max/m_min]),log([1,N/f]),'k', 'linewidth',1.5)
loglog(log([20,20]),log([1,N/f]),'k', 'linewidth',1.5)
loglog(log([1,2600]),log([5,5]),'k', 'linewidth',1.5)
loglog(log([1,2600]),log([20,20]),'k', 'linewidth',1.5)
xlim(log([1,10*m_max/m_min]))
ylim(log([1,N/f]))
xticks(log([1 20 260 2600]))%xticks(log([1 20 130 2600]))%
xticklabels({'$1$','$20$','$260$','$2600$'})%xticklabels({'$1$','$20$','$130$','$2600$'})%
yticks(log([1 5 20 67]))
yticklabels({'$f$','$5f$','$20f$','$N$'})
xlabel('$m$ (units of mode $1$)')
ylabel('$\omega$','Interpreter','latex')
ph = 2.3;
pv = 2.50;
plot(log([1,260]),log([20,20]),'color',[0.6350 0.0780 0.1840],'linewidth',3)
plot(log([260,260]),log([1,20]),'color',[0.6350 0.0780 0.1840],'linewidth',3)
% plot(log([1,130]),log([20,20]),'color',[0.6350 0.0780 0.1840],'linewidth',3)
% plot(log([130,130]),log([1,20]),'color',[0.6350 0.0780 0.1840],'linewidth',3)

pause
%% united arrows
%draw arrows: 
Fi = (Fs_ID_p + Fs_ID_m + Fs_PSI_p + Fs_PSI_m + Fs_ES_p + Fs_ES_m)/E_tot_n^2;%/0.0023^2;
F  = 3*3*sign(Fi).*sqrt(abs(Fi))*200*(E_tot)/0.003; %for plotting purpose

DissipatedPowerTot = +Fi(1,3) + Fi(2,3)*(Fi(2,3)>0)+Fi(2,6)+Fi(5,6)+Fi(5,9)+Fi(4,7)+Fi(5,8)+Fi(4,8)+Fi(5,7);
DissipatedPowerTot = DissipatedPowerTot*(E_tot^2)*(f/f0)

drawArrow = @(x,y,varargin) quiver( x(1),x(2),y(1)-x(1),y(2)-x(2),0, varargin{:} )  ;
P1h = log([11.5,2.3]);
P2h = log([36,2.3]);
P1v = log([4.5,3.5]);
P2v = log([4.5,7]);
d = .15;
d1 = 0;%.1;
dm = 0;
%12
w=abs(F(1,2));
ws = sign(F(1,2)); % sign of flux
if w~=0
if ws == +1
    p1 = P1h+[0,d]*1.5;
    p2 = P2h+[0,d]*1.5;
end
if ws == -1
    p1 = P2h+[0,d]*1.5;
    p2 = P1h+[0,d]*1.5;
end
% drawArrow(p1,p2,'MaxHeadSize',.5,'linewidth',w,'color',[0.8500, 0.3250, 0.0980])
X = [p1(1)/log(2600)   p2(1)/log(2600)]/1.3+0.13;
Y = [p1(2)/log(67)     p2(2)/log(67)]/1.20+0.10;
annotation('arrow',X,Y,'linestyle','-','color',[0.4, 0.4, 0.4],'linewidth',w,'headlength',15,'headwidth',w*4,'units','normalized')
end


%13
w=abs(F(1,3));
ws = sign(F(1,3)); % sign of flux
if w~=0
if ws == +1
    p1 = P1h+log([1,0.7])+[0,d]+[dm,0];
    p2 = P2h+log([260/18,0.7])+[0,d]+[dm,0];
end
if ws == -1
    p1 = P2h+log([260/18,0.7])+[0,d]+[dm,0];
    p2 = P1h+log([1,0.7])+[0,d]+[dm,0];
end
% drawArrow(p1,p2,'MaxHeadSize',.5,'linewidth',w,'color',[0.8500, 0.3250, 0.0980])
X = [p1(1)/log(2600)   p2(1)/log(2600)]/1.3+0.13;
Y = [p1(2)/log(67)     p2(2)/log(67)]/1.20+0.10;
annotation('arrow',X,Y,'linestyle','-','color',[0.4, 0.4, 0.4],'linewidth',w,'headlength',15,'headwidth',w*4,'units','normalized')
end

%14
w=abs(F(1,4));
ws = sign(F(1,4)); % sign of flux
if w~=0
if ws == +1
    p1 = P1v;
    p2 = P2v;
end
if ws == -1
    p1 = P2v;
    p2 = P1v;
end
% drawArrow(p1,p2,'MaxHeadSize',.5,'linewidth',w,'color',[0.8500, 0.3250, 0.0980])
X = [p1(1)/log(2600)   p2(1)/log(2600)]/1.3+0.13;
Y = [p1(2)/log(67)     p2(2)/log(67)]/1.20+0.10;
annotation('arrow',X,Y,'linestyle','-','color',[0.4, 0.4, 0.4],'linewidth',w,'headlength',15,'headwidth',w*4,'units','normalized')
end

%15
w=abs(F(1,5));
ws = sign(F(1,5)); % sign of flux
if w~=0
if ws == +1
    p1 = P1v+log([3.3,1.1])+[-d1,d1];
    p2 = P2v+log([6.4,1])+[-d1,d1];
end
if ws == -1
    p1 = P2v+log([6.4,1])+[-d1,d1];
    p2 = P1v+log([3.3,1.1])+[-d1,d1];
end
% drawArrow(p1,p2,'MaxHeadSize',.5,'linewidth',w,'color',[0.8500, 0.3250, 0.0980])
X = [p1(1)/log(2600)   p2(1)/log(2600)]/1.3+0.13;
Y = [p1(2)/log(67)     p2(2)/log(67)]/1.20+0.10;
annotation('arrow',X,Y,'linestyle','-','color',[0.4, 0.4, 0.4],'linewidth',w,'headlength',15,'headwidth',w*4,'units','normalized')
end

%23
w=abs(F(2,3));
ws = sign(F(2,3)); % sign of flux
if w~=0
if ws == +1
    p1 = P1h+log([260/20,1])+[0,d]*1.5+[dm,0];
    p2 = P2h+log([260/20,1])+[0,d]*1.5+[dm,0];
end
if ws == -1
    p1 = P2h+log([260/20,1])+[0,d]*1.5+[dm,0];
    p2 = P1h+log([260/20,1])+[0,d]*1.5+[dm,0];
end
% drawArrow(p1,p2,'MaxHeadSize',.5,'linewidth',w,'color',[0.8500, 0.3250, 0.0980])
X = [p1(1)/log(2600)   p2(1)/log(2600)]/1.3+0.13;
Y = [p1(2)/log(67)     p2(2)/log(67)]/1.20+0.10;
annotation('arrow',X,Y,'linestyle','-','color',[0.4, 0.4, 0.4],'linewidth',w,'headlength',15,'headwidth',w*4,'units','normalized')
end

%24
w=abs(F(2,4));
ws = sign(F(2,4)); % sign of flux
if w~=0
if ws == +1
    p1 = P1v+log([6.4*12/260*20,1.1]);
    p2 = P2v+log([3.3*12/260*20,1]);
end
if ws == -1
    p1 = P2v+log([3.3*12/260*20,1]);
    p2 = P1v+log([6.4*12/260*20,1.1]);
end
% drawArrow(p1,p2,'MaxHeadSize',.5,'linewidth',w,'color',[0.8500, 0.3250, 0.0980])
X = [p1(1)/log(2600)   p2(1)/log(2600)]/1.3+0.13;
Y = [p1(2)/log(67)     p2(2)/log(67)]/1.20+0.10;
annotation('arrow',X,Y,'linestyle','-','color',[0.4, 0.4, 0.4],'linewidth',w,'headlength',15,'headwidth',w*4,'units','normalized')
end

%25
w=abs(F(2,5));
ws = sign(F(2,5)); % sign of flux
if w~=0
if ws == +1
    p1 = P1v+log([260/17,1])+[dm,0]/2;
    p2 = P2v+log([260/17,1])+[dm,0]/2;
end
if ws == -1
    p1 = P2v+log([260/17,1])+[dm,0]/2;
    p2 = P1v+log([260/17,1])+[dm,0]/2;
end
% drawArrow(p1,p2,'MaxHeadSize',.5,'linewidth',w,'color',[0.8500, 0.3250, 0.0980])
X = [p1(1)/log(2600)   p2(1)/log(2600)]/1.3+0.13;
Y = [p1(2)/log(67)     p2(2)/log(67)]/1.20+0.10;
annotation('arrow',X,Y,'linestyle','-','color',[0.4, 0.4, 0.4],'linewidth',w,'headlength',15,'headwidth',w*4,'units','normalized')
end

%26
w=abs(F(2,6));
ws = sign(F(2,6)); % sign of flux
if w~=0
if ws == +1
    p1 = P1v+log([3.3*260/20,1.1])+[-d1,d1]+[dm,0];
    p2 = P2v+log([6.4*260/20,1])+[-d1,d1]+[dm,0];
end
if ws == -1
    p1 = P2v+log([6.4*260/20,1])+[-d1,d1]+[dm,0];
    p2 = P1v+log([3.3*260/20,1.1])+[-d1,d1]+[dm,0];
end
% drawArrow(p1,p2,'MaxHeadSize',.5,'linewidth',w,'color',[0.8500, 0.3250, 0.0980])
X = [p1(1)/log(2600)   p2(1)/log(2600)]/1.3+0.13;
Y = [p1(2)/log(67)     p2(2)/log(67)]/1.20+0.10;
annotation('arrow',X,Y,'linestyle','-','color',[0.4, 0.4, 0.4],'linewidth',w,'headlength',15,'headwidth',w*4,'units','normalized')
end

%35
w=abs(F(3,5));
ws = sign(F(3,5)); % sign of flux
if w~=0
if ws == +1
    p1 = P1v+log([6.4*12,1.1])+[dm,0];
    p2 = P2v+log([3.3*12,1])+[dm,0];
end
if ws == -1
    p1 = P2v+log([3.3*12,1])+[dm,0];
    p2 = P1v+log([6.4*12,1.1])+[dm,0];
end
% drawArrow(p1,p2,'MaxHeadSize',.5,'linewidth',w,'color',[0.8500, 0.3250, 0.0980])
X = [p1(1)/log(2600)   p2(1)/log(2600)]/1.3+0.13;
Y = [p1(2)/log(67)     p2(2)/log(67)]/1.20+0.10;
%annotation('arrow',X,Y,'linestyle','-','color',[0.8, 0.8, 0.8],'linewidth',w,'headlength',15,'headwidth',w*4,'units','normalized')
end

%36
w=abs(F(3,6));
ws = sign(F(3,6)); % sign of flux
if w~=0
if ws == +1
    p1 = P1v+log([175,1])+[dm,0];
    p2 = P2v+log([175,1])+[dm,0];
end
if ws == -1
    p1 = P2v+log([175,1])+[dm,0];
    p2 = P1v+log([175,1])+[dm,0];
end
% drawArrow(p1,p2,'MaxHeadSize',.5,'linewidth',w,'color',[0.8500, 0.3250, 0.0980])
X = [p1(1)/log(2600)   p2(1)/log(2600)]/1.3+0.13;
Y = [p1(2)/log(67)     p2(2)/log(67)]/1.20+0.10;
%annotation('arrow',X,Y,'linestyle','-','color',[0.7, 0.7, 0.7],'linewidth',w,'headlength',w*4,'headwidth',w*4,'units','normalized')
end

%45
w=abs(F(4,5));
ws = sign(F(4,5)); % sign of flux
if w~=0
if ws == +1
    p1 = P1h+log([1,25/5])+[0,d];
    p2 = P2h+log([1,25/5])+[0,d];
end
if ws == -1
    p1 = P2h+log([1,25/5])+[0,d];
    p2 = P1h+log([1,25/5])+[0,d];
end
% drawArrow(p1,p2,'MaxHeadSize',.5,'linewidth',w,'color',[0.8500, 0.3250, 0.0980])
X = [p1(1)/log(2600)   p2(1)/log(2600)]/1.3+0.13;
Y = [p1(2)/log(67)     p2(2)/log(67)]/1.20+0.10;
annotation('arrow',X,Y,'linestyle','-','color',[0.4, 0.4, 0.4],'linewidth',w,'headlength',15,'headwidth',w*4,'units','normalized')
end

%47
w=abs(F(4,7));
ws = sign(F(4,7)); % sign of flux
if w~=0
if ws == +1
    p1 = P1v+log([1,20/5]);
    p2 = P2v+log([1,20/5]);
end
if ws == -1
    p1 = P2v+log([1,20/5]);
    p2 = P1v+log([1,20/5]);
end
% drawArrow(p1,p2,'MaxHeadSize',.5,'linewidth',w,'color',[0.8500, 0.3250, 0.0980])
X = [p1(1)/log(2600)   p2(1)/log(2600)]/1.3+0.13;
Y = [p1(2)/log(67)     p2(2)/log(67)]/1.20+0.10;
annotation('arrow',X,Y,'linestyle','-','color',[0.4, 0.4, 0.4],'linewidth',w,'headlength',15,'headwidth',w*4,'units','normalized')
end

%48
w=abs(F(4,8));
ws = sign(F(4,8)); % sign of flux
if w~=0
if ws == +1
    p1 = P1v+log([3.3,1.1*20/5])+[-d1,d1];
    p2 = P2v+log([6.4,20/5])+[-d1,d1];
end
if ws == -1
    p1 = P2v+log([6.4,20/5])+[-d1,d1];
    p2 = P1v+log([3.3,1.1*20/5])+[-d1,d1];
end
% drawArrow(p1,p2,'MaxHeadSize',.5,'linewidth',w,'color',[0.8500, 0.3250, 0.0980])
X = [p1(1)/log(2600)   p2(1)/log(2600)]/1.3+0.13;
Y = [p1(2)/log(67)     p2(2)/log(67)]/1.20+0.10;
annotation('arrow',X,Y,'linestyle','-','color',[0.4, 0.4, 0.4],'linewidth',w,'headlength',15,'headwidth',w*4,'units','normalized')
end

%56
w=abs(F(5,6));
ws = sign(F(5,6)); % sign of flux
if w~=0
if ws == +1
    p1 = P1h+log([260/20,25/5])+[0,d]+[dm,0];
    p2 = P2h+log([260/20,25/5])+[0,d]+[dm,0];
end
if ws == -1
    p1 = P2h+log([260/20,25/5])+[0,d];
    p2 = P1h+log([260/20,25/5])+[0,d];
end
% drawArrow(p1,p2,'MaxHeadSize',.5,'linewidth',w,'color',[0.8500, 0.3250, 0.0980])
X = [p1(1)/log(2600)   p2(1)/log(2600)]/1.3+0.13;
Y = [p1(2)/log(67)     p2(2)/log(67)]/1.20+0.10;
annotation('arrow',X,Y,'linestyle','-','color',[0.4, 0.4, 0.4],'linewidth',w,'headlength',15,'headwidth',w*4,'units','normalized')
end

%57
w=abs(F(5,7));
ws = sign(F(5,7)); % sign of flux
if w~=0
if ws == +1
    p1 = P1v+log([6.4*12/260*20,1.1*20/5]);
    p2 = P2v+log([3.3*12/260*20,20/5]);
end
if ws == -1
    p1 = P2v+log([3.3*12/260*20,20/5]);
    p2 = P1v+log([6.4*12/260*20,1.1*20/5]);
end
% drawArrow(p1,p2,'MaxHeadSize',.5,'linewidth',w,'color',[0.8500, 0.3250, 0.0980])
X = [p1(1)/log(2600)   p2(1)/log(2600)]/1.3+0.13;
Y = [p1(2)/log(67)     p2(2)/log(67)]/1.20+0.10;
annotation('arrow',X,Y,'linestyle','-','color',[0.4, 0.4, 0.4],'linewidth',w,'headlength',15,'headwidth',w*4,'units','normalized')
end

%58
w=abs(F(5,8));
ws = sign(F(5,8)); % sign of flux
if w~=0
if ws == +1
    p1 = P1v+log([260/17,20/5])+[dm,0]/2;
    p2 = P2v+log([260/17,20/5])+[dm,0]/2;
end
if ws == -1
    p1 = P2v+log([260/17,20/5])+[dm,0]/2;
    p2 = P1v+log([260/17,20/5])+[dm,0]/2;
end
% drawArrow(p1,p2,'MaxHeadSize',.5,'linewidth',w,'color',[0.8500, 0.3250, 0.0980])
X = [p1(1)/log(2600)   p2(1)/log(2600)]/1.3+0.13;
Y = [p1(2)/log(67)     p2(2)/log(67)]/1.20+0.10;
annotation('arrow',X,Y,'linestyle','-','color',[0.4, 0.4, 0.4],'linewidth',w,'headlength',15,'headwidth',w*4,'units','normalized')
end

%59
w=abs(F(5,9));
ws = sign(F(5,9)); % sign of flux
if w~=0
if ws == +1
    p1 = P1v+log([3.3*260/20,1.1*20/5])+[-d1,d1]+[dm,0];
    p2 = P2v+log([6.4*260/20,20/5])+[-d1,d1]+[dm,0];
end
if ws == -1
    p1 = P2v+log([6.4*260/20,20/5])+[-d1,d1]+[dm,0];
    p2 = P1v+log([3.3*260/20,1.1*20/5])+[-d1,d1]+[dm,0];
end
% drawArrow(p1,p2,'MaxHeadSize',.5,'linewidth',w,'color',[0.8500, 0.3250, 0.0980])
X = [p1(1)/log(2600)   p2(1)/log(2600)]/1.3+0.13;
Y = [p1(2)/log(67)     p2(2)/log(67)]/1.20+0.10;
annotation('arrow',X,Y,'linestyle','-','color',[0.4, 0.4, 0.4],'linewidth',w,'headlength',15,'headwidth',w*4,'units','normalized')
end

%68
w=F(6,8);
p1 = P1v+log([6.4*12,1.1*20/5]);
p2 = P2v+log([3.3*12,1*20/5]);
% drawArrow(p1,p2,'MaxHeadSize',.5,'linewidth',w,'color',[0.8500, 0.3250, 0.0980])
X = [p1(1)/log(2600)   p2(1)/log(2600)]/1.3+0.13;
Y = [p1(2)/log(67)     p2(2)/log(67)]/1.20+0.10;
%annotation('arrow',X,Y,'linestyle','-','color',[0.8500, 0.3250, 0.0980],'linewidth',w,'headlength',15,'headwidth',w*4,'units','normalized')

%69
w=F(6,9);
p1 = P1v+log([175,20/5]);
p2 = P2v+log([175,20/5]);
%drawArrow(p1,p2,'MaxHeadSize',.5,'linewidth',w,'color',[0.8500, 0.3250, 0.0980])
X = [p1(1)/log(2600)   p2(1)/log(2600)]/1.3+0.13;
Y = [p1(2)/log(67)     p2(2)/log(67)]/1.20+0.10;
%annotation('arrow',X,Y,'linestyle','-','color',[0.7, 0.7, 0.7],'linewidth',w,'headlength',w*4,'headwidth',w*4,'units','normalized')

%78
w=F(7,8);
p1 = P1h+log([1,25/5*22/5]);
p2 = P2h+log([1,25/5*22/5]);
%drawArrow(p1,p2,'MaxHeadSize',.5,'linewidth',w,'color',[0.8500, 0.3250, 0.0980])
X = [p1(1)/log(2600)   p2(1)/log(2600)]/1.3+0.13;
Y = [p1(2)/log(67)     p2(2)/log(67)]/1.20+0.10;
%annotation('arrow',X,Y,'linestyle','-','color',[0.8500, 0.3250, 0.0980],'linewidth',w,'headlength',15,'headwidth',w*4,'units','normalized')

%89
w=F(8,9);
p1 = P1h+log([1*260/20,25/5*22/5]);
p2 = P2h+log([1*260/20,25/5*22/5]);
%drawArrow(p1,p2,'MaxHeadSize',.5,'linewidth',w,'color',[0.8500, 0.3250, 0.0980])
X = [p1(1)/log(2600)   p2(1)/log(2600)]/1.3+0.13;
Y = [p1(2)/log(67)     p2(2)/log(67)]/1.20+0.10;
%annotation('arrow',X,Y,'linestyle','-','color',[0.8500, 0.3250, 0.0980],'linewidth',w,'headlength',15,'headwidth',w*4,'units','normalized')

txt = ['LFLW'];
%txt = '(I) b=';
text(log(ph),log(pv)-0.2,txt)
% str=sprintf('%.1f',Tres_NILW);
% txt = ['$\tau_{\rm res}=$ ',str,'d'];
% text(log(ph),log(pv/1.2),txt)
% str=sprintf('%.3f',r_NILW);
% txt = ['$r_{\rm nl}=$ ',str];
% text(log(ph),log(pv/1.4),txt)
txt = ['HFLW'];
text(log(ph),log(pv*5)-0.2,txt)
% str=sprintf('%.1f',Tres_HFLW);
% txt = ['$\tau_{\rm res}=$ ',str,'d'];
% text(log(ph),log(pv*5/1.2),txt)
% str=sprintf('%.3f',r_HFLW);
% txt = ['$r_{\rm nl}=$ ',str];
% text(log(ph),log(pv*5/1.4),txt)
% txt = ['(7)'];
%text(log(ph),log(pv*20),txt)
txt = ['LFHW'];
text(log(ph*20),log(pv)-0.2,txt)
% str=sprintf('%.1f',Tres_NIHW);
% txt = ['$\tau_{\rm res}=$ ',str,'d'];
% text(log(ph*20),log(pv/1.2),txt)
% str=sprintf('%.3f',r_NIHW);
% txt = ['$r_{\rm nl}=$ ',str];
% text(log(ph*20),log(pv/1.4),txt)
txt = ['(3)'];
%text(log(ph*260),log(pv),txt)
txt = ['HFHW'];
text(log(ph*20),log(pv*5)-0.2,txt)
% str=sprintf('%.1f',Tres_HFHW);
% txt = ['$\tau_{\rm res}=$ ',str,'d'];
% text(log(ph*20),log(pv*5/1.2),txt)
% str=sprintf('%.3f',r_HFHW);
% txt = ['$r_{\rm nl}=$ ',str];
% text(log(ph*20),log(pv*5/1.4),txt)
% txt = ['(6)'];
%text(log(ph*260),log(pv*5),txt)
txt = ['(8)'];
%text(log(ph*20),log(pv*20),txt)
txt = ['(9)'];
%text(log(ph*260),log(pv*20),txt)
E_tot = E_tot;
residence_time = E_tot/DissipatedPowerGood1/3600/24;
str1=sprintf('%.1d',E_tot);
DissipatedPowerGood1 = DissipatedPowerID + DissipatedPowerPSI + DissipatedPowerES;
str2=sprintf('%.1d',DissipatedPowerGood1);
str3=sprintf('%.1f',residence_time);
txt = ['$E=$ ',str1,'$\,$J$\,$kg$^{-1}$,\qquad $\mathcal P=$ ',str2,'$\,$W$\,$kg$^{-1}$,\qquad overall $ \tau_{\rm res}=$ ',str3,'d'];
text(log(ph*.7),log(pv*30),txt)

str1=sprintf('%.1d',DissipatedPowerID);
str2=sprintf('%.1d',DissipatedPowerPSI);
str3=sprintf('%.1d',DissipatedPowerES);
txt = ['$\mathcal P^{\rm (ID)}=$ ',str1,'$\,$W$\,$kg$^{-1}$'];
text(log(ph*0.7),log(pv*20),txt)
txt = ['$\mathcal P^{\rm (PSI)}=$ ',str2,'$\,$W$\,$kg$^{-1}$'];
text(log(ph*0.7),log(pv*17),txt)
txt = ['$\mathcal P^{\rm (ES)}=$ ',str3,'$\,$W$\,$kg$^{-1}$'];
text(log(ph*0.7),log(pv*14.5),txt)


axis tight












%% compute n_dot (its negative part)
%resolution parameter (distance from optimal)
res = 4;
nM = 20;
nO = 8;
n_dots_neg = zeros(nO,nM);
c_om = 0;
c_m = 0;
msA = exp(linspace(log(m_min),log(m_max),nM));
osA = [[1.025,1.05,1.10,1.17,1.28,1.40,1.60,1.80,1.90,1.98,2.04,2.07,2.10,2.15,2.20,2.25,2.32,2.40,2.56,3.20,4,5]*f,exp(linspace(log(f*6.5),log(20*f),nO))];
[OsA,MsA] = meshgrid(osA,msA);
OsA=OsA';
MsA=MsA';
RsA = sqrt(1./((OsA/f).^2 - 1));

ns = A*(f*MsA./RsA/alpha).^(-4+nu).*(1+RsA.^2).^((mu-3)/2)./(1+(m_star./MsA).^2);

for m = msA
    c_m = c_m + 1
    parfor c_om = 1:length(osA)
        om = osA(c_om);
        r = sqrt(1/((om/f)^2-1));
        k = f*m/alpha/r;
        k_L = k/16;
        k_M = k*16;
        
        n = GM(k,m,params);
        
        tic
        % % Integrate over region 2
        N = 11 - res;%target:9;
        N2 = 2^N;
        N2b = 2^3;
        dk2 = k_L/N2b;
        dk = ((k - 2*k_L))/N2; % can be refined
        jx_loop = 1:floor(k_L/dk2);
        I2 = 0;
        for j = 1:(N2)
            k2 = k_L + j*dk;
            i2 = 0;
            for jx = jx_loop
                x = jx*dk2;
                [p1,p2,p3,p4,p5,p6] = IntegrandR(k,k2,k-k2+x,m,n,params);
                IR = [p1,p2,p3,p4,p5,p6];
                [p1,p2,p3,p4,p5,p6] = IntegrandT(k,k2,k-k2,m,n,params);
                IT = [p1,p2,p3,p4,p5,p6];
                jj2 = sum(IR(IR<0)) - sum(IT(IT<0))/(sqrt(2*k*k2*(k-k2)*x));
                i2  = i2 + jj2;
            end
            [p1,p2,p3,p4,p5,p6] = IntegrandT(k,k2,k-k2,m,n,params);
            IT = [p1,p2,p3,p4,p5,p6];
            i2 = i2*dk2 + sum(IT(IT<0))*sqrt(2*k_L)/(sqrt(k*k2*(k-k2)));
            I2 = I2 + i2;
        %         end
        end
        I2 = I2*dk/k
        toc
        
        tic
        % Integrate over region 3
        N = 13 - res;%target:13; %vary
        N3 = 2^N;
        N3b = 2^3;
        dk = (k_M - k - k_L)/N3;
        dk2 = k_L/N3b;
        jx_loop = 1:floor(k_L/dk2);
        I3 = 0;
        for j = 1:N3
            k2 = k + k_L + j*dk;
    %         if (k2>k_min+1 && k2<k_max)
                i3 = 0;
                for jx = jx_loop
                    x = jx*dk2;
                    [p1,p2,p3,p4,p5,p6] = IntegrandR(k,k2,k2-k+x,m,n,params);
                    IR = [p1,p2,p3,p4,p5,p6];
                    [p1,p2,p3,p4,p5,p6] = IntegrandT(k,k2,k2-k,m,n,params);
                    IT = [p1,p2,p3,p4,p5,p6];
                    jj3 = sum(IR(IR<0)) - sum(IT(IT<0))/(sqrt(2*k*k2*(k2-k)*x));
                    i3 = i3 + jj3;
                end
                [p1,p2,p3,p4,p5,p6] = IntegrandT(k,k2,k2-k,m,n,params);
                IT = [p1,p2,p3,p4,p5,p6];
                i3 = i3*dk2 + sum(IT(IT<0))*sqrt(2*k_L)/(sqrt(k*k2*(k2-k)));
                I3 = I3 + i3;
    %         end
        end
        I3 = I3*dk/k
        toc
        
        tic
        % Integrate over region 4a
        N = 10 - res;%target:9;
        dk = k/2^N;
        j1 = floor(k/dk+1);
        j_L = floor(k_L/dk)+1;
        j2_arr = floor((k_L)/dk+1):(k_M/dk);
        j3_arr = floor((k_L)/dk+1):(k_M/dk);
        I4 = 0;
        for j2 = j2_arr
            for j3 = j3_arr
                if (j3 > abs(j1 - j2) + j_L && j3 < j1 && j2 < j1 && j2>j_L)
                    k2 = j2*dk;
                    k3 = j3*dk;
    %                 if (k2>k_min && k2<k_max && k3>k_min && k3<k_max)
                        [p1,p2,p3,p4,p5,p6] = IntegrandR(k,k2,k3,m,n,params);
                        IR = [p1,p2,p3,p4,p5,p6];
                        I4 = I4 + sum(IR(IR<0));
    %                 end
                end
            end
        end
        I4a = dk^2/k*I4
        toc
        
        tic
        % Integrate over region 4b and 4c
        N = 9 - res; %target:9;
        dk = k/2^N;
        j1 = floor(k/dk+1);
        j_L = floor(k_L/dk)+1;
        j2_arr = floor((k_L)/dk+1):(k_M/dk);
        j3_arr = floor((k_L)/dk+1):(k_M/dk);
        I4b = 0;
        I4c = 0;
        for j2 = j2_arr
            j_Lmov = floor(j2*k_L/k);
            for j3 = j3_arr
                if (j3 > abs(j1 - j2) + j_L && j3 <= abs(j1 - j2) + j_Lmov && j2 > j1 && j2>j_L)
                    k2 = j2*dk;
                    k3 = j3*dk;
    %                 if (k2>k_min && k2<k_max && k3>k_min && k3<k_max)
                    [p1,p2,p3,p4,p5,p6] = IntegrandR(k,k2,k3,m,n,params);
                    IR = [p1,p2,p3,p4,p5,p6];
                    I4b = I4b + sum(IR(IR<0));
    %                 end
                end
                if (j3 > abs(j1 - j2)+1 + j_Lmov && j3 < j2 && j2 > j1 && j2>j_L)
                    k2 = j2*dk;
                    k3 = j3*dk;
    %                 if (k2>k_min && k2<k_max && k3>k_min && k3<k_max)
                        [p1,p2,p3,p4,p5,p6] = IntegrandR(k,k2,k3,m,n,params);
                        IR = [p1,p2,p3,p4,p5,p6];
                        I4c = I4c + sum(IR(IR<0));
    %                 end
                end
            end
        end
        I4b = dk^2/k*I4b
        I4c = dk^2/k*I4c
        toc

        I = I2 + 2*I3 + I4a + 2*I4b + 2*I4c;
        n_dots_neg(c_om,c_m) = I;
    end
end

n_dots_neg = V0sq*A^2*8*pi*n_dots_neg;
res_time = -ns./n_dots_neg/3600/24;
lin_time = 2*pi./(OsA)/3600/24;
nonlinearity = lin_time./res_time;
es = 4*pi*ns.*(MsA.^2).*(OsA.^2)/alpha^2*N0^2/g;
e_dots_neg = n_dots_neg*4*pi.*(MsA.^2).*(OsA.^2)/alpha^2*N0^2/g;



figure(10);clf;

%% plot 2D spectrum
subplot(4,1,1)
contourf(log(MsA/m_min),log(OsA/f),real(log10(es)),70,'linecolor','none')
hold on
contour(log(MsA/m_min),log(OsA/f),real(log10(es)),10,'k')
%areas
X = log([1 260 260.001 2600]);
Y = log([20 0 3.35; 20 0 3.35; 0 0 67; 0 0 67]);
ylim(log([1, 67]));
aa = area(X,Y,'FaceAlpha', 0.3);
newcolors = [1 1 1; 0.8500 0.3250 0.0980; 0 0.4470 0.7410];
colororder(newcolors)
hold on
set(gca,'TickLabelInterpreter','latex')
set(groot,'defaulttextinterpreter','latex');
set(groot,'defaultLegendInterpreter','latex');
plot([log(1),log(10*m_max/m_min)],log([1,1]),'k', 'linewidth',1.5)
hold on
loglog(log([1,10*m_max/m_min]),log([N/f,N/f]),'k', 'linewidth',1.5)
loglog(log([1,1]),log([1,N/f]),'k', 'linewidth',1.5)
loglog(log([10*m_max/m_min,10*m_max/m_min]),log([1,N/f]),'k', 'linewidth',1.5)
loglog(log([m_max/m_min,m_max/m_min]),log([1,N/f]),'k', 'linewidth',1.5)
loglog(log([20,20]),log([1,N/f]),'k', 'linewidth',1.5)
loglog(log([1,10*m_max/m_min]),log([5,5]),'k', 'linewidth',1.5)
loglog(log([1,10*m_max/m_min]),log([20,20]),'k', 'linewidth',1.5)
xlim(log([1,1.25*m_max/m_min]))
ylim(log([1,25]))
xticks(log([1 20 260 2600]))
xticklabels({'$1$','$20$','$260$','$2600$'})
yticks(log([1 5 20 67]))
yticklabels({'$f$','$5f$','$20f$','$N$'})
%xlabel('$m$ (units of mode $1$)')
ylabel('$\omega$','Interpreter','latex')
ph = 2.3;
pv = 2.15;
plot(log([1,260]),log([20,20]),'color',[0.6350 0.0780 0.1840],'linewidth',3)
plot(log([260,260]),log([1,20]),'color',[0.6350 0.0780 0.1840],'linewidth',3)
% caxis([-1.5,3])
a = colorbar;
a.Label.String = '$\log_{10}[e(m,\omega)]$';
set(a.Label,'interpreter','latex','FontSize',12,'Rotation',90)

%% plot outgoing transfer
subplot(4,1,2)
contourf(log(MsA/m_min),log(OsA/f),real(log10(-e_dots_neg)),70,'linecolor','none')
hold on
contour(log(MsA/m_min),log(OsA/f),real(log10(-e_dots_neg)),10,'k')
%areas
X = log([1 260 260.001 2600]);
Y = log([20 0 3.35; 20 0 3.35; 0 0 67; 0 0 67]);
ylim(log([1, 67]));
aa = area(X,Y,'FaceAlpha', 0.3);
newcolors = [1 1 1; 0.8500 0.3250 0.0980; 0 0.4470 0.7410];
colororder(newcolors)
hold on
set(gca,'TickLabelInterpreter','latex')
set(groot,'defaulttextinterpreter','latex');
set(groot,'defaultLegendInterpreter','latex');
plot([log(1),log(10*m_max/m_min)],log([1,1]),'k', 'linewidth',1.5)
hold on
loglog(log([1,10*m_max/m_min]),log([N/f,N/f]),'k', 'linewidth',1.5)
loglog(log([1,1]),log([1,N/f]),'k', 'linewidth',1.5)
loglog(log([10*m_max/m_min,10*m_max/m_min]),log([1,N/f]),'k', 'linewidth',1.5)
loglog(log([m_max/m_min,m_max/m_min]),log([1,N/f]),'k', 'linewidth',1.5)
loglog(log([20,20]),log([1,N/f]),'k', 'linewidth',1.5)
loglog(log([1,10*m_max/m_min]),log([5,5]),'k', 'linewidth',1.5)
loglog(log([1,10*m_max/m_min]),log([20,20]),'k', 'linewidth',1.5)
xlim(log([1,1.25*m_max/m_min]))
ylim(log([1,25]))
xticks(log([1 20 260 2600]))
xticklabels({'$1$','$20$','$260$','$2600$'})
yticks(log([1 5 20 67]))
yticklabels({'$f$','$5f$','$20f$','$N$'})
%xlabel('$m$ (units of mode $1$)')
ylabel('$\omega$','Interpreter','latex')
ph = 2.3;
pv = 2.15;
plot(log([1,260]),log([20,20]),'color',[0.6350 0.0780 0.1840],'linewidth',3)
plot(log([260,260]),log([1,20]),'color',[0.6350 0.0780 0.1840],'linewidth',3)
% caxis([-1.5,3])
a = colorbar;
a.Label.String = '$\log_{10}[-\dot e^{-}(m,\omega)]$';
set(a.Label,'interpreter','latex','FontSize',12,'Rotation',90)

%% plot residence times
subplot(4,1,3)
contourf(log(MsA/m_min),log(OsA/f),real(log10(res_time)),70,'linecolor','none')
hold on
contour(log(MsA/m_min),log(OsA/f),real(log10(res_time)),10,'k')
%areas
X = log([1 260 260.001 2600]);
Y = log([20 0 3.35; 20 0 3.35; 0 0 67; 0 0 67]);
ylim(log([1, 67]));
aa = area(X,Y,'FaceAlpha', 0.3);
newcolors = [1 1 1; 0.8500 0.3250 0.0980; 0 0.4470 0.7410];
colororder(newcolors)
hold on
set(gca,'TickLabelInterpreter','latex')
set(groot,'defaulttextinterpreter','latex');
set(groot,'defaultLegendInterpreter','latex');
plot([log(1),log(10*m_max/m_min)],log([1,1]),'k', 'linewidth',1.5)
hold on
loglog(log([1,10*m_max/m_min]),log([N/f,N/f]),'k', 'linewidth',1.5)
loglog(log([1,1]),log([1,N/f]),'k', 'linewidth',1.5)
loglog(log([10*m_max/m_min,10*m_max/m_min]),log([1,N/f]),'k', 'linewidth',1.5)
loglog(log([m_max/m_min,m_max/m_min]),log([1,N/f]),'k', 'linewidth',1.5)
loglog(log([20,20]),log([1,N/f]),'k', 'linewidth',1.5)
loglog(log([1,10*m_max/m_min]),log([5,5]),'k', 'linewidth',1.5)
loglog(log([1,10*m_max/m_min]),log([20,20]),'k', 'linewidth',1.5)
xlim(log([1,1.25*m_max/m_min]))
ylim(log([1,25]))
xticks(log([1 20 260 2600]))
xticklabels({'$1$','$20$','$260$','$2600$'})
yticks(log([1 5 20 67]))
yticklabels({'$f$','$5f$','$20f$','$N$'})
%xlabel('$m$ (units of mode $1$)')
ylabel('$\omega$','Interpreter','latex')
ph = 2.3;
pv = 2.15;
plot(log([1,260]),log([20,20]),'color',[0.6350 0.0780 0.1840],'linewidth',3)
plot(log([260,260]),log([1,20]),'color',[0.6350 0.0780 0.1840],'linewidth',3)
caxis([-1.5,3])
a = colorbar;
a.Label.String = '$\log_{10}[\tau_{\rm res}(m,\omega)/{\rm d}] $';
set(a.Label,'interpreter','latex','FontSize',12,'Rotation',90)


%% plot nonlinearity level
subplot(4,1,4)
contourf(log(MsA/m_min),log(OsA/f),real(log10(nonlinearity)),70,'linecolor','none') 
% this only possible with 2022 version: 'ShowText',true,'LabelFormat','%0.1f m','FaceAlpha',0.25)
hold on
contour(log(MsA/m_min),log(OsA/f),real(log10(nonlinearity)),10,'k')
contour(log(MsA/m_min),log(OsA/f),real(log10(nonlinearity)),[0 0], 'linewidth',3, 'color','w')
%contourf(log(MsA/m_min),log(OsA/f),real(log10(nonlinearity))) 
%areas
X = log([1 260 260.001 2600]);
Y = log([20 0 3.35; 20 0 3.35; 0 0 67; 0 0 67]);
ylim(log([1, 67]));
aa = area(X,Y,'FaceAlpha', 0.3);
newcolors = [1 1 1; 0.8500 0.3250 0.0980; 0 0.4470 0.7410];
colororder(newcolors)
hold on
set(gca,'TickLabelInterpreter','latex')
set(groot,'defaulttextinterpreter','latex');
set(groot,'defaultLegendInterpreter','latex');
plot([log(1),log(10*m_max/m_min)],log([1,1]),'k', 'linewidth',1.5)
hold on
loglog(log([1,10*m_max/m_min]),log([N/f,N/f]),'k', 'linewidth',1.5)
loglog(log([1,1]),log([1,N/f]),'k', 'linewidth',1.5)
loglog(log([10*m_max/m_min,10*m_max/m_min]),log([1,N/f]),'k', 'linewidth',1.5)
loglog(log([m_max/m_min,m_max/m_min]),log([1,N/f]),'k', 'linewidth',1.5)
loglog(log([20,20]),log([1,N/f]),'k', 'linewidth',1.5)
loglog(log([1,10*m_max/m_min]),log([5,5]),'k', 'linewidth',1.5)
loglog(log([1,10*m_max/m_min]),log([20,20]),'k', 'linewidth',1.5)
xlim(log([1,1.25*m_max/m_min]))
ylim(log([1,25]))
xticks(log([1 20 260 2600]))
xticklabels({'$1$','$20$','$260$','$2600$'})
yticks(log([1 5 20 67]))
yticklabels({'$f$','$5f$','$20f$','$N$'})
xlabel('$m$ (units of mode $1$)')
ylabel('$\omega$','Interpreter','latex')
ph = 2.3;
pv = 2.15;
plot(log([1,260]),log([20,20]),'color',[0.6350 0.0780 0.1840],'linewidth',3)
plot(log([260,260]),log([1,20]),'color',[0.6350 0.0780 0.1840],'linewidth',3)
caxis([-3,1])
a = colorbar
a.Label.String = '$\log_{10}[r_{\rm nl}(m,\omega)]$';
set(a.Label,'interpreter','latex','FontSize',12,'Rotation',90)
%ylabel(a,'$r_{\rm nl}$','interpreter','latex','FontSize',16,'Rotation',0);



% save('MsA','MsA','-ascii')
% save('OsA','OsA','-ascii')
% save('res_timeNIs','res_time','-ascii')
% save('nonlinearityNIs','nonlinearity','-ascii')
% save('res_timeNIs','res_time','-ascii')
% save('esNIs','es','-ascii')
% save('e_dots_negNIs','e_dots_neg','-ascii')
