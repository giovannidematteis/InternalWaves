Fs_1a_m = load('Fs_1a_m_NI');
Fs_1a_p = load('Fs_1a_p_NI');
Fs_2a_m = load('Fs_2a_m_NI');
Fs_2a_p = load('Fs_2a_p_NI');
Fs_3a_m = load('Fs_3a_m_NI');
Fs_3a_p = load('Fs_3a_p_NI');
Fs_1b_m = load('Fs_1b_m_NI');
Fs_1b_p = load('Fs_1b_p_NI');
Fs_2b_m = load('Fs_2b_m_NI');
Fs_2b_p = load('Fs_2b_p_NI');
Fs_3b_m = load('Fs_3b_m_NI');
Fs_3b_p = load('Fs_3b_p_NI');
Fs_GM_tot = load('Fs_NI_tot');

Fs_ID_m = zeros(9,9);
Fs_ID_p = zeros(9,9);
Fs_PSI_m = zeros(9,9);
Fs_PSI_p = zeros(9,9);
Fs_ES_m = zeros(9,9);
Fs_ES_p = zeros(9,9);

% Induced diffusion
Fs_ID_m(2,1) = Fs_1a_m(2,1) + Fs_1b_m(2,1);
Fs_ID_m(5,1) = Fs_1a_m(5,1) + Fs_1b_m(5,1);
Fs_ID_m(3,2) = Fs_1a_m(3,2) + Fs_1b_m(3,2);
Fs_ID_m(6,2) = Fs_1a_m(6,2) + Fs_1b_m(6,2);
Fs_ID_m(5,4) = Fs_1a_m(5,4) + Fs_1b_m(5,4);
Fs_ID_m(8,4) = Fs_1a_m(8,4) + Fs_1b_m(8,4);
Fs_ID_m(6,5) = Fs_1a_m(6,5) + Fs_1b_m(6,5);
Fs_ID_m(9,5) = Fs_1a_m(9,5) + Fs_1b_m(9,5);

% PSI
Fs_PSI_p(4,2) = Fs_1a_p(4,2) + Fs_1b_p(4,2);
Fs_PSI_p(5,3) = Fs_1a_p(5,3) + Fs_1b_p(5,3);
Fs_PSI_p(5,4) = Fs_1b_p(5,4);
Fs_PSI_p(7,5) = Fs_1a_p(7,5) + Fs_1b_p(7,5);
Fs_PSI_p(3,2) = Fs_3a_p(3,2) + Fs_3b_p(3,2);
Fs_PSI_p(2,1) = Fs_3b_p(2,1);

Fs_PSI_m(2,1) = Fs_2a_m(2,1) + Fs_2b_m(2,1) + Fs_3a_m(2,1) + Fs_3b_m(2,1);
Fs_PSI_m(3,2) = Fs_2a_m(3,2) + Fs_2b_m(3,2) + Fs_3a_m(3,2) + Fs_3b_m(3,2);
Fs_PSI_m(3,1) = Fs_2a_m(3,1) + Fs_2b_m(3,1) + Fs_3a_m(3,1) + Fs_3b_m(3,1);
Fs_PSI_m(5,4) = Fs_2a_m(5,4) + Fs_2b_m(5,4) + Fs_3a_m(5,4) + Fs_3b_m(5,4);
Fs_PSI_m(6,5) = Fs_2a_m(6,5) + Fs_2b_m(6,5) + Fs_3b_m(6,5);

%ES
Fs_ES_p(2,1) = Fs_2a_p(2,1) + Fs_2b_p(2,1) + Fs_3a_p(2,1);
Fs_ES_p(3,2) = Fs_2a_p(3,2) + Fs_2b_p(3,2);
Fs_ES_p(5,4) = Fs_2a_p(5,4) + Fs_2b_p(5,4);
Fs_ES_p(5,3) = Fs_2a_p(5,3);
Fs_ES_p(6,5) = Fs_2a_p(6,5) + Fs_2b_p(6,5);

Fs_ES_m(4,1) = Fs_1a_m(4,1) + Fs_1b_m(4,1);
Fs_ES_m(4,2) = Fs_1a_m(4,2) + Fs_1b_m(4,2);
Fs_ES_m(5,2) = Fs_1a_m(5,2) + Fs_1b_m(5,2);
Fs_ES_m(5,3) = Fs_1a_m(5,3) + Fs_1b_m(5,3);
Fs_ES_m(6,5) = Fs_3a_m(6,5);
Fs_ES_m(7,4) = Fs_1a_m(7,4) + Fs_1b_m(7,4);
Fs_ES_m(7,5) = Fs_1a_m(7,5) + Fs_1b_m(7,5);
Fs_ES_m(8,5) = Fs_1a_m(8,5) + Fs_1b_m(8,5);
pause

%% Assign by default 1/3 of ES going up to ID, difficult to untangle them
Fs_ES_m(4,1) = 2/3*Fs_ES_m(4,1);
Fs_ES_m(5,2) = 2/3*Fs_ES_m(5,2);
Fs_ES_m(7,4) = 2/3*Fs_ES_m(7,4);
Fs_ES_m(8,5) = 2/3*Fs_ES_m(8,5);

Fs_ID_m(4,1) = .5*Fs_ES_m(4,1);
Fs_ID_m(5,2) = .5*Fs_ES_m(5,2);
Fs_ID_m(7,4) = .5*Fs_ES_m(7,4);
Fs_ID_m(8,5) = .5*Fs_ES_m(8,5);




%% Build upper part of antisymmetric matrices

ii = repmat((1:9)',1,9);
jj = ii';
ff = -Fs_ID_m';
Fs_ID_m(jj>ii) = ff(jj>ii);
ff = -Fs_PSI_p';
Fs_PSI_p(jj>ii) = ff(jj>ii);
ff = -Fs_PSI_m';
Fs_PSI_m(jj>ii) = ff(jj>ii);
ff = -Fs_ES_p';
Fs_ES_p(jj>ii) = ff(jj>ii);
ff = -Fs_ES_m';
Fs_ES_m(jj>ii) = ff(jj>ii);

Fs_GM = (Fs_GM_tot - Fs_GM_tot')/2;

%% Consistency test
(Fs_ID_m + Fs_PSI_p + Fs_PSI_m + Fs_ES_p + Fs_ES_m)./Fs_GM %OK, less than 5% error!



%% Now I have the 6 signed matrices for the 3 named processes
% that encode all of the energy transfer processes!