% the script loads the file NDOTS and analyses and plots the flux matrix
% This is the high-resolution version for low frequency

nOlf = 19;
nMlf = 15;
nO = 11;
nM = 10;
n_int = 200;
ndotslf = load('NDOTS-r4-NItot-3b-lf'); %load('NDOTS-n10-r4-v2b-ar67-m2-lf');%load('NDOTS-r4-NI-3b-lf'); %load('NDOTS-r4-GM-3b-lf'); %load('NDOTS-n10-r4-v3-ar67-m2-lf');%load('NDOTS-r4-GMeth-3b-lf'); %
ndots   = load('NDOTS-r4-NItot-3b-hf'); %load('NDOTS-n10-r4-v2b-ar67-m2'); %load('NDOTS-r4-NI-3b'); %load('NDOTS-r4-GM-3b'); %load('NDOTS-n10-r4-v3-ar67-m2'); % load('NDOTS-r4-GMeth-3b'); %  
% spectral parameters
params.nu = 0.;
params.mu = 1.90;%0;
params.a = 4-params.nu;
a = params.a;
nu = params.nu;
mu = params.mu;

% physical constants
AR = 66.7978;
params.g = 9.8;
params.f = sin(32.5*pi/180)*2*7.3*10^-5;
params.N = params.f*AR; %params.N = 0.00524/2; %params.N = 0.00524; %change according to aspect ratio!!
params.rho = 1000;
g = params.g;
rho = params.rho;
N = params.N;
f = params.f;
params.alpha = params.g/params.rho/params.N;
alpha = params.alpha;
params.m_star = 4*pi/1300*g/rho/N^2;
params.m_min = 2*pi/2600*g/rho/N^2;
params.m_max = 2*pi/10*g/rho/N^2;%/5 or /10?
params.k_min = 2*pi/10^5;
params.k_max = 2*pi/5; %for test
% params.m_min = 0;
% params.m_max = 1000;
% params.k_min = 0;
% params.k_max = 1000;
m_star = params.m_star;
m_min = params.m_min;
m_max = params.m_max;
k_min = params.k_min;
k_max = params.k_max;

E = 6.3*10^-5; %GM energy level (non dimensional)
ell = 10;
c = 3;
b = 1300;
m_starCart = 4*pi/b;
k_star = c*m_starCart*f/N;

% Parameters for spectrum
s = 2*a - 7;
A = E*b^2*rho*f*m_starCart*N/pi^3/N/k_star^((1-s)/2);
V0sq = N^2/32/g;

% Define matrices with boundaries
mss = [m_min,20*m_min,m_max,20*m_max];
oss = [1.03*f,5*f,20*f,N];
Fs_p  = zeros(9,9);
Fs_m  = zeros(9,9);

figure(4);clf
title('box-j output with input from box 1')
hold on
figure(5);clf
title('input from box 1 with output in box-j')
hold on
figure(7);clf
title('box-j output with input from box 1')
hold on
figure(8);clf
hold on
figure(9);clf
hold on
figure(10);clf
hold on
figure(11);clf
hold on

for n = 1:81
    Input = floor((n-1)/9);
    Output = mod(n-1,9);
    %% define frequency and wavenumber matrices
    ind_i     = mod(floor((n-1)/9),3);
    ind_j     = floor(floor((n-1)/9)/3);
    ind_ip    = mod((n-1),3);
    ind_jp    = mod(floor((n-1)/3),3);
    [Input+1,Output+1]
    %[ind_i,ind_j,ind_ip,ind_jp]
    mA        = mss(ind_i+1);
    MA        = mss(ind_i+2);
    oA        = oss(ind_j+1);
    OA        = oss(ind_j+2);
    mB        = mss(ind_ip+1);
    MB        = mss(ind_ip+2);
    oB        = oss(ind_jp+1);
    OB        = oss(ind_jp+2);
    msA       = exp(linspace(log(mA),log(MA),nM));
    osA       = exp(linspace(log(oA),log(OA),nO));
    if ind_j==0 && ind_jp==0
        msA   = exp(linspace(log(mA),log(MA),nMlf));
        osA   = [1.025,1.05,1.10,1.17,1.28,1.40,1.80,1.90,1.98,2.04,2.07,2.10,2.15,2.25,2.40,2.56,3.20,4,5]*f;
        
        %osA = [1.025,1.05,1.10,1.17,1.28,1.40,1.80,2.04,2.07,2.10,2.15,2.25,2.40,2.56,3.20,4,5]*f;
        %osA = [1.03,1.06,1.15,1.25,1.40,1.80,2.04,2.07,2.13,2.25,2.40,2.56,3.20,4,5]*f;
    end
    [OsA,MsA] = meshgrid(osA,msA);
    OsA       = OsA';
    MsA       = MsA';
    RsA       = sqrt(1./((OsA/f).^2 - 1));
    
    %% load NDOTS and compute matrix flux: * omega, *Jacobian, double integration in omega and m
    
    if ind_j==0 && ind_jp==0
        ndot  = ndotslf(((n-1)*nOlf+1):(n*nOlf),:);
    else
        ndot      = ndots(((n-1)*nO+1):(n*nO),:);
    end
    P         = -4*pi*ndot.*(MsA.^2).*(OsA.^2)/alpha^2; %
    
    % Define linear grids for interpolation
    msA_int   = (linspace((mA*1.001),(MA*0.999),n_int));
    osA_int   = (linspace((oA*1.001),(OA*0.999),n_int));
    [OsA_int,MsA_int] = meshgrid(osA_int,msA_int);
    MsA_int   = MsA_int';
    OsA_int   = OsA_int';
%     l_msA_int = log(msA_int);
%     l_osA_int = log(osA_int);
%     [l_OsA_int,l_MsA_int] = meshgrid(l_osA_int,l_msA_int);
    
    % Interpolate over linear grid
    P_int  = interp2(MsA,OsA,P,MsA_int,OsA_int,'makima');
    %P_int2 = griddata(MsA(:),OsA(:),P(:),MsA_int,OsA_int,'nearest');
    
%     if Output==4
%         In = Input;
%         if Input<3
%             In = Input+6
%         end
%         if Input>5
%             In = Input-6
%         end
%         if Input~=4
%         figure(9);clf;
%         %subplot(3,3,mod(In,9)+1)
%         P_pos = P_int;
%         P_pos(P_int<0)=NaN;
%         Ppplot = log10(10^6*P_pos');
%         Ppplot(Ppplot<0) = 0;
%         contourf((MsA_int'/m_min),(OsA_int'/f),-Ppplot,50,'EdgeColor','None')
%         hold on
%         caxis([-5,4.5])
%         %pause
%         P_neg = P_int;
%         P_neg(P_int>0)=NaN;
%         Pnplot = log10(-10^-6./P_neg');
%         Pnplot(Pnplot>0) = 0;
%         contourf((MsA_int'/m_min),(OsA_int'/f),-Pnplot,50,'EdgeColor','None')
%         xlabel('$m/m_{\rm min}$','Interpreter','latex')
%         ylabel('$\omega/f$','Interpreter','latex')
%         caxis([-5,4.5])
%         set(gca, 'YScale', 'log')
%         set(gca, 'XScale', 'log')
%         xlim([1,2000])
%         ylim([1,67])
% %         if ind_i==2
% %             xlim([260,1000])
% %         end
%         drawnow
%         end
%     end
    
    if Output==4
        In = Input;
        if Input<3
            In = Input+6
        end
        if Input>5
            In = Input-6
        end
        if Input~=4
        figure(9)
        %subplot(3,3,mod(In,9)+1)
        P_pos = P_int;
        P_pos(P_int<0)=NaN;
        Ppplot = log10(10^6*P_pos');
        Ppplot(Ppplot<0) = 0;
        contourf((MsA_int'/m_min),(OsA_int'/f),-Ppplot,50,'EdgeColor','None')
        hold on
        caxis([-5,4.5])
        %pause
        P_neg = P_int;
        P_neg(P_int>0)=NaN;
        Pnplot = log10(-10^-6./P_neg');
        Pnplot(Pnplot>0) = 0;
        contourf((MsA_int'/m_min),(OsA_int'/f),-Pnplot,50,'EdgeColor','None')
        xlabel('$m/m_{\rm min}$','Interpreter','latex')
        ylabel('$\omega/f$','Interpreter','latex')
        caxis([-5,4.5])
        set(gca, 'YScale', 'log')
        set(gca, 'XScale', 'log')
        xlim([1,2000])
        ylim([1,67])
%         if ind_i==2
%             xlim([260,1000])
%         end
        drawnow
        end
    end
    
    if Output==0
        In = Input;
        if Input<3
            In = Input+6
        end
        if Input>5
            In = Input-6
        end
        if Input~=0
        figure(8)
        %subplot(3,3,mod(In,9)+1)
        P_pos = P_int;
        P_pos(P_int<0)=NaN;
        Ppplot = log10(10^6*P_pos');
        Ppplot(Ppplot<0) = 0;
        contourf((MsA_int'/m_min),(OsA_int'/f),-Ppplot,50,'EdgeColor','None')
        hold on
        caxis([-5,4.5])
        %pause
        P_neg = P_int;
        P_neg(P_int>0)=NaN;
        Pnplot = log10(-10^-6./P_neg');
        Pnplot(Pnplot>0) = 0;
        contourf((MsA_int'/m_min),(OsA_int'/f),-Pnplot,50,'EdgeColor','None')
        xlabel('$m/m_{\rm min}$','Interpreter','latex')
        ylabel('$\omega/f$','Interpreter','latex')
        caxis([-5,4.5])
        set(gca, 'YScale', 'log')
        set(gca, 'XScale', 'log')
        xlim([1,2000])
        ylim([1,67])
%         if ind_i==2
%             xlim([260,1000])
%         end
        drawnow
        end
    end
    
    if Output==1
        In = Input;
        if Input<3
            In = Input+6
        end
        if Input>5
            In = Input-6
        end
        if Input~=1
        figure(10)
        %subplot(3,3,mod(In,9)+1)
        P_pos = P_int;
        P_pos(P_int<0)=NaN;
        Ppplot = log10(10^6*P_pos');
        Ppplot(Ppplot<0) = 0;
        contourf((MsA_int'/m_min),(OsA_int'/f),-Ppplot,50,'EdgeColor','None')
        hold on
        caxis([-5,4.5])
        %pause
        P_neg = P_int;
        P_neg(P_int>0)=NaN;
        Pnplot = log10(-10^-6./P_neg');
        Pnplot(Pnplot>0) = 0;
        contourf((MsA_int'/m_min),(OsA_int'/f),-Pnplot,50,'EdgeColor','None')
        xlabel('$m/m_{\rm min}$','Interpreter','latex')
        ylabel('$\omega/f$','Interpreter','latex')
        caxis([-5,4.5])
        set(gca, 'YScale', 'log')
        set(gca, 'XScale', 'log')
        xlim([1,2000])
        ylim([1,67])
%         if ind_i==2
%             xlim([260,1000])
%         end
        drawnow
        end
    end
    
    if Output==3
        In = Input;
        if Input<3
            In = Input+6
        end
        if Input>5
            In = Input-6
        end
        if Input~=3
        figure(11)
        %subplot(3,3,mod(In,9)+1)
        P_pos = P_int;
        P_pos(P_int<0)=NaN;
        Ppplot = log10(10^6*P_pos');
        Ppplot(Ppplot<0) = 0;
        contourf((MsA_int'/m_min),(OsA_int'/f),-Ppplot,50,'EdgeColor','None')
        hold on
        caxis([-5,4.5])
        %pause
        P_neg = P_int;
        P_neg(P_int>0)=NaN;
        Pnplot = log10(-10^-6./P_neg');
        Pnplot(Pnplot>0) = 0;
        contourf((MsA_int'/m_min),(OsA_int'/f),-Pnplot,50,'EdgeColor','None')
        xlabel('$m/m_{\rm min}$','Interpreter','latex')
        ylabel('$\omega/f$','Interpreter','latex')
        caxis([-5,4.5])
        set(gca, 'YScale', 'log')
        set(gca, 'XScale', 'log')
        xlim([1,2000])
        ylim([1,67])
%         if ind_i==2
%             xlim([260,1000])
%         end
        drawnow
        end
    end
    
    if Output==5
        In = Input;
        if Input<3
            In = Input+6
        end
        if Input>5
            In = Input-6
        end
        if Input~=5
        figure(5)
        subplot(3,3,mod(In,9)+1)
        P_pos = P_int;
        P_pos(P_int<0)=NaN;
        Ppplot = log10(10^6*P_pos');
        Ppplot(Ppplot<0) = 0;
        contourf((MsA_int'/m_min),(OsA_int'/f),-Ppplot,50,'EdgeColor','None')
        hold on
        caxis([-5,4.5])
        %pause
        P_neg = P_int;
        P_neg(P_int>0)=NaN;
        Pnplot = log10(-10^-6./P_neg');
        Pnplot(Pnplot>0) = 0;
        contourf((MsA_int'/m_min),(OsA_int'/f),-Pnplot,50,'EdgeColor','None')
        xlabel('$m/m_{\rm min}$','Interpreter','latex')
        ylabel('$\omega/f$','Interpreter','latex')
        caxis([-5,4.5])
%         if ind_i==2
%             xlim([260,1000])
%         end
        drawnow
        end
    end
    
    
    if Output==0
        In = Input;
        if Input<3
            In = Input+6
        end
        if Input>5
            In = Input-6
        end
        if Input~=0
        figure(4)
        subplot(3,3,mod(In,9)+1)
        P_pos = P_int;
        P_pos(P_int<0)=NaN;
        Ppplot = log10(10^6*P_pos');
        Ppplot(Ppplot<0) = 0;
        contourf((MsA_int'/m_min),(OsA_int'/f),-Ppplot,50,'EdgeColor','None')
        hold on
        caxis([-5,4.5])
        %pause
        P_neg = P_int;
        P_neg(P_int>0)=NaN;
        Pnplot = log10(-10^-6./P_neg');
        Pnplot(Pnplot>0) = 0;
        contourf((MsA_int'/m_min),(OsA_int'/f),-Pnplot,50,'EdgeColor','None')
        xlabel('$m/m_{\rm min}$','Interpreter','latex')
        ylabel('$\omega/f$','Interpreter','latex')
        caxis([-5,4.5])
        if ind_i==2
            xlim([260,1000])
        end
        drawnow
        end
    end
    
    if Input==4
        Ou = Output;
        if Output<3
            Ou = Output+6
        end
        if Output>5
            Ou = Output-6
        end
        
        if Output~=4
        figure(7)
        subplot(3,3,mod(Ou,9)+1)
        P_pos = P_int;
        P_pos(P_int<0)=NaN;
        Ppplot = log10(10^4*P_pos');
        Ppplot(Ppplot<0) = 0;
        contourf((MsA_int'/m_min),(OsA_int'/f),Ppplot,50,'EdgeColor','None')
        hold on
        caxis([-4,3])
        %pause
        P_neg = P_int;
        P_neg(P_int>0)=NaN;
        Pnplot = log10(-10^-4./P_neg');
        Pnplot(Pnplot>0) = 0;
        contourf((MsA_int'/m_min),(OsA_int'/f),Pnplot,50,'EdgeColor','None')
        xlabel('$m/m_{\rm min}$','Interpreter','latex')
        ylabel('$\omega/f$','Interpreter','latex')
        caxis([-4,3])
%         if ind_i==2
%             xlim([260,1000])
%         end
        drawnow
        end
    end
    
    if Input==4
        Ou = Output;
        if Output<3
            Ou = Output+6
        end
        if Output>5
            Ou = Output-6
        end
        
        if Output~=4
        figure(6)
        subplot(3,3,mod(Ou,9)+1)
        P_pos = P_int;
        P_pos(P_int<0)=NaN;
        Ppplot = log10(10^6*P_pos');
        Ppplot(Ppplot<0) = 0;
        contourf((MsA_int'/m_min),(OsA_int'/f),Ppplot,50,'EdgeColor','None')
        hold on
        caxis([-4,3])
        %pause
        P_neg = P_int;
        P_neg(P_int>0)=NaN;
        Pnplot = log10(-10^-6./P_neg');
        Pnplot(Pnplot>0) = 0;
        contourf((MsA_int'/m_min),(OsA_int'/f),Pnplot,50,'EdgeColor','None')
        xlabel('$m/m_{\rm min}$','Interpreter','latex')
        ylabel('$\omega/f$','Interpreter','latex')
        caxis([-4,3])
%         if ind_i==2
%             xlim([260,1000])
%         end
        drawnow
        end
    end
    
    
%     figure(1);clf;
%     contourf((MsA/m_min),(OsA/f),P,'EdgeColor','None')
%     xlabel('$m/m_{\rm min}$','Interpreter','latex')
%     ylabel('$\omega/f$','Interpreter','latex')
%     drawnow

%     figure(2);clf;
%     contourf((MsA_int'/m_min),(OsA_int'/f),P_int',50,'EdgeColor','None')
%     xlabel('$m/m_{\rm min}$','Interpreter','latex')
%     ylabel('$\omega/f$','Interpreter','latex')
%     drawnow
    %pause
    
    P_int_p = P_int;
    P_int_m = P_int;
    P_int_p(P_int_p<0) = 0;
    P_int_m(P_int_m>0) = 0;
    
    F_h_p = trapz(msA_int,P_int_p,2);
    F1_p  = trapz(osA_int,F_h_p')
    Fs_p(Input+1,Output+1) = F1_p;
    
    F_h_m = trapz(msA_int,P_int_m,2);
    F1_m  = trapz(osA_int,F_h_m')
    Fs_m(Input+1,Output+1) = F1_m;
    
    F_h = trapz(msA_int,P_int,2);
    F1   = trapz(osA_int,F_h')
    Fs(Input+1,Output+1) = F1;
    
    [Input,Output]
    
%     F_v = trapz(osA_int,P_int,1);
%     F2   = trapz(msA_int,F_v)
%     Fsv(Input+1,Output+1) = F2;
    
  %pause
end

%dimensionally correct fluxes:
Fs_p = Fs_p*N^2/g; % 8*pi was forgotten in compute_fluxes, suppress here when reinstated where supposed to be!
Fs_m = Fs_m*N^2/g;

FsR_p = Fs_p;
FsR_m = Fs_m;

Fs = Fs*N^2/g; % 8*pi was forgotten in compute_fluxes, suppress here when reinstated where supposed to be!
FsR = Fs;

% Generate signed/named matrices:

% save('Fs_3b_p_NI','Fs_p','-ascii') % Meth version has m_max/2
% save('Fs_3b_m_NI','Fs_m','-ascii')
% save('Fs_NI_Tot','Fs','-ascii')