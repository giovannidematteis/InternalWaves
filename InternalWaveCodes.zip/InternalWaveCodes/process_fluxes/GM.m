function n = GM(k,m,params)

f = params.f;
alpha = params.alpha;
m_star = params.m_star;

nu = params.nu;
mu = params.mu;

r = f*m/alpha/k;
% r = 0; %switch for non-rotating, scale invariant case
%GM from arguments k,m spits out the transformed GM spectrum at (k,m)

% define z(y) as the line in a-b space on which we are going to move
% z=y is "constant flux line"
% z=2 is the interpolation of GM and PR spectra
% z=(5+y)/3 is the "constant flux" line

y = 2-nu;
z = params.z;%(5+y)/3;
% z = 2;
% z = y;

n = k^-(4-nu)*((1 + r^2)^(-3/2 + mu/2))*(abs(m)^(y-z))/(1+(m_star/abs(m))^z); % general expression
%n = k^-(4-nu)*((1 + r^2)^(-3/2 + mu/2)); % r-scale-invariant

end