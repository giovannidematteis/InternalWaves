function [m2,m3] = m2a(k,k2,k3,m,params)
    m3 = -m/2/k*(k - k2 - k3 + sqrt((k - k2 - k3)^2 + 4*k*k3));
    m2 = m + m3;
end