function f123 = f123(k1,k2,k3,n1,n2,n3,params) % computes the matrix element
    a = params.a;
    f123 = n2*n3 - n1*(n2 + n3); %(k2*k3)^(-a) - k1^(-a)*(k2^(-a) + k3^(-a));
end