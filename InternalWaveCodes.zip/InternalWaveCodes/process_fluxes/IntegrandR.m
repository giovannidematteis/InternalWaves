function [I1a,I1b,I2a,I2b,I3a,I3b] = IntegrandR(k,k2,k3,m,n,params)
    f = params.f;
    N = params.N;%*1.25;
    alpha = params.alpha;
    %m_max = params.m_max;
    %m_min = params.m_min;
    %m_cut = m_max*20;
    
    R1a = 0;
    R1b = 0;
    R2a = 0;
    R2b = 0;
    R3a = 0;
    R3b = 0;

    options = optimset('FunValCheck', 'off', 'Display','off');
  
    %[m2,m3] = m1a(k2,k3,params);
    [m2_0,m3_0] = m1a(k,k2,k3,m,params);
    fun = @(x) m_solve1(x,k2,k3,k,m,f,alpha);   % function of x alone
    m2 = fzero(fun,m2_0,options);
    m3 = m - m2;
%     m2 = m2_0;%fzero(fun,m2_0);
%     m3 = m3_0;%m - m2;
    om = sqrt(f^2 + alpha^2*k^2/m^2);
    om2 = sqrt(f^2 + alpha^2*k2^2/m2^2);
    om3 = sqrt(f^2 + alpha^2*k3^2/m3^2);
    if (om>N || om2>N || om3>N) % out of bounds
        R1a = 0;
    else
        n2 = GM(k2,m2,params);
        n3 = GM(k3,m3,params);
        R1a = k*k2*k3*Vsq123(k,k2,k3,om,om2,om3,f)*f123(k,k2,k3,n,n2,n3,params)/(g_abs(k2,k3,m2,m3,params)*Delta123(k,k2,k3));
        if (isnan(m2))
            R1a = 0;
        end
    end
    %[m2,m3] = m1b(k2,k3,params);
    [m2_0,m3_0] = m1b(k,k2,k3,m,params);
    fun = @(x) m_solve1(x,k2,k3,k,m,f,alpha);   % function of x alone
    m2 = fzero(fun,m2_0,options);
    m3 = m - m2;
%     m2 = m2_0;%fzero(fun,m2_0);
%     m3 = m3_0;%m - m3;
    %om = sqrt(f^2 + alpha^2*k^2/m^2);
    om2 = sqrt(f^2 + alpha^2*k2^2/m2^2);
    om3 = sqrt(f^2 + alpha^2*k3^2/m3^2);
    if (om>N || om2>N || om3>N) % out of bounds
        R1b = 0;
    else
        n2 = GM(k2,m2,params);
        n3 = GM(k3,m3,params);
        R1b = k*k2*k3*Vsq123(k,k2,k3,om,om2,om3,f)*f123(k,k2,k3,n,n2,n3,params)/(g_abs(k2,k3,m2,m3,params)*Delta123(k,k2,k3));
        if (isnan(m2))
            R1b = 0;
        end
    end
    %[m2,m3] = m2a(k2,k3,params);
    [m2_0,m3_0] = m2a(k,k2,k3,m,params);
    fun = @(x) m_solve2(x,k2,k3,k,m,f,alpha);   % function of x alone
    m2 = fzero(fun,m2_0,options);
    m3 = m2 - m;
%     m2 = m2_0;%fzero(fun,m2_0);
%     m3 = m3_0;%m - m3;
    %om = sqrt(f^2 + alpha^2*k^2/m^2);
    om2 = sqrt(f^2 + alpha^2*k2^2/m2^2);
    om3 = sqrt(f^2 + alpha^2*k3^2/m3^2);
    if (om>N || om2>N || om3>N) % out of bounds
        R2a = 0;
    else
        n2 = GM(k2,m2,params);
        n3 = GM(k3,m3,params);
        R2a = k*k2*k3*Vsq213(k,k2,k3,om,om2,om3,f)*f123(k2,k,k3,n2,n,n3,params)/(g_abs(k2,k3,m2,m3,params)*Delta123(k,k2,k3));
        if (isnan(m2))
            R2a = 0;
        end
    end
        %[m2,m3] = m2b(k2,k3,params);
    [m2_0,m3_0] = m2b(k,k2,k3,m,params);
    fun = @(x) m_solve2(x,k2,k3,k,m,f,alpha);   % function of x alone
    m2 = fzero(fun,m2_0,options);
    m3 = m2 - m;
%     m2 = m2_0;%fzero(fun,m2_0);
%     m3 = m3_0;%m - m3;
    %om = sqrt(f^2 + alpha^2*k^2/m^2);
    om2 = sqrt(f^2 + alpha^2*k2^2/m2^2);
    om3 = sqrt(f^2 + alpha^2*k3^2/m3^2);
    if (om>N || om2>N || om3>N) % out of bounds
        R2b = 0;
    else
        n2 = GM(k2,m2,params);
        n3 = GM(k3,m3,params);
        R2b = k*k2*k3*Vsq213(k,k2,k3,om,om2,om3,f)*f123(k2,k,k3,n2,n,n3,params)/(g_abs(k2,k3,m2,m3,params)*Delta123(k,k2,k3));
        if (isnan(m2))
            R2b = 0;
        end
    end
    %[m2,m3] = m3a(k2,k3,params);
    [m2_0,m3_0] = m3a(k,k2,k3,m,params);
    fun = @(x) m_solve3(x,k2,k3,k,m,f,alpha);   % function of x alone
    m2 = fzero(fun,m2_0,options);
    m3 = m + m2;
%     m2 = m2_0;%fzero(fun,m2_0);
%     m3 = m3_0;%m - m3;
    %om = sqrt(f^2 + alpha^2*k^2/m^2);
    om2 = sqrt(f^2 + alpha^2*k2^2/m2^2);
    om3 = sqrt(f^2 + alpha^2*k3^2/m3^2);
    if (om>N || om2>N || om3>N) % out of bounds
        R3a = 0;
    else
        n2 = GM(k2,m2,params);
        n3 = GM(k3,m3,params);
        R3a = k*k2*k3*Vsq312(k,k2,k3,om,om2,om3,f)*f123(k3,k,k2,n3,n,n2,params)/(g_abs(k2,k3,m2,m3,params)*Delta123(k,k2,k3));
        if (isnan(m2))
            R3a = 0;
        end
    end
    %[m2,m3] = m3b(k2,k3,params);
    [m2_0,m3_0] = m3b(k,k2,k3,m,params);
    fun = @(x) m_solve3(x,k2,k3,k,m,f,alpha);   % function of x alone
    m2 = fzero(fun,m2_0,options);
    m3 = m + m2;
%     m2 = m2_0;%fzero(fun,m2_0);
%     m3 = m3_0;%m - m3;
    %om = sqrt(f^2 + alpha^2*k^2/m^2);
    om2 = sqrt(f^2 + alpha^2*k2^2/m2^2);
    om3 = sqrt(f^2 + alpha^2*k3^2/m3^2);
    if (om>N || om2>N || om3>N) % out of bounds
        R3b = 0;
    else
        n2 = GM(k2,m2,params);
        n3 = GM(k3,m3,params);
        R3b = k*k2*k3*Vsq312(k,k2,k3,om,om2,om3,f)*f123(k3,k,k2,n3,n,n2,params)/(g_abs(k2,k3,m2,m3,params)*Delta123(k,k2,k3));
        if (isnan(m2))
            R3b = 0;
        end
    end
  %  I   = - R2b - R3b + R1a - R2a + R1b - R3a;
    I1a = + R1a;
    I1b = + R1b;
    I2a = - R2a;
    I2b = - R2b;
    I3a = - R3a;
    I3b = - R3b;
end