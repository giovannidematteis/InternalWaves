function g_abs = g_abs(k2,k3,m2,m3,params) % computes the matrix element
    f = params.f;
    alpha = params.alpha;
    s2 = sign(m2);
    s3 = sign(m3);
    om2 = sqrt(f^2 + alpha^2*k2^2/m2^2);
    om3 = sqrt(f^2 + alpha^2*k3^2/m3^2);
    g_abs = abs( s2*alpha^2*k2^2/abs(m2)^3/om2 - s3*alpha^2*k3^2/abs(m3)^3/om3 );
end